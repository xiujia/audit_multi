#!/bin/bash

killall oracle_dir_processing
