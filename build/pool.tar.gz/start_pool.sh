val=`cat /usr/inp/cfg/pool.cfg`
echo $val
/usr/inp/bin/pool $val

