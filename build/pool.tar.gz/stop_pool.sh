killall mongo_watchdog
killall pool
