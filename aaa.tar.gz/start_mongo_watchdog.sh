/usr/inp/bin/mongo_watchdog &
