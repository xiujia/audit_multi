#!/bin/bash

/usr/inp/bin/search_processing_dir 0
/usr/inp/bin/search_processing_dir 1
/usr/inp/bin/search_processing_dir 2
/usr/inp/bin/search_processing_dir 3
/usr/inp/bin/search_processing_dir 4
/usr/inp/bin/search_processing_dir 5
/usr/inp/bin/search_processing_dir 6
/usr/inp/bin/search_processing_dir 7
/usr/inp/bin/search_processing_dir 8
/usr/inp/bin/search_processing_dir 9

