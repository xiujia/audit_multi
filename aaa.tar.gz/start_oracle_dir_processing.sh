#!/bin/bash
/usr/inp/bin/oracle_dir_processing 1 1
/usr/inp/bin/oracle_dir_processing 2 1
/usr/inp/bin/oracle_dir_processing 3 1
/usr/inp/bin/oracle_dir_processing 4 1
/usr/inp/bin/oracle_dir_processing 5 1
