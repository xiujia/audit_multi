killall get_snmp_file
echo > /usr/inp/bin/audit_ip_mac.sh
/usr/inp/bin/audit_snmp_construct
