#ifndef SUNDAY_H
#define SUNDAY_H

char * sunday_search(const char *text, const char *pattern);
char * sunday_search_mem(const char *text, int textlen, const char *pattern, int patlen);

#endif

