#include <time.h>
#include <string.h> /* strlen()... */
#include <sys/mman.h> /* mmap()... */
#include <sys/stat.h> /* stat() */
#include <fcntl.h> /* open()... */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h> /* ntohs() */
#include <iconv.h> /* iconv() */
#include <signal.h> /* signal() */
#include <ctype.h> /* isalpha() */
#include <hiredis/hiredis.h>
#include <errno.h>
#include "/usr/src/inp/audit_new/oracleShm.c"

#include "csp_deal.h"
#include "csp_policy.h"
#include "/usr/src/inp/audit_new/redis_new_api.h" /* 2015-11-16,����snmp */


/* redis��� */
#define REDISSERVERHOST      "127.0.0.1"
#define REDISSERVERPORT      6379
#define REDIS_ORACLE_TABLE  14

#define TNS_DEBUG 1

#define TEMP_SQL_DIR "/data/audit/sql_tmp"
#define SQL_DIR "/data/audit/sql"

#define MAX_COLUMN 1024

/* TNSͷtype����ȡֵ */
#define PKT_TYPE_CONNECT 0x01
#define PKT_TYPE_ACCEPT 0x02
#define PKT_TYPE_ACK 0x03
#define PKT_TYPE_REFUSE 0x04
#define PKT_TYPE_REDIRECT 0x05
#define PKT_TYPE_DATA 0x06 /* ����(����Ҫ������,sql����ͷ��ض�������) */
#define PKT_TYPE_NULL 0x07
#define PKT_TYPE_ABORT 0x09
#define PKT_TYPE_RESEND 0x0b
#define PKT_TYPE_MARKER 0x0c
#define PKT_TYPE_ATTENTION 0x0d
#define PKT_TYPE_CONTROL 0x0e

#define TNS_NORMAL 0 /* ��0x06�����ҽ������� */
#define TNS_DEL -1   /* ��0x06�� */
#define TNS_SAVE -2  /* ��0x06���������쳣 */

#define DATA_TYPE_VARCHAR2 0x01
#define DATA_TYPE_NUMBER 0x02
#define DATA_TYPE_LONG 0x08
#define DATA_TYPE_RAW 0x17
#define DATA_TYPE_LONG_RAW 0x18
#define DATA_TYPE_ROWID 0x0b
#define DATA_TYPE_DATE 0x0c
#define DATA_TYPE_CHAR 0x60
#define DATA_TYPE_BINARY_FLOAT 0x64
#define DATA_TYPE_BINARY_DOUBLE 0x65
#define DATA_TYPE_CLOB 0x70
#define DATA_TYPE_BLOB 0x71
#define DATA_TYPE_BFILE 0x72
#define DATA_TYPE_TIMESTAMP 0xb4
#define DATA_TYPE_TIMESTAMP_TZ 0xb5
#define DATA_TYPE_INTERVAL_YEAR 0xb6
#define DATA_TYPE_INTERVAL_DAY 0xb7
#define DATA_TYPE_UROWID 0xd0
#define DATA_TYPE_TIMESTAMP_LTZ 0xe7

typedef struct {
    unsigned short length; /* TNS�����ȣ�����TNSͷ */
    unsigned short packetCheckSum; /* ����У��� */
    unsigned char type; /* TNS������ */
    unsigned char flag; /* ״̬ */
    unsigned short headerCheckSum; /* TNSͷ��У��� */
} TNS_HEADER;

typedef struct {
    char colName[1024];
    unsigned char type;

    /* ����NUMBER,FLOAT. ��NUMBER(p,s)�У�
    p�Ǿ��ȣ���ʾ��Ч���ֵ�λ��,
    sΪ����ʱ����ʾ��С���㵽�����Ч���ֵ�λ������Ϊ����ʱ����ʾ�������Ч���ֵ�С�����λ�� */
    unsigned char precision;
    unsigned char scale;
    unsigned long maxByteSize; /* ��ռ���ռ� */
    unsigned char charWidth; /* ��CHAR,VARCHARʱ��1��NCHAR,NVARCHARʱ��2 */
    unsigned char nullbit;
    unsigned int seq;
}COLUMN_INFO;

typedef struct {
    char *colValues[MAX_COLUMN+1];
    int colSizes[MAX_COLUMN+1];
}PREV_ROW_INFO;

/* �ͻ�PL/sql developer 7����oracle 10g 64bits */
#define PKT_11XX_035E__1017 0 /* 03 5E�������sql���, 10 17��������Ϣ */
#define PKT_035E__1017 1
#define PKT_035E__0602 2 /* 03 5E��������, 06 02������ֵ */
#define PKT_035E__04XX 3 /* 03 5E��������, 04 01��ʾ������Ϊ�� */
#define PKT_035E__XXXX 4 /* 03 5E����, �ظ�������1017,0602,04XX������� */

#define PKT_0305__0602 5 /* 03 05��������, 06 02�ظ���ֵ */
#define PKT_0305__04XX 6 /* 03 05��������, 04 01��ʾ������Ϊ�� */

/* �ͻ�odbc����oracle 10g 64bits */
#define PKT_034A__XXXX 7 /* 03 4A����sql���, 04XX����ͳ����Ϣ */
#define PKT_032B__08XX 8 /* 06 2B��������Ϣ, 08XX��������Ϣ */
#define PKT_0347__0602 9 /* 06 02������ֵ, 06 02�ظ���ֵ */
#define PKT_0347__04XX 10 /* 03 47���������ֵ, 04xx����û������ */

#define PKT_OTHER 100

char sql_str[5*1024] = {0};           /* �洢request������� */
char response_str[1024*1024] = {0}; /* �洢response������� */
static unsigned char bufForTnsRebuid[2*1024*1024]; /* ����TNS����������, ��Ҫunsigned */

static char bufForBigCharRebuid[5*1024];
static char bufForColValuesmain[10*1024*1024];
static char bufForColValuestmp[10*1024*1024];
static COLUMN_INFO colInfos[MAX_COLUMN];
static unsigned char redisColInfos[10240]; /* ��Ҫunsigned, ���ֽڱȽ� */
static unsigned char tmpColInfos[10240];   /* ��Ҫunsigned, ���ֽڱȽ� */
static PREV_ROW_INFO prevRow;
int isLast = 0; /* 1��ʾselect���һ���غ� */
int totalColInfoNum = 0;
int currentColInfoNum = 0;
static int line_num = 0; /* 06 02������� */

static int oracleVersion = 10;
static CSP_FILE_INFO zinfo;

static unsigned int src_ip, src_port, dst_ip, dst_port; /*255.255.255.255(0xffffffff)��ip���ֵ, ����unsigned int��ʾ*/
static int pktType;
static int flagLocation;
char filename_request[512], filename_response[512];
char cmdRmRequest[1024], cmdRmResponse[1024];


/*
���������
����sql
  �����Ԫ�黺��
���������1����,
  ����sql, ����sql
  ������ֵ, ������ֵ
�������һ����
  ����sql, ��sql����ֵ,�������
  ��û��sql, ������Ԫ�飬��sql����ֵ,�������
*/

/*
��1��select������ʾ�»غϿ�ʼ, ��hash���������½��, ���ѽ������ϻ���. ��hash�����Ѵ��ڸ���Ԫ��, �������
��1������Ϣ��, ��hash�����ҵ���Ӧ, ������Ϣд��redis
��1����ֵ��, ��hash�����ҵ���Ӧ, ����ֵд��redis

hashֵ, ip, port, mac, capture_time, interval_time, line_num�浽�����ڴ�
sql��䱣����src_ip-src_port-dst_ip-dst_port-sql��
��ֵ������src_ip-src_port-dst_ip-dst_port-rows��
�и�ʽ������src_ip-src_port-dst_ip-dst_port-cloInfos��
*/

#define getRowsKey(src_ip, src_port, dst_ip, dst_port, key) sprintf(key, "%u-%u-%u-%u-rows", src_ip, src_port, dst_ip, dst_port)
#define getColInfosKey(src_ip, src_port, dst_ip, dst_port, key) sprintf(key, "%u-%u-%u-%u-cloInfos", src_ip, src_port, dst_ip, dst_port)
#define getSqlKey(src_ip, src_port, dst_ip, dst_port, key) sprintf(key, "%u-%u-%u-%u-sql", src_ip, src_port, dst_ip, dst_port)
#define getUsernameKey(src_ip, src_port, dst_ip, dst_port, key) sprintf(key, "%u-%u-%u-%u-username", src_ip, src_port, dst_ip, dst_port)

/* ����20s���ϻ� */
//#define isold(n, now) ((n)-(now)>=200 || (now)-(n)>=200)
#define isold(n, now) 0

int getUsername_0376(char *username, int len) {
    char key[128] = {0};
    redisContext *conn = NULL;
    redisReply *reply =NULL;

    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    getUsernameKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "get %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    if (REDIS_REPLY_STRING == reply->type && reply->len>0) {
        int tocopy = ((len-1) > (reply->len)) ? (reply->len) : (len-1);
        strncpy(username, reply->str, reply->len);
        username[tocopy] = '\0';
    } else {
        username[0] = '\0';
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    #if TNS_DEBUG
    printf("getUsername_0376: username=%s, key=%s\n", username, key);
    #endif
    return 0;
}


int writeDBfile(int dir_id, unsigned long capture_time, int app_id,
                unsigned int src_ip, unsigned int src_port, char *src_mac,
                unsigned int dst_ip, unsigned int dst_port, char *dst_mac,
                unsigned long interval_time, int line_num, char *sql_str, char *response_str){
    char filename_sql[1024], temp_filename_sql[1024], command[2048],
         src_ip_str[100], dst_ip_str[200], src_mac2[200], dst_mac2[200];
    FILE *fd_sql;
    struct in_addr in;
    char c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12;
    char username[200] = {0};
    time_t t1;
    struct tm *tm1;

    #if TNS_DEBUG
    printf("writeDBfile: sql = %s\n, response = %s, app_id=%d, line_num=%d\n", sql_str, response_str, app_id, line_num);
    #endif

    if (app_id != 6 || line_num<=0) {
        #if TNS_DEBUG
        printf("writeDBfile: not write\n");
        #endif
        return 0;
    }

    /* IP */
    in.s_addr=src_ip;
    strcpy(src_ip_str, inet_ntoa(in));

    in.s_addr=dst_ip;
    strcpy(dst_ip_str, inet_ntoa(in));

    /* MAC */
    sscanf(src_mac,"%c%c%c%c%c%c%c%c%c%c%c%c",&c1,&c2,&c3,&c4,&c5,&c6,&c7,&c8,&c9,&c10,&c11,&c12);
    sprintf(src_mac2,"%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12);
    sscanf(dst_mac,"%c%c%c%c%c%c%c%c%c%c%c%c",&c1,&c2,&c3,&c4,&c5,&c6,&c7,&c8,&c9,&c10,&c11,&c12);
    sprintf(dst_mac2,"%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12);

    /* 2015-11-16, ����snmp
    char tmpSrcmac[64]={0}, tmpDstmac[64]={0};
    get_mac_str(src_ip_str, tmpSrcmac);
    get_mac_str(dst_ip_str, tmpDstmac);
    if (tmpSrcmac[0] != '\0' && tmpDstmac[0] != '\0') {
        strcpy(src_mac, tmpSrcmac);
        strcpy(dst_mac, tmpDstmac);
    }*/

    sprintf(temp_filename_sql, "%s/Sql_oracle_%lu_%d", TEMP_SQL_DIR, capture_time, dir_id);
    sprintf(filename_sql, "%s/Sql_oracle_%lu_%d", SQL_DIR, capture_time, dir_id);
    fd_sql = fopen(temp_filename_sql, "w+");

    getUsername_0376(username, sizeof(username)-1);

    time(&t1);
    tm1 = localtime(&t1);
    fprintf(fd_sql, "rowkey=%lu|", capture_time);
    fprintf(fd_sql, "colfam1:table=%04d_%02d|", tm1->tm_year+1900, tm1->tm_mon+1);
    fprintf(fd_sql, "colfam1:user_name=%s|", username);
    fprintf(fd_sql, "colfam1:app_id=%d|", app_id);
    fprintf(fd_sql, "colfam1:src_ip=%s|colfam1:dst_ip=%s|", src_ip_str, dst_ip_str);
    fprintf(fd_sql, "colfam1:src_mac=%s|colfam1:dst_mac=%s|", src_mac2, dst_mac2);
    fprintf(fd_sql, "colfam1:src_port=%u|colfam1:dst_port=%u|", src_port, dst_port);
    fprintf(fd_sql, "colfam1:interval_time=%lu|", interval_time);
    fprintf(fd_sql, "colfam1:line_num=%d|", line_num);
    fprintf(fd_sql, "colfam1:operation_command=%s|", sql_str);
    fprintf(fd_sql, "colfam1:response_content=%d|colfam\n%s\n", strlen(response_str), response_str);

    fclose(fd_sql);
    sprintf(command,"mv %s %s", temp_filename_sql, filename_sql);
    system(command);
    return 0;
}


/* 1,��redis���select���
   2,��redis���select���� */
int getSelectAndResponse(unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port, char *sqlbuf, char *reulstbuf) {
    char key[256];
    redisContext * conn;
    redisReply *reply =NULL;
    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    //��ȡ��ɾ��select
    getSqlKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "get %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    if (REDIS_REPLY_STRING == reply->type) {
        strncpy(sqlbuf, reply->str, reply->len);
        sqlbuf[reply->len] = '\0';
    } else {
        sqlbuf[0] = '\0';
    }
    freeReplyObject(reply);

    reply = (redisReply*)redisCommand(conn, "del %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);

    //��ȡ��ɾ����ֵ
    getRowsKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "get %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    if (REDIS_REPLY_STRING == reply->type) {
        strncpy(reulstbuf, reply->str, reply->len);
        reulstbuf[reply->len] = '\0';
    } else {
        reulstbuf[0] = '\0';
    }
    freeReplyObject(reply);

    reply = (redisReply*)redisCommand(conn, "del %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);

    //����Ϣ��ɾ��, ��redis�Լ���ʱɾ��, ����Ϣ��ÿ�α���select���ʱ����
    //select * from help֮��Ĳ�ѯ, PL/sql developer����һ��ȫ������, Ҫ��
    //��һҳ�Ŵ�, ���Ҫ������Ϣ��select���Ҫ���������ʱ��.��select����
    //���ϻ��������.
    /*getColInfosKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "del %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);*/

    redisFree(conn);
    reply = NULL;

    return 0;
}

/* �ӿ�ʼ����, �ѳ���10s����� */
int checkOldList(ORACLE_SHM_MEM *shm) {
    struct SHM_NODE *cur, *node, *prev, dummy;
    time_t now;
    time(&now);

    #if TNS_DEBUG
    printf("checkOldList\n");
    #endif

    if (shm->count <= 0) return 0;

    cur = shm->old;
    while (cur) {
        if (isold(cur->capture_time / 1000000, now)) {
            node = cur;
            cur = cur->oldnext; /* cur��ǰһ�� */

            /* �������, ֻ����node, ��Ҫ��cur�� */
            if (node->oldprev) node->oldprev->oldnext = node->oldnext;
            else shm->old = node->oldnext;
            if (node->oldnext) node->oldnext->oldprev = node->oldprev;

            dummy.next = shm->hashTable[node->hash % HASH_TABLE_SIZE];
            prev = &dummy;
            while (prev->next && (prev->next != node)) prev = prev->next;
            if (NULL == prev->next) {
                fprintf(stderr, "%d: cannot find node in hash table\n", __LINE__);
                return -1;
            }

            prev->next = node->next;
            shm->hashTable[node->hash % HASH_TABLE_SIZE] = dummy.next;

            memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
            getSelectAndResponse(node->src_ip, node->src_port, node->dst_ip, node->dst_port, sql_str, bufForColValuestmp);

            writeDBfile(node->dir_id, node->capture_time, 6,
                        node->src_ip, node->src_port, node->src_mac,
                        node->dst_ip, node->dst_port, node->dst_mac,
                        node->lastResutlPktCaptureTime - node->selectPktCaptureTime, node->line_num, sql_str, bufForColValuestmp);

        } else {
            cur = cur->oldnext;
        }
    }
    return 0;
}

/* ��hash��, ����, ��д����ļ�, ���������� */
int shmDelOneRecod(ORACLE_SHM_MEM *shm, unsigned int hash, unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port) {
    struct SHM_NODE *cur, *prev, dummy;
    dummy.next = shm->hashTable[hash % HASH_TABLE_SIZE];
    prev = &dummy;
    while (prev->next) {
        cur = prev->next;
        if (cur->src_ip == src_ip && cur->src_port==src_port && cur->dst_ip==dst_ip && cur->dst_port==dst_port) {
            prev->next = cur->next;
            shm->hashTable[hash % HASH_TABLE_SIZE] = dummy.next;

            if (cur->oldprev) cur->oldprev->oldnext = cur->oldnext;
            else shm->old = cur->oldnext;
            if (cur->oldnext) cur->oldnext->oldprev = cur->oldprev;

            memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
            getSelectAndResponse(cur->src_ip, cur->src_port, cur->dst_ip, cur->dst_port, sql_str, bufForColValuestmp);

            writeDBfile(cur->dir_id, cur->capture_time, 6,
                        cur->src_ip, cur->src_port, cur->src_mac,
                        cur->dst_ip, cur->dst_port, cur->dst_mac,
                        cur->lastResutlPktCaptureTime - cur->selectPktCaptureTime, cur->line_num, sql_str, bufForColValuestmp);

            memset(cur, 0, sizeof(struct SHM_NODE));
            cur->next = shm->free;
            shm->free = cur;
            shm->count--;
            return 0;
        } else {
            prev = prev->next;
        }
    }
    return 0;
}

/* ��hash��, ����, ��д����ļ�, ���������� */
int shmDelOneRecodWithLastColValues(ORACLE_SHM_MEM *shm, unsigned int hash, unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port, char *lastColValues, int line_num, unsigned long capture_time, unsigned long responseCaptureTime) {
    struct SHM_NODE *cur, *prev, dummy;
    dummy.next = shm->hashTable[hash % HASH_TABLE_SIZE];
    prev = &dummy;
    while (prev->next) {
        cur = prev->next;
        if (cur->src_ip == src_ip && cur->src_port==src_port && cur->dst_ip==dst_ip && cur->dst_port==dst_port) {
            prev->next = cur->next;
            shm->hashTable[hash % HASH_TABLE_SIZE] = dummy.next;

            if (cur->oldprev) cur->oldprev->oldnext = cur->oldnext;
            else shm->old = cur->oldnext;
            if (cur->oldnext) cur->oldnext->oldprev = cur->oldprev;

            memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
            getSelectAndResponse(cur->src_ip, cur->src_port, cur->dst_ip, cur->dst_port, sql_str, bufForColValuestmp);

            strcat(bufForColValuestmp, lastColValues);
            writeDBfile(cur->dir_id, cur->capture_time, 6,
                        cur->src_ip, cur->src_port, cur->src_mac,
                        cur->dst_ip, cur->dst_port, cur->dst_mac,
                        responseCaptureTime - cur->selectPktCaptureTime, cur->line_num+line_num, sql_str, bufForColValuestmp);

            memset(cur, 0, sizeof(struct SHM_NODE));
            cur->next = shm->free;
            shm->free = cur;
            shm->count--;
            return 0;
        } else {
            prev = prev->next;
        }
    }
    return 0;
}


/* 1, �����ϻ���
   2, ȡ��1��free�ṹ, ����������ṹ
   3, ����ͬһ��Ԫ��ļ�¼
   4, ���ϻ���, hash��
   5, дredis*/
int saveSelect(ORACLE_SHM_MEM *shm, char *sql,
    int hash, unsigned long capture_time, int dir_id,
    unsigned int src_ip, unsigned int src_port, char *src_mac,
    unsigned int dst_ip, unsigned int dst_port, char *dst_mac,
    long requestCaptureTime, long responseCaptureTime) {

    struct SHM_NODE *node;
    char key[256];
    time_t now;
    time(&now);

    /* �����ϻ��� */
    checkOldList(shm);
    if (!(shm->free)) {
        printf("(!(shm->free))\n");
        return -1;
    }

    /* ȡ��1��free�ṹ, ����������ṹ */
    node = shm->free;
    shm->free = node->next;

    node->hash = hash;
    node->src_ip = src_ip;
    node->src_port = src_port;
    strcpy(node->src_mac, src_mac);
    node->dst_ip = dst_ip;
    node->dst_port = dst_port;
    strcpy(node->dst_mac, dst_mac);
    node->capture_time = capture_time;
    node->selectPktCaptureTime = requestCaptureTime;
    node->lastResutlPktCaptureTime = responseCaptureTime;
    node->line_num = line_num;
    node->dir_id = dir_id;
    node->next = NULL;
    node->oldnext = NULL;
    node->oldprev = NULL;

    /* ����ͬһ��Ԫ��ļ�¼ */
    shmDelOneRecod(shm, hash, src_ip, src_port, dst_ip, dst_port);

    /* �ҵ�hash�� */
    node->next = shm->hashTable[hash % HASH_TABLE_SIZE];
    shm->hashTable[hash % HASH_TABLE_SIZE] = node;

    /* �ҵ��ϻ��� */
    node->oldnext = shm->old;
    if (shm->old) shm->old->oldprev = node;
    shm->old = node;

    redisContext * conn;
    redisReply *reply =NULL;
    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* ɾ��rows�� */
    getRowsKey(src_ip, src_port, dst_ip, dst_port, key);
    reply =(redisReply*)redisCommand(conn,"del %s", key);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* ɾ��colInfos�� */
    getColInfosKey(src_ip, src_port, dst_ip, dst_port, key);
    reply =(redisReply*)redisCommand(conn,"del %s", key);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* sql�����redis */
    getSqlKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 1200", key, sql);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    shm->count++;
    return 0;
}

int saveSelectColInfosColValues(ORACLE_SHM_MEM *shm,
    int hash,
    unsigned int src_ip, unsigned int src_port, char *src_mac,
    unsigned int dst_ip, unsigned int dst_port, char *dst_mac,
    unsigned long capture_time, long requestCaptureTime, long responseCaptureTime,
    int line_num, int dir_id,
    char *sql,
    COLUMN_INFO *res, unsigned int num, unsigned int totalNum,
    char *colNames, char *colValues) {

    unsigned char *pos;
    struct SHM_NODE *node;
    char key[256];
    time_t now;
    int i, len;

    time(&now);

    /* �����ϻ��� */
    if (!(shm->free)) {
        checkOldList(shm);
        if (!(shm->free)) {
            printf("(!(shm->free))\n");
            return -1;
        }
    }

    /* ȡ��1��free�ṹ, ����������ṹ */
    node = shm->free;
    shm->free = node->next;

    node->hash = hash;
    node->src_ip = src_ip;
    node->src_port = src_port;
    strcpy(node->src_mac, src_mac);
    node->dst_ip = dst_ip;
    node->dst_port = dst_port;
    strcpy(node->dst_mac, dst_mac);
    node->capture_time = capture_time;
    node->selectPktCaptureTime = requestCaptureTime;
    node->lastResutlPktCaptureTime = responseCaptureTime;
    node->line_num = line_num;
    node->dir_id = dir_id;
    node->next = NULL;
    node->oldnext = NULL;
    node->oldprev = NULL;

    /* ����ͬһ��Ԫ��ļ�¼ */
    shmDelOneRecod(shm, hash, src_ip, src_port, dst_ip, dst_port);

    /* �ҵ�hash�� */
    node->next = shm->hashTable[hash % HASH_TABLE_SIZE];
    shm->hashTable[hash % HASH_TABLE_SIZE] = node;

    /* �ҵ��ϻ��� */
    node->oldnext = shm->old;
    if (shm->old) shm->old->oldprev = node;
    shm->old = node;

    shm->count++;

    redisContext * conn;
    redisReply *reply =NULL;
    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* ����rows�� */
    getRowsKey(src_ip, src_port, dst_ip, dst_port, key);
    memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
    sprintf(bufForColValuestmp, "%s%s", colNames, colValues);
    reply =(redisReply*)redisCommand(conn,"set %s %s EX 1200", key, bufForColValuestmp);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* ����colInfos�� */
    pos = redisColInfos;
    memset(redisColInfos, 0, sizeof(redisColInfos));

    if (totalNum > 255) {
        *pos++ = 0x02;
        *pos++ = totalNum%256;
        *pos++ = totalNum/256;
    } else {
        *pos++ = 0x01;
        *pos++ = totalNum;
    }

    if (num > 255) {
        *pos++ = 0x02;
        *pos++ = num%256;
        *pos++ = num/256;
    } else {
        *pos++ = 0x01;
        *pos++ = num;
    }

    for (i=0; i<num; i++) {
        *pos++ = res[i].type;
        if (DATA_TYPE_VARCHAR2 == res[i].type || DATA_TYPE_CHAR == res[i].type) {
            *pos++ = (0x0 == res[i].charWidth) ? 0x01 : (res[i].charWidth);
        }
        len = strlen(res[i].colName);
        *pos++ = len;
        strcpy(pos, res[i].colName);
        pos += len;
    }
    *pos = '\0';

    getColInfosKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 1200", key, redisColInfos);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    reply = NULL;

    /* sql�����redis */
    getSqlKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 1200", key, sql);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    return 0;
}

/* 1, ��ȡ���е�
   2, ׷�������еĺ���
   3, дredis*/
int saveColValues(ORACLE_SHM_MEM *shm, int hash, unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port, char *colNames, char *colValues, int line_num, unsigned long capture_time, unsigned long responseCaptureTime) {
    redisContext *conn = NULL;
    redisReply *reply =NULL;
    char key[128] = {0};
    struct SHM_NODE *cur, *prev, dummy;

    dummy.next = shm->hashTable[hash % HASH_TABLE_SIZE];
    prev = &dummy;
    while (prev->next) {
        cur = prev->next;
        if (cur->src_ip == src_ip && cur->src_port==src_port && cur->dst_ip==dst_ip && cur->dst_port==dst_port) {
            cur->lastResutlPktCaptureTime = responseCaptureTime;
            cur->line_num += line_num;
            break;
        } else {
            prev = prev->next;
        }
    }

    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
    getRowsKey(src_ip, src_port, dst_ip, dst_port, key);
    if (!colNames) {
        /* ��������Ϊ��, ��ʾ�����Ѿ�д��redis��, �ȶ������е�, ��׷���ں��� */
        reply = (redisReply*)redisCommand(conn, "get %s", key);
        if(conn->err){
            fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
            if(reply){
                freeReplyObject(reply);
                return 0;
            }
            redisFree(conn);
        }
        if (REDIS_REPLY_STRING == reply->type) {
            strncpy(bufForColValuestmp, reply->str, reply->len);
            bufForColValuestmp[reply->len] = '\0';
        } else {
            bufForColValuestmp[0] = '\0';
        }
        freeReplyObject(reply);

        strcat(bufForColValuestmp, colValues);
    } else {
        sprintf(bufForColValuestmp, "%s%s", colNames, colValues);
    }

    reply = (redisReply*)redisCommand(conn, "set %s %s EX 1200", key, bufForColValuestmp);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;
    return 0;
}

int getColInfos(unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port, COLUMN_INFO *res, int *num) {
    unsigned char *pos = redisColInfos;
    int i;
    unsigned int len;
    int valueLen, totalNum;
    redisContext * conn;
    redisReply *reply =NULL;
    char key[128] = {0};

    getColInfosKey(src_ip, src_port, dst_ip, dst_port, key);

    conn = redisConnect(REDISSERVERHOST,REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        *num = 0;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    reply = (redisReply*)redisCommand(conn, "get %s", key);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    if (REDIS_REPLY_STRING == reply->type) {
        strncpy(redisColInfos, reply->str, reply->len);
        redisColInfos[reply->len] = '\0';
    } else {
        redisColInfos[0] = '\0';
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    #if 0
    printf("\n");
    for (i=0; redisColInfos[i]!= '\0'; i++) {
        printf("%02x ", redisColInfos[i]);
        if (i%16 == 0) printf("\n");
    }
    printf("\n");
    #endif

    if ('\0' == redisColInfos[0]) {
        *num = 0;
        return -1;
    }

    pos = redisColInfos;
    valueLen = strlen(redisColInfos);
    if (0x01 == *pos) {
        totalNum = pos[1];
        pos += 2;
    } else {
        totalNum = pos[1] + pos[2]*256;
        pos += 3;
    }

    if (0x01 == *pos) {
        *num = pos[1];
        pos += 2;
    } else {
        *num = pos[1] + pos[2]*256;
        pos += 3;
    }

    if (totalNum != *num) {
        printf("%d: not all infos\n", __LINE__);
    }

    for (i=0; i<*num && pos < redisColInfos+valueLen; i++) {
        res[i].type = *pos++;
        if (DATA_TYPE_VARCHAR2 == res[i].type || DATA_TYPE_CHAR == res[i].type) {
            res[i].charWidth = *pos++;
        }
        len = *pos++;
        memcpy(res[i].colName, pos, len);
        res[i].colName[len] = '\0';
        pos += len;
    }
    return 0;
}

/* ��ʽ:
   ����     �ֽ���
   ������     ���ֽ��Ǹ��ֶγ���
   ��ǰ����     ���ֽ��Ǹ��ֶγ���

   ��1����  1�ֽ�
   �ַ����� 1�ֽ�(ֻ�е�������0x01ʱ����)
   ����     ���ֽ��Ǹ��ֶγ���
   �����ظ���1�ĸ�ʽ
   */
int saveColInfos(char *key, COLUMN_INFO *res, unsigned int num, unsigned int totalNum) {
    unsigned char *pos;
    int i;
    unsigned int len, tmpNum, tmpTotal;
    redisContext * conn;
    redisReply *reply =NULL;

    /* ����redis */
    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }
    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    /* ��Ҫ: ����������, ��ֱ�Ӹ��� */
    memset(tmpColInfos, 0, sizeof(tmpColInfos));
    memset(redisColInfos, 0, sizeof(redisColInfos));
    if (num == totalNum) {
        tmpNum = 0;
    } else {
        /* ��get */
        reply = (redisReply*)redisCommand(conn, "get %s", key);
        if(conn->err){
            fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
            if(reply){
                freeReplyObject(reply);
                return 0;
            }
            redisFree(conn);
        }
        if (REDIS_REPLY_STRING == reply->type) {
            strncpy(redisColInfos, reply->str, reply->len);
            redisColInfos[reply->len] = '\0';
            if (0x01 == *pos) {
                tmpTotal = pos[1];
                pos += 2;
            } else {
                tmpTotal = pos[1] + pos[2]*256;
                pos += 3;
            }

            if (0x01 == *pos) {
                tmpNum = pos[1];
                pos += 2;
            } else {
                tmpNum = pos[1] + pos[2]*256;
                pos += 3;
            }
            strcpy(tmpColInfos, pos);
        } else {
            tmpColInfos[0] = '\0';
        }
        freeReplyObject(reply);

        if (totalNum == tmpNum || totalNum != tmpTotal || num+tmpNum > totalNum) {
            tmpColInfos[0] = '\0';
            tmpNum = 0;
        }
    }

    /* ���� */
    pos = redisColInfos;

    if (totalNum > 255) {
        *pos++ = 0x02;
        *pos++ = totalNum%256;
        *pos++ = totalNum/256;
    } else {
        *pos++ = 0x01;
        *pos++ = totalNum;
    }

    tmpNum += num;
    if (tmpNum > 255) {
        *pos++ = 0x02;
        *pos++ = tmpNum%256;
        *pos++ = tmpNum/256;
    } else {
        *pos++ = 0x01;
        *pos++ = tmpNum;
    }
    strcpy(pos, tmpColInfos);
    pos += strlen(pos);

    for (i=0; i<num; i++) {
        *pos++ = res[i].type;
        if (DATA_TYPE_VARCHAR2 == res[i].type || DATA_TYPE_CHAR == res[i].type) {
            *pos++ = (0x0 == res[i].charWidth) ? 0x01 : (res[i].charWidth);
        }
        len = strlen(res[i].colName);
        *pos++ = len;
        strcpy(pos, res[i].colName);
        pos += len;
    }
    *pos = '\0';

    /* ��set */
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 1200", key, redisColInfos);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    #if 0
    printf("\n");
    for (i=0; redisColInfos[i]!= '\0'; i++) {
        printf("%02x ", redisColInfos[i]);
        if (i%16 == 0) printf("\n");
    }
    printf("\n");
    #endif

    return 0;
}

int exists(ORACLE_SHM_MEM *shm, int hash, unsigned int src_ip, unsigned int src_port, unsigned int dst_ip, unsigned int dst_port) {
    struct SHM_NODE *cur, *node, *prev, dummy;
    cur = shm->hashTable[hash % HASH_TABLE_SIZE];
    while (cur) {
        if (cur->src_ip == src_ip && cur->src_port==src_port && cur->dst_ip==dst_ip && cur->dst_port==dst_port) {
            return 1;
        }
        cur = cur->next;
    }
    return 0;
}

static long getFileTime(char *filename) {
    struct stat buf;
    if(stat(filename, &buf)<0) {
        return -1;
    }
    return (long)buf.st_mtime;
}

/* ɾ��'str'��ͷ��ĩβ�����Ŀհ��ַ�. ԭַ����
   ���ؽ�����ĳ��� */
static int trim(char *str) {
    char *start = str,
         *end = str+strlen(str)-1;
    int num;

    if (NULL==str || '\0'==str[0]) return 0;

    while (start<=end && isspace(*start)) start++;
    while (end > start && isspace(*end)) end--;

    if (start > end) {
        str[0] = '\0';
        num = 0;
    } else {
        if (start != str) {
            memmove(str, start, end-start+1);
        }
        str[end-start+1] = '\0';
        num = end-start+1;
    }

    return num;
}

/* ��1���������Ķ�����ɴ�ӡ�ַ����һ���ո��Һ���\0
   ���ؽ�������� */
static int unprintToSpace(char *src, int slen, char *dst, int dstMaxSize) {
    int i=0, j=0;
    //if (!src || slen <= 0 || !dst || dstMaxSize<=0) {
    //    return -1;
    //}

    while (i<slen && j<(dstMaxSize-1)) {
        if ('\0' == src[i]) {
            i++;
        } else if (isprint(src[i]) || (unsigned char)src[i] > 0x80) {
            dst[j++] = src[i++];
        } else {
            dst[j++] = ' ';
            while(i<slen && !isprint(src[i])) i++;
        }
    }
    dst[j] = '\0';
    trim(dst);

    return strlen(dst);
}

static int getPolicyTime(unsigned long time){
    int  time_sec=0;
    int  time_min=0;
    const int time_zone = 8*60;
    const int week_min = 7*24*60;
    //const int day_min = 24*60;
    const int monday_start = 4*24*60;
    int res;
    time_sec = time/1000000;
    time_min = time_sec/60;

    res = (time_min + time_zone - monday_start)%week_min;

    return res;
}


static char* memfind(const char* buf, const char* tofind, size_t len,size_t findlen) {
    if (findlen > len) {
        return((char*)NULL);
    }
    if (len < 1) {
        return((char*)buf);
    } else {
        const char* bufend = &buf[len - findlen + 1];
        const char* c = buf;
        for (; c < bufend; c++) {
            if (*c == *tofind) { // first letter matches
                if (!memcmp(c + 1, tofind + 1, findlen - 1)) { // found
                    return((char*)c);
                }
            }
        }
    }
    return((char*)NULL);
}

static int deleteFile(char *file_request,char *file_response) {
    char command[2048];
    sprintf(command,"rm -fr %s",file_request);
    system(command);
    sprintf(command,"rm -fr %s",file_response);
    system(command);
    return 1;
}

static int mvFile(char *file_request,char *file_response) {
    char command[2048];
    sprintf(command,"mv %s /home/oracle_debug/",file_request);
    system(command);
    sprintf(command,"mv %s /home/oracle_debug/",file_response);
    system(command);
    return 1;
}


/* �ַ���ת�����ɹ��򷵻ؽ�������ȣ�ʧ�ܷ���-1
   ע�� - GBK/GB2312�ȣ�����һ�֣���������֮��ת������iconv()�ϳ��� */
static int codeConv(char* srcCharSet, char *dstCharSet, char *src, size_t srcLen, char *dst, size_t dstMaxSize) {
    iconv_t cd;
    size_t tmpLen = dstMaxSize;
    char *tmppos = dst;

    if (NULL==srcCharSet || NULL==dstCharSet || NULL==src || NULL==dst || srcLen<0 || dstMaxSize<0 ) {
        perror("Incorrect parameter\n");
        return -1;
    }

    /* �����߶���GBK��һ��ʱ������Ҫת�� */
    if ((('G'==srcCharSet[0] || 'g'==srcCharSet[0]) && ('B'==srcCharSet[1] || 'b'==srcCharSet[1]))
        && (('G'==dstCharSet[0] || 'g'==dstCharSet[0]) && ('B'==dstCharSet[1] || 'b'==dstCharSet[1]))) {
        memcpy(dst, src, srcLen);
        return srcLen;
    }

    cd = iconv_open(dstCharSet, srcCharSet);
    if((iconv_t)-1 == cd ){ perror("iconv_open() failed\n"); return -1; }

    memset(dst, 0, dstMaxSize);
    if(iconv(cd, &src, &srcLen, &tmppos, &tmpLen) < 0){
        iconv_close(cd);
        perror("iconv() failed\n");
        return -1;
    }
    iconv_close(cd);

    dst[dstMaxSize - tmpLen] = '\0';
    return (dstMaxSize - tmpLen);
}

static void ucs2Swap(char *data, int datalen) {
    char tmp;
    int i;
    for (i=0; i<datalen-1; i+=2) {
        tmp = data[i];
        data[i] = data[i+1];
        data[i+1] = tmp;
    }
}

static int ucs2Swap2(char *data, int datalen, char *res, int resMaxSize) {
    int i, toSwap;
    toSwap = (datalen <= resMaxSize) ? datalen : resMaxSize;
    for (i=0; i<toSwap-1; i+=2) {
        res[i] = data[i+1];
        res[i+1] = data[i];
    }
    return toSwap;
}

void setBitOpposite(unsigned char *data, int datalen) {
    int i;
    for (i=0; i<datalen; i++) {
        data[i] ^= 0xff;
    }
}

/* 111.1 : data[] = {0x40, 0x5b, 0xc7, 0x0a, 0x3d, 0x70, 0xa3}
   ������ = 0100 0000 0101 1011 1100 0111 0000 1010 0011 1101 0111 0000 1010 0011
   ����λF(1λ) = 0(+)
   ָ��λZ(11λ) = (100 0000 0101)2 = (1029)10
   β��W(23λ) = 0.1011 1100 0111 0000 1010 0011 1101 0111 0000 1010 0011 = 0.73609374999995225152815692126751
   ��IEEE754����ʾ��ʮ������ = (-1)^F * 2^(Z-1023) * (1+W) = 111.10999999999694409780204296112

   ��Z = 0, �����(-1)^F * 2^(-126) * W
   ��Z��0��0xff, �����(-1)^F * 2^(Z-127) * (1+W)
*/
static double getFloat64IEEE754(unsigned char *data) {
    int F, Z, i;
    double W, base, n;
    F = (data[0]&0x80) >> 7;
    Z = ((data[0]&0x70)>>4)*256 + ((data[0]&0x0f)<<4) + ((data[1]&0xf0)>>4);
    W = 0;
    base = 0.5;
    W += ((data[1] & 0x08)>>3)*base; base *= 0.5;
    W += ((data[1] & 0x04)>>2)*base; base *= 0.5;
    W += ((data[1] & 0x02)>>1)*base; base *= 0.5;
    W += (data[1] & 0x01)*base; base *= 0.5;

    for (i=2; i<=7; i++) {
        W += ((data[2] & 0x80)>>7)*base; base *= 0.5;
        W += ((data[2] & 0x40)>>6)*base; base *= 0.5;
        W += ((data[2] & 0x20)>>5)*base; base *= 0.5;
        W += ((data[2] & 0x10)>>4)*base; base *= 0.5;
        W += ((data[2] & 0x08)>>3)*base; base *= 0.5;
        W += ((data[2] & 0x04)>>2)*base; base *= 0.5;
        W += ((data[2] & 0x02)>>1)*base; base *= 0.5;
        W += (data[2] & 0x01)*base; base *= 0.5;
    }

    if (0 == Z) return (W * ((1==F)?(-1.0):(1.0))* (2.2250738585072013830902327173324e-308));

    n = 1;
    if (Z >= 1023) {
        for (i=0 ;i<Z-1023; i++) {
            n *= 2;
        }
    } else {
        for (i=0 ;i<1023-Z; i++) {
            n *= 0.5;
        }
    }

    return ((W+1.0)* n * ((1==F)? -1.0 : 1.0));
}

/* data[] = {0xb6, 0x33, 0x24, 0x40},���λ�����
   ��ʾIEEE754�� = 0x402433b6
   ������ = 0100 0000 0010 0100 0011 0011 1011 0110
   ����λF(1λ) = 0(+)
   ָ��λZ(8λ) = (100 0000 0)2 = (128)10
   β��W(23λ) = 0.0100100001100111011010100111001
   ��IEEE754����ʾ��ʮ������ = (-1)^F * 2^(Z-127) * (1+W)
   Ӧ����2.565656

   ��Z = 0, �����(-1)^F * 2^(-126) * W
   ��Z��0��0xff, �����(-1)^F * 2^(Z-127) * (1+W)

=========================================================================
111.1 = 01000010110111100011001100110010,(42DE3332)
F = 0
Z = 10000101 = 133
W = 0.10111100011001100110010 = 0.7359373569488525390625
(-1)^F * 2^(Z-127) * (1+W) = 1 * 64 * 1.7359373569488525390625 = 111.0999908447265625

-111.1 = 11000010110111100011001100110010,(C2DE3332)
F = 1
Z = 10000101 = 133
W = 0.10111100011001100110010 = 0.7359373569488525390625
(-1)^F * 2^(Z-127) * (1+W) = -1 * 64 * 1.7359373569488525390625 = 111.0999908447265625

=========================================================================
4321.5324 = 01000101100001110000110001000010,(45870C42)
F = 0
Z = 10001011 = 139
M = 0.00001110000110001000010 =0.0550615787506103515625
F = 0
(-1)^F * 2^(Z-127) * (1+W) = 1 * 4096 * 1.0550615787506103515625 = 4321.5322265625

-4321.5324 = 11000101100001110000110001000010,(C5870C42)
F = 1
Z = 10001011 = 139
M = 0.00001110000110001000010 = 0.0550615787506103515625
(-1)^F * 2^(Z-127) * (1+W) = -1 * 4096 * 1.0550615787506103515625 = 4321.5322265625

=========================================================================
0 = 00000000000000000000000000000000,(0)

=========================================================================
1 = 00111111100000000000000000000000,(3F800000)
F = 0
Z = 01111111 = 127
W = 00000000000000000000000
(-1)^F * 2^(Z-127) * (1+W) = 1 * 1 * 1 = 1

-1 = 10111111100000000000000000000000,(BF800000)
F = 1
Z = 01111111 = 127
W = 00000000000000000000000 = 0
(-1)^F * 2^(Z-127) * (1+W) = -1 * 1 * 1 = -1

=========================================================================
0.75 = 00111111010000000000000000000000,(3F400000)
F = 0
Z = 01111110 = 126
W = 0.10000000000000000000000 = 0.5
(-1)^F * 2^(Z-127) * (1+W) = 1 * 0.5 * 1.5 = 0.75

=========================================================================
-2.5 = 11000000001000000000000000000000,(C0200000)
F = 1
Z = 10000000 = 128
W = 0.01000000000000000000000 = 0.25
(-1)^F * 2^(Z-127) * (1+W) = -1 * 2 * 1.25 = -2.5
*/

static double getFloat32IEEE754(unsigned char *data) {
    int F, Z, i;
    double W, base, n;
    F = (data[0]&0x80) >> 7;
    Z = ((data[0]&0x7f)<<1) + ((data[1]&0x80)>>7);
    W = 0;
    base = 0.5;
    W += ((data[1] & 0x40)>>6)*base; base *= 0.5;
    W += ((data[1] & 0x20)>>5)*base; base *= 0.5;
    W += ((data[1] & 0x10)>>4)*base; base *= 0.5;
    W += ((data[1] & 0x08)>>3)*base; base *= 0.5;
    W += ((data[1] & 0x04)>>2)*base; base *= 0.5;
    W += ((data[1] & 0x02)>>1)*base; base *= 0.5;
    W += (data[1] & 0x01)*base; base *= 0.5;

    W += ((data[2] & 0x80)>>7)*base; base *= 0.5;
    W += ((data[2] & 0x40)>>6)*base; base *= 0.5;
    W += ((data[2] & 0x20)>>5)*base; base *= 0.5;
    W += ((data[2] & 0x10)>>4)*base; base *= 0.5;
    W += ((data[2] & 0x08)>>3)*base; base *= 0.5;
    W += ((data[2] & 0x04)>>2)*base; base *= 0.5;
    W += ((data[2] & 0x02)>>1)*base; base *= 0.5;
    W += (data[2] & 0x01)*base; base *= 0.5;

    W += ((data[3] & 0x80)>>7)*base; base *= 0.5;
    W += ((data[3] & 0x40)>>6)*base; base *= 0.5;
    W += ((data[3] & 0x20)>>5)*base; base *= 0.5;
    W += ((data[3] & 0x10)>>4)*base; base *= 0.5;
    W += ((data[3] & 0x08)>>3)*base; base *= 0.5;
    W += ((data[3] & 0x04)>>2)*base; base *= 0.5;
    W += ((data[3] & 0x02)>>1)*base; base *= 0.5;
    W += (data[3] & 0x01)*base; base *= 0.5;

    if (0 == Z) return (W * ((1==F)?(-1.0):(1.0))* (1.1754943508222875079687365372222e-38));

    n = 1;
    if (Z >= 127) {
        for (i=0 ;i<Z-127; i++) {
            n *= 2;
        }
    } else {
        for (i=0 ;i<127-Z; i++) {
            n *= 0.5;
        }
    }

    return ((W+1.0)* n * ((1==F)? -1.0 : 1.0));
}


static int tnsRebuild(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos=data;
    char *resPos=res;
    int leftlen = datalen, reslen=0, len;
    TNS_HEADER *tnsh = (TNS_HEADER *)pos;

    len = ntohs(tnsh->length);
    if (len >= datalen) {
        memcpy(res+10, data, datalen-10);
        return datalen-10;
    }

    while (leftlen > 0) {
        memcpy(resPos, pos+10, len-10);
        reslen += (len-10);
        resPos += (len-10);
        pos += len;
        leftlen -= len;

        if (leftlen <= 0) break;
        tnsh = (TNS_HEADER *)pos;
        len = ntohs(tnsh->length);
    }
    return reslen;
}

/* ���ؽ�����data�����ֽ�
   @resMaxSize����@res���ռ䣬����󷵻ش���res���ֽ��� */
static int segmentsReform(unsigned char *data, char *res, int *resMaxSize) {
    int len, parsedLen=0, reslen=0;
    unsigned char *pos = data;
    char *respos = res;

    while ((unsigned char)*pos != 0x00) {
        len = *pos++;
        memcpy(respos, pos, len);
        pos += len;
        parsedLen += (1 + len);
        respos += len;
        reslen += len;
    }

    *resMaxSize = reslen;
    return parsedLen+1; /* ����������β��0x0 */
}

/* ���ؽ�������ĳ��ȣ�@datalen���ؽ�����data�ĳ��� */
int parseCHAR(unsigned char *data, int *datalen, char *res, int resSize) {
    unsigned char *pos = data;
    int len, tmplen;

    /* null */
    if (0x00 == (unsigned char)*pos) {
        strcpy(res, "null");
        *datalen = 1;
        return 4;
    }

    if (0xfe == (unsigned char)*pos) {
        pos++;
        len = segmentsReform(pos, res, &tmplen);
        pos += len;
    } else {
        len = *pos++;
        memcpy(res, pos, len);
        tmplen = len;
        pos += len;
    }

    *datalen = (pos-data);
    return tmplen;
}

/* ���ؽ�������ĳ��ȣ�@datalen���ؽ�����data�ĳ��� */
int parseNUMBER(unsigned char *data, int *datalen, char *res, int resSize) {
    /* 0x02: NUMBER, INTEGER, FLOAT */
    unsigned char *pos = data;
    char *resPos = res;
    int len;
    int intLen, docLen, padLen, j;

    /* null */
    if (0x00 == (unsigned char)*pos) {
        strcpy(res, "null");
        *datalen = 1;
        return 4;
    }

    /* 0x01 0x80 */
    if (0x01 == (unsigned char)pos[0] && 0x80 == (unsigned char)pos[1]) {
        res[0] = '0';
        res[1] = '\0';
        *datalen = 2;
        return 1;
    }

    len = *pos++;
    if ((unsigned char)*pos >= 0xc0) {
        /* ���� */
        intLen = (unsigned char)*pos - 0xc0;
        if (intLen >= len-1) {
            padLen = intLen - (len -1);
            intLen = len - 1;
            docLen = 0;
        } else {
            padLen = 0;
            docLen = len - intLen -1;
        }
        pos++;

        if ( 0 == intLen) {
            *resPos++ = '0';
        } else {
            for (j=0; j<intLen; j++) {
                if (j!=0) sprintf(resPos, "%02d", pos[j]-1);
                else sprintf(resPos, "%d", pos[j]-1);
                resPos += strlen(resPos);
            }
            pos += intLen;
            for (j=0; j<padLen; j++) {
                *resPos++ = '0';
                *resPos++ = '0';
            }
        }
        if (docLen != 0) {
            *resPos++ = '.';
            for (j=0; j<docLen; j++) {
                sprintf(resPos, "%02d", pos[j]-1);
                resPos += strlen(resPos);
            }
            pos += docLen;
        }
    } else if ((unsigned int)*pos <= (unsigned int)0x3f){
        /* ���� */
        intLen = 0x3f - (unsigned int)*pos;
        *resPos++ = '-';
        if (intLen >= len-1-1) {
            padLen = intLen - (len - 1 - 1);
            intLen = len - 1 - 1;
            docLen = 0;
        } else {
            padLen = 0;
            docLen = len - intLen - 1 - 1; /* ��1���ַ������1���ַ�0x66(0x66�Ǹ�������) */
        }
        pos++;

        if ( 0 == intLen) {
            *resPos++ = '0';
        } else {
            for (j=0; j<intLen; j++) {
                if (j!=0) sprintf(resPos, "%02d", 101-pos[j]);
                else sprintf(resPos, "%d", 101-pos[j]);
                resPos += strlen(resPos);
            }
            for (j=0; j<padLen; j++) {
                *resPos++ = '0';
                *resPos++ = '0';
            }
            pos += intLen;
        }
        if (docLen != 0) {
            *resPos++ = '.';
            for (j=0; j<docLen; j++) {
                sprintf(resPos, "%02d", 101-pos[j]);
                resPos += strlen(resPos);
            }
            pos += docLen;
        }
        pos++; /* ����ĩβ��0x66 */
    }

    *datalen = pos-data;
    return resPos-res;
}

/* ���ؽ�������ĳ��ȣ�@datalen���ؽ�����data�ĳ��� */
int parseDATE(unsigned char *data, int *datalen, char *res, int resSize) {
    /* null */
    if (0x00 == data[0]) {
        strcpy(res, "null");
    } else if (0x07 == data[0]){
        if (0x64==data[1]) {
            sprintf(res, "%02d-%02d-%02d %02d:%02d:%02d",
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]);
        } else {
            sprintf(res, "%d%02d-%02d-%02d %02d:%02d:%02d",
                ((data[1]>100) ? (data[1]-100) : (100-data[1])),
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]);
        }
    } else {
        printf("not DATE type\n");
        res[0] = '\0';
        /* *datalen���䣬����������������ֶ� */
        return 0;
    }
    *datalen = (data[0]+1);
    return strlen(res);
}

/* ���ؽ�������ĳ��ȣ�@datalen���ؽ�����data�ĳ��� */
int parseTIMESTAMP(unsigned char *data, int *datalen, char *res, int resSize) {
    /* null */
    if (0x00 == data[0]) {
        strcpy(res, "null");
    } else if (0x07 == data[0]) {
        if (0x64==data[1]) {
            sprintf(res, "%02d-%02d-%02d %02d:%02d:%02d.000000000",
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]-1);
        } else {
            sprintf(res, "%d%02d-%02d-%02d %02d:%02d:%02d.000000000",
                ((data[1]>=100) ? (data[1]-100) : (100-data[1])),
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]-1);
        }
    } else if (0x0b == data[0]) {
        unsigned long n = 0;
        int i;
        for (i=8; i<= 11; i++) n = n * 256 + data[i];
        if (0x64==data[1]) {
            sprintf(res, "%02d-%02d-%02d %02d:%02d:%02d.%lu",
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]-1, n);
        } else {
            sprintf(res, "%d%02d-%02d-%02d %02d:%02d:%02d.%lu",
                ((data[1]>=100) ? (data[1]-100) : (100-data[1])),
                data[2]-100, data[3], data[4], data[5]-1, data[6]-1, data[7]-1, n);
        }
    } else {
        printf("not TIMESTAMP type\n");
        res[0] = '\0';
        /* *datalen���䣬����������������ֶ� */
        return 0;
    }

    *datalen = (data[0]+1);
    return strlen(res);
}

/* ������ֵ�����ֽ��ǳ���
   @info������Ϣ, @res��������, @datalen����data����, ���ؽ�������ֵ���ֳ���.
   �������ؽ��������. */
int parseColValue(unsigned char *data, int *datalen, COLUMN_INFO *info, char *res, int resMaxSize) {
    unsigned char *pos = data;
    char *resPos=res;
    int len, tmp, j, leftlen;

    if (0x60 == info->type || 0x01 == info->type) {
        /* 0x60:CHAR, NCHAR; 0x01:VARCHAR2, NVARCHAR */
        memset(bufForBigCharRebuid, 0, sizeof(bufForBigCharRebuid));

        leftlen = *datalen - (pos - data);
        tmp = parseCHAR(pos, &leftlen, bufForBigCharRebuid, sizeof(bufForBigCharRebuid)-1);
        pos += leftlen;
        if (tmp > 0) {
            if (0x02 == info->charWidth) {
                ucs2Swap(bufForBigCharRebuid, tmp);
                tmp = codeConv("UCS-2", "UTF-8", bufForBigCharRebuid, tmp, resPos, resMaxSize-strlen(res));
                if (tmp < 0) {
                    return TNS_SAVE;
                }
            } else if (0x01 == info->charWidth) {
                memcpy(resPos, bufForBigCharRebuid, tmp);
            }
            resPos += tmp;
        }
    } else if (0x02 == info->type) {
        /* 0x02: NUMBER, INTEGER, FLOAT */
        leftlen = *datalen - (pos - data);
        tmp = parseNUMBER(pos, &leftlen, resPos, resMaxSize-(resPos-res));
        pos += leftlen;
        resPos += tmp;
    } else if (0x64 == info->type) {
        /* 0x64: BINARY_FLOAT */
        len = *pos++;
        if ((unsigned char)*pos >= 0x80) *pos = *pos - 0x80;
        else setBitOpposite(pos, 8);
        sprintf(resPos, "%lf", getFloat32IEEE754(pos));
        resPos += strlen(resPos);
        pos += len;
    } else if (0x65 == info->type) {
        /* 0x65: BINARY_DOUBLE */
        len = *pos++;
        if ((unsigned char)*pos >= 0x80) *pos = *pos - 0x80;
        else setBitOpposite(pos, 8);
        sprintf(resPos, "%lf", getFloat64IEEE754(pos));
        resPos += strlen(resPos);
        pos += len;
    } else if (0x0c == info->type) {
        /* 0x0c: DATE */
        leftlen = *datalen - (pos - data);
        tmp = parseDATE(pos, &leftlen, resPos, resMaxSize-(resPos-res));
        pos += leftlen;
        resPos += tmp;
    }  else if (0xb4 == info->type) {
        /* 0xb4: TIMESTAMP */
        leftlen = *datalen - (pos - data);
        tmp = parseTIMESTAMP(pos, &leftlen, resPos, resMaxSize-(resPos-res));
        pos += leftlen;
        resPos += tmp;
    } else {
        len = *pos++;
        for (j=0; j<len; j++) {
            sprintf(resPos, "%02x", (unsigned char)pos[j]);
            resPos += 2;
        }
        pos += len;
    }

    *datalen = pos - data;
    return resPos-res;
}

int isInBitmap(char *bitmap, int i) {
    return ((0x1 << (i%8)) & bitmap[i/8]);
}

/* request = 03 2b, response = 08 0xnn, �ظ�����Ϣ
���� : 10g server, δ֪�ͻ���(�ɶ���������ҽԺ, �ն˷���)
*/
static int response_032B_08XX(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos, *pos22;
    int len, i;
    int totalColNum, curColNum;

    if (datalen < 47) return TNS_DEL;

    pos = data;
    totalColNum = pos[1] + pos[2]*256;
    curColNum = pos[3] + pos[4]*256;
    pos += 5;
    if (totalColNum<=0 || curColNum<=0 || totalColNum<=curColNum ) return -1;

    if (totalColNum > MAX_COLUMN) {
        printf("%d:too many column (%d)\n", __LINE__, totalColNum);
        return TNS_SAVE;
    }

    for (i=0; i<curColNum && pos<data+datalen; i++) {
    #if 0
        int iii;
        printf("%d: ------------------------------------\n", i);
        for (iii=0; iii<40; iii++) {
            printf("0x%02x ", (unsigned char)pos[iii]);
        }
        printf("\n");
    #endif
        colInfos[i].type = *pos++;
        pos += 23;

        /* CHAR,NCHAR,VARCHAR2,NVARCHAR���ַ���(1/2) */
        if (0x60 == colInfos[i].type || 0x01 == colInfos[i].type) {
            colInfos[i].charWidth = *pos;
        }
        pos += 15;
    }
    len = pos[0] + pos[1]*256;

    /* �������� */
    if (len+2 > datalen-(pos-data)) {
        len = datalen-(pos-data) - 2;
    }
    pos += 2;
    memcpy(res, pos, len);
    res[len] = '\0';

    for (i=0; i<curColNum && pos<data+datalen; i++) {
        pos22 = pos;
        while (*pos22 != 0x22 && pos22 <data+datalen) pos22++;
        if (pos22 >= data+datalen) break;
        if (pos22 != pos) {
            memcpy(colInfos[i].colName, pos, pos22-pos);
            colInfos[i].colName[pos22-pos] = '\0';
        }
        else {
            strcpy(colInfos[i].colName, "--");
        }
        pos = pos22+1;
    }
    if (i < curColNum) {
        for (; i<curColNum; i++) {
            strcpy(colInfos[i].colName, "--");
        }
    }

    char key[200];
    getColInfosKey(src_ip, src_port, dst_ip, dst_port, key);
    saveColInfos(key, colInfos, curColNum, totalColNum);

    return TNS_NORMAL;
}

/* request = 03 47, response = 06 02, �ظ���ֵ
���� : ODBC ���� 64bits oracle 10g server(�ɶ���������ҽԺ, �ն˷���)
*/
static int response_0347_0602(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos;
    char *resPos=res;
    int i, tmp, leftlen;
    int curColNum, totalColNum, seq;
    char bitmap[MAX_COLUMN/8+1];
    int bitmapSize;
    int bb;

    if (datalen < 16) return TNS_DEL;

    pos = data;
    totalColNum = pos[2] + pos[3]*256;
    memset(&prevRow, 0, sizeof(PREV_ROW_INFO));
    totalColInfoNum = MAX_COLUMN;
    getColInfos(src_ip, src_port, dst_ip, dst_port, colInfos, &totalColInfoNum);
    if (totalColInfoNum != totalColNum) {
        return TNS_SAVE;
    }
    for (i=0; i<totalColNum && pos<data+datalen; i++) {
        if (i != totalColNum-1) sprintf(resPos, "%s;:s", colInfos[i].colName);
        else sprintf(resPos, "%s;:n", colInfos[i].colName);
        resPos += strlen(resPos);
    }
    while (0x06==pos[0] && 0x02==pos[1] && pos<data+datalen) {
        line_num++;

        pos += 2;

        /* ��06 02��������, ������һ����ͬʱ��ȱ�� */
        curColNum = pos[0] + pos[1]*256;
        pos += 2;

        seq = pos[0] + pos[1]*256;
        pos += 2;

        if (0 == seq) {
            pos += 12;
            for (bb=0; bb<(totalColInfoNum/8+1); bb++) {
                bitmap[bb] = 0xff;
            }
        } else {
            pos += 8;
            bitmapSize = *pos++;
            memcpy(bitmap, pos, bitmapSize);
            pos += (bitmapSize + 4);
        }
        pos++;

        for (i=0; i<totalColNum && pos<data+datalen; i++) {
            if (!isInBitmap(bitmap, i)) {
                if (prevRow.colSizes[i]!=0) memcpy(resPos, prevRow.colValues[i], prevRow.colSizes[i]);
                resPos += prevRow.colSizes[i];
                if (i != totalColNum-1) strcpy(resPos, ";:s");
                else strcpy(resPos, ";:n");
                resPos += 3;
                continue;
            }
            prevRow.colValues[i] = resPos;

            if (0x00 == *pos) {
                /* 00 ff ff 00 00 */
                strcpy(resPos, "null");
                resPos += 4;
                pos += 3;
            } else if (0xff == *pos) {
                strcpy(resPos, "null");
                resPos += 4;
                while (0xff == *pos && pos<data+datalen) pos++;
            }else {
                leftlen = datalen - (pos - data);
                tmp = parseColValue(pos, &leftlen, colInfos+i, resPos, resMaxSize-(resPos-res));
                pos += leftlen;
                resPos += tmp;

                pos += 2;
            }
            prevRow.colSizes[i] = resPos - prevRow.colValues[i];
            if (i != totalColNum-1) strcpy(resPos, ";:s");
            else strcpy(resPos, ";:n");
            resPos += 3;
        }
    }
    return TNS_NORMAL;
}

/* request = 03 5e, response = 06 02, �ظ���ֵ
���� : 10g server, PL/sql developer(�ɶ���������ҽԺ)
*/
#define UNMEET_PKT 10
#define QINGYANG_PKT 1
#define HOME_PKT 2

static int response_035e_0602_qingyang(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos;
    char *resPos=res;
    int i, tmp, leftlen;
    int curColNum, seq;
    char bitmap[MAX_COLUMN/8+1];
    int bitmapSize;
    int bb;

    if (datalen < 16) return TNS_DEL;

    pos = data;
    while (0x06==pos[0] && 0x02==pos[1] && pos<data+datalen) {
        line_num++;

        pos += 2;

        /* ��06 02��������, λͼ����ʱ, ����С�ڲ�ѯ���� */
        curColNum = pos[0] + pos[1]*256;
        pos += 2;

        seq = pos[0] + pos[1]*256;
        pos += 2;

        if (0 == seq) {
            pos += 12;

            /* ��ȡ�и�ʽ, ��������� */
            totalColInfoNum = MAX_COLUMN;
            getColInfos(src_ip, src_port, dst_ip, dst_port, colInfos, &totalColInfoNum);
            if (totalColInfoNum != curColNum) {
                return TNS_SAVE;
            }

            /* ����λͼ */
            for (bb=0; bb<(totalColInfoNum/8+1); bb++) {
                bitmap[bb] = 0xff;
            }

            /* ��ʼ����һ������ */
            memset(&prevRow, 0, sizeof(PREV_ROW_INFO));

            /* ���ɱ�ͷ */
            for (i=0; i<totalColInfoNum && pos<data+datalen; i++) {
                if (i != totalColInfoNum-1) sprintf(resPos, "%s;:s", colInfos[i].colName);
                else sprintf(resPos, "%s;:n", colInfos[i].colName);
                resPos += strlen(resPos);
            }
        } else {
            pos += 8;
            bitmapSize = *pos++;
            memcpy(bitmap, pos, bitmapSize);
            pos += (bitmapSize + 4);
        }
        pos++;

        for (i=0; i<totalColInfoNum && pos<data+datalen; i++) {
            if (!isInBitmap(bitmap, i)) {
                if (prevRow.colSizes[i]!=0) memcpy(resPos, prevRow.colValues[i], prevRow.colSizes[i]);
                resPos += prevRow.colSizes[i];
                if (i != totalColInfoNum-1) strcpy(resPos, ";:s");
                else strcpy(resPos, ";:n");
                resPos += 3;
                continue;
            }
            prevRow.colValues[i] = resPos;

            if (0x00 == *pos) {
                /* 00 ff ff 00 00 */
                strcpy(resPos, "null");
                resPos += 4;
                pos += 5;
            } else if (0xff == *pos) {
                strcpy(resPos, "null");
                resPos += 4;
                while (0xff == *pos && pos<data+datalen) pos++;
                pos += 2;
            }else {
                leftlen = datalen - (pos - data);
                tmp = parseColValue(pos, &leftlen, colInfos+i, resPos, resMaxSize-(resPos-res));
                pos += leftlen;
                resPos += tmp;

                pos += 4;
            }
            prevRow.colSizes[i] = resPos - prevRow.colValues[i];
            if (i != totalColInfoNum-1) strcpy(resPos, ";:s");
            else strcpy(resPos, ";:n");
            resPos += 3;
        }
    }
    if (datalen-(pos-data) > 0 && memfind(pos, "ORA-01403", datalen-(pos-data), 9)) {
        isLast = 1;
    }
    return TNS_NORMAL;
}

/* oracle10g��oracle11g,
   Oracle sql developer 11g*/
static int response_035e_0602_home64bit10g(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos;
    char *resPos=res, bitmap[MAX_COLUMN/8+1];
    int colNum, i, tmp, leftlen;

    if (datalen < 16) return TNS_DEL;

    pos = data + 2;
    colNum = pos[0] + pos[1]*256;
    pos += 12;

    pos += (*pos+1);
    pos += (*pos+1);
    pos += (*pos+1);
    pos += (*pos+1);
    pos += 4;

    getColInfos(src_ip, src_port, dst_ip, dst_port, colInfos, &totalColInfoNum);
    if (colNum > totalColInfoNum) {
        #if TNS_DEBUG
        printf("(colNum(%d) > totalColInfoNum(%d))\n", colNum, totalColInfoNum);
        #endif
        return TNS_SAVE;
    }

    memset(&prevRow, 0, sizeof(PREV_ROW_INFO));
    int bb;
    for (bb=0; bb<(colNum/8+1); bb++) {
        bitmap[bb] = 0xff;
    }
    while (0x07 == *pos) {
#if 0
        printf("--------------------------------------------\n");
        int idx;
        for (idx=0; idx<20; idx++) {
            printf("%02x ", (unsigned char)pos[idx]);
        }
        printf("\n");
#endif
        pos++;
        line_num++;
        for (i=0; i<totalColInfoNum; i++) {
            #if 0
            printf("--------------------------------------------\n");
            int idx;
            for (idx=0; idx<20; idx++) {
                printf("%02x ", (unsigned char)pos[idx]);
            }
            printf("\n");
            printf("%s", res);
            printf("\n");
            #endif
            if (i>=colNum) {
                if (i != colNum-1) strcpy(resPos, ";:s");
                else strcpy(resPos, ";:n");
                continue;
            }

            if (!isInBitmap(bitmap, i)) {
                if (prevRow.colSizes[i]!=0) memcpy(resPos, prevRow.colValues[i], prevRow.colSizes[i]);
                resPos += prevRow.colSizes[i];
                if (i != colNum-1) strcpy(resPos, ";:s");
                else strcpy(resPos, ";:n");
                resPos += 3;
                continue;
            }

            prevRow.colValues[i] = resPos;
            if (0x00 == *pos) {
                strcpy(resPos, "null");
                resPos += 4;
                pos++;
            } else {
                leftlen = datalen - (pos - data);
                tmp = parseColValue(pos, &leftlen, colInfos+i, resPos, resMaxSize-(resPos-res));
                pos += leftlen;
                resPos += tmp;
            }
            prevRow.colSizes[i] = resPos - prevRow.colValues[i];
            if (i != colNum-1) strcpy(resPos, ";:s");
            else strcpy(resPos, ";:n");
            resPos += 3;
        }

        /* 0x15�ֶΣ�����һ�е����ݺͱ��ν����У�������ֵͬ����, ��������һ���о�ȱʧ�ˡ� */
        if (0x15 == *pos) {
            int bitmapSize = colNum%8==0 ? colNum/8 : colNum/8+1;
            pos += 3;
            memcpy(bitmap, pos, bitmapSize);
            pos += bitmapSize;
        } else if (0x07 == *pos){
            for (bb=0; bb<(colNum/8+1); bb++) {
                bitmap[bb] = 0xff;
            }
        } else {
            break;
        }
    }
    if (datalen-(pos-data) > 0 && memfind(pos, "ORA-01403", datalen-(pos-data), 9)) {
        printf("is last\n");
        isLast = 1;
    }
    return TNS_NORMAL;
}


static int response_035e_0602(unsigned char *data, long datalen, char *res, int resMaxSize) {
    if (datalen < 16) return TNS_DEL;

    if (0x07 == data[18]) flagLocation = QINGYANG_PKT;
    else flagLocation = HOME_PKT;

    if (QINGYANG_PKT == flagLocation)
        return response_035e_0602_qingyang(data, datalen, res, resMaxSize);
    else
        return response_035e_0602_home64bit10g(data, datalen, res, resMaxSize);
    return TNS_NORMAL;
}

static int response_0305_04XX(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos = data;
    char *resPos=res;
    int i;

    if (datalen < 16) return TNS_DEL;

    getColInfos(src_ip, src_port, dst_ip, dst_port, colInfos, &totalColInfoNum);

    for (i=0; i<totalColInfoNum && pos<data+datalen; i++) {
        if (i != totalColInfoNum-1) sprintf(resPos, "%s;:s", colInfos[i].colName);
        else sprintf(resPos, "%s;:n", colInfos[i].colName);
        resPos += strlen(resPos);
    }
    return TNS_NORMAL;
}

/* request = 03 5e, response = 10 17, sql��������, �ͻظ�����Ϣ
��ʱ03 5e��ǰ����1��11 6b��, ��Ҫ���ƫ�Ƶ�03 5e������
���� : 10g server, PL/sql developer(�ɶ���������ҽԺ)
�����06 02, ����Ž����������˳�
*/
static int response_035e_1017(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos;
    int colNum, i;
    int flagLocation = UNMEET_PKT; /* �������ķ������� */

    if (datalen < 34) return TNS_DEL;

    pos = data + (2 + 16 + 7 + 4); /* ����0x10 0x17 */

    /* ���� */
    colNum = pos[0] + pos[1]*256 + pos[2]*256*256 + pos[3]*256*256*256;
    pos += 4;
    if (colNum > MAX_COLUMN) {
        printf("%d:too many column (%d)\n", __LINE__, colNum);
        return TNS_SAVE;
    }
    totalColInfoNum = colNum;
    currentColInfoNum = colNum;

    pos++;

    /* ������ */
    for (i=0; i<colNum && pos<data+datalen; i++) {
        #if 0
        int iii;
        printf("%d: ------------------------------------\n", i);
        for (iii=0; iii<40; iii++) {
            printf("0x%02x ", (unsigned char)pos[iii]);
        }
        printf("\n");
        #endif

        /* ������ */
        colInfos[i].type = *pos++;
        pos++; /* δ֪, Ŀǰ����varchar2��char��clob��long�����г��֣�ֵΪ0x80 */

        /* NUMBER,FLOAT��precision��scale */
        colInfos[i].precision = *pos++;
        colInfos[i].scale = *pos++;
        colInfos[i].maxByteSize = pos[0] + pos[1]*256 + pos[2]*256*256 + pos[3]*256*256*256;
        pos += 4;

        pos += 16;

        colInfos[i].charWidth = *pos++; /* CHAR,NCHAR,VARCHAR2,NVARCHAR���ַ���(1/2) */

        if (UNMEET_PKT == flagLocation) {
            if (DATA_TYPE_VARCHAR2 == colInfos[i].type || DATA_TYPE_CHAR == colInfos[i].type) {
                if ((pos[0] + pos[1]*256 + pos[2]*256*256 + pos[3]*256*256*256) == colInfos[i].maxByteSize)
                    flagLocation = HOME_PKT;
                else
                    flagLocation = QINGYANG_PKT;
            } else {
                if (pos[1] == pos[2] && pos[1]!=0x0) flagLocation = QINGYANG_PKT;
                else flagLocation = HOME_PKT;
            }
        }

        if (HOME_PKT == flagLocation) {
            pos += 4;
        }

        colInfos[i].nullbit = *pos++;
        pos += 5;

        /* ���� */
        memcpy(colInfos[i].colName, pos+1, pos[0]);
        colInfos[i].colName[pos[0]] = '\0';
        pos += (1 + pos[0]); /* ����colName */

        pos += 8;

        if (HOME_PKT == flagLocation) {
            colInfos[i].seq = pos[0] + pos[1]*256;
            pos += 2;
        }
    }

    if (i < colNum) {
        return TNS_SAVE;
    }

    pos += 12;
    if (HOME_PKT == flagLocation) {
        pos += 16;
    }

    if (0x06==pos[0] && 0x02==pos[1]) {
        return response_035e_0602(pos, datalen-(pos-data), res, resMaxSize);
    }

    return TNS_NORMAL;
}

static int responseParserHelper(unsigned char *data, long datalen, char *res, int resMaxSize) {
    int tmp = -1;
    /* PL/sql developer7 ����64bit Oracle 10g */
    switch (pktType) {
        case PKT_035E__1017:
            tmp = response_035e_1017(data, datalen, res, resMaxSize); break;
        case PKT_035E__0602:
            tmp = response_035e_0602(data, datalen, res, resMaxSize); break;
        case PKT_035E__04XX:
            tmp = response_0305_04XX(data, datalen, res, resMaxSize); break;
        case PKT_035E__XXXX:
            tmp = -1; break;
        case PKT_0305__0602:
            tmp = response_035e_0602(data, datalen, res, resMaxSize); break;
        case PKT_0305__04XX:
            tmp = response_0305_04XX(data, datalen, res, resMaxSize); break;
        case PKT_034A__XXXX:
            tmp = -1; break;
        case PKT_032B__08XX:
            tmp = response_032B_08XX(data, datalen, res, resMaxSize); break;
        case PKT_0347__0602:
            tmp = response_0347_0602(data, datalen, res, resMaxSize); break;
        case PKT_0347__04XX:
            tmp = response_0305_04XX(data, datalen, res, resMaxSize); break;
        default:
            tmp = -1;
    }
    if (tmp < 0) unprintToSpace(data, datalen, res, resMaxSize);
    return TNS_NORMAL;
}

static int responseParser(unsigned char *data, long datalen, char *res, int resMaxSize) {
    int len;
    TNS_HEADER *tnsh = (TNS_HEADER *)data;
    if (tnsh->type != 0x06) {
        return TNS_DEL;
    }
    if (ntohs(tnsh->length) >= datalen) {
        return responseParserHelper(data+10, datalen-10, res, resMaxSize);
    }

    memset(bufForTnsRebuid, 0, sizeof(bufForTnsRebuid));
    len = tnsRebuild(data, datalen, bufForTnsRebuid, sizeof(bufForTnsRebuid)-1);
    return responseParserHelper(bufForTnsRebuid, len, res, resMaxSize);
}

/*======================================================================================*/
/* oracle10g��oracle11g,
   Oracle sql developer 11g*/
static int requestParserHelper(char *data, long datalen, char *res, int resMaxSize) {
    char *pos047fffffff, *pos;
    int sqlLen, tocopy;
    int offset, i, n;

    if (11 == oracleVersion) offset = 15;
    else if (10 == oracleVersion) offset = 10;
    else offset = 10;

    /* ��04 7F FF FF FF */
    pos047fffffff = memfind(data, "\x04\x7f\xff\xff\xff", datalen, 5);
    if(pos047fffffff) {
        pos = pos047fffffff + 5;
        pos ++;
        pos += ((unsigned char)*pos+1);
        pos += offset;
        if(pos >= (data+datalen)) {
            //printf("file length error  \n");
            return TNS_SAVE;
        }
    } else {
        if (0x03==(unsigned char)data[0] && 0x5e==(unsigned char)data[1]) {
            pos = data + 34;
            if(pos >= (data+datalen)) {
                //printf("%d:file length error\n", __LINE__);
                return TNS_DEL;
            }
        } else {
        /* 03 4A���������:
03 4A FD 01 00 00
00 3A 00 00 00 01 CF 00  00 00 00 00 00 00 00 01
01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00
00 00 00 00 (������0xcf�ֽڵ�����)73 65 6C 65  63 74 ...*/
            pos = data + 11;
            n = *pos++;
            sqlLen = 0;
            for (i=0; i<n; i++) {
                sqlLen = 256*sqlLen + (unsigned char)pos[i];
            }
            pos += n;
            pos += 29;
            if (pos >= data+datalen) {
                //printf("%d:file length error\n", __LINE__);
                return TNS_DEL;
            }
            tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize;
            strncpy(res, pos, tocopy);
            res[tocopy] = '\0';
            if (strlen(res) != tocopy) {
                return TNS_DEL;
            }
            return TNS_NORMAL;
        }
    }

    /* �����ֶ� */
    if (0xfe == (unsigned char)*pos) {
        segmentsReform(pos+1, res, &resMaxSize);
    } else {
        sqlLen = *pos;
        if (pos + sqlLen > data+datalen) {
            //printf("file length error\n");
            return TNS_SAVE;
        }
        tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize;
        strncpy(res, pos+1, tocopy);
        res[tocopy] = '\0';
    }
    return TNS_NORMAL;
}

static int requestParserHelper_64bitOracle10g(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos047fffffff, *pos, *pos035e, *pos034a;
    int sqlLen, tocopy;
    int offset, i;

    if (11 == oracleVersion) offset = 15;
    else if (10 == oracleVersion) offset = 10;
    else offset = 10;

#if TNS_DEBUG
    pos035e = memfind(data, "\x03\x5e", datalen, 2);
    if (pos035e) {
        pos = pos035e + 56;
        if (0xfe == (unsigned char)*pos) {
            segmentsReform(pos+1, res, &resMaxSize);
        } else {
            sqlLen = *pos;
            if (pos + sqlLen > data+datalen) {
                return TNS_SAVE;
            }
            tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize;
            strncpy(res, pos+1, tocopy);
            res[tocopy] = '\0';
        }
        return TNS_NORMAL;
    }
#endif

    /* ��04 7F FF FF FF */
    pos047fffffff = memfind(data, "\x04\x7f\xff\xff\xff", datalen, 5);
    if(pos047fffffff) {
        pos = pos047fffffff + 5;
        pos ++;
        pos += ((unsigned char)*pos+1);
        pos += offset;
        if(pos >= (data+datalen)) {
            //printf("file length error  \n");
            return TNS_SAVE;
        }
        /* �����ֶ� */
        if (0xfe == (unsigned char)*pos) {
            segmentsReform(pos+1, res, &resMaxSize);
        } else {
            sqlLen = *pos;
            if (pos + sqlLen > data+datalen) {
                //printf("file length error\n");
                return TNS_SAVE;
            }
            tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize-1;
            strncpy(res, pos+1, tocopy);
            res[tocopy] = '\0';
        }
        return TNS_NORMAL;
    } else {
        pos035e = memfind(data, "\x03\x5e", datalen, 2);
        if (pos035e) {
            pos = pos035e + 12;
            sqlLen = 0;
            for (i=3; i>=0; i--) {
                sqlLen += (sqlLen * 256 + pos[i]);
            }
            pos += 4;
            pos += 29;
            tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize-1;
            strncpy(res, pos, tocopy);
            res[tocopy] = '\0';
            return TNS_NORMAL;
        } else {
        /* 03 4A���������:
03 4A FD 01 00 00
00 3A 00 00 00 01 CF 00  00 00 00 00 00 00 00 01
01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00
00 00 00 00 (������0xcf�ֽڵ�����)73 65 6C 65  63 74 ...*/
            pos034a = memfind(data, "\x03\x4a", datalen, 2);
            if (pos034a) {
                pos = pos034a + 12;
                sqlLen = 0;
                for (i=3; i>=0; i--) {
                    sqlLen += (sqlLen * 256 + pos[i]);
                }
                pos += 4;
                pos += 26;
                tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize-1;
                strncpy(res, pos, tocopy);
                res[tocopy] = '\0';
                return TNS_NORMAL;
            } else {
                return TNS_SAVE;
            }
        }
    }
    return TNS_SAVE;
}


/* oracle 10g(10.2.0.4.0),
   NLS_CHARACTERSET = ZHS16GBK
   NLS_NCHAR_CHARACTERSET = AL16UTF16
   PL/sql developer 7.0.2.1076,  */
static int requestParserHelper_qingyang64bit10g_plsql(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos047fffffff, *pos, *pos035e, *pos034a;
    int sqlLen, tocopy;
    int offset, i;

    pos035e = memfind(data, "\x03\x5e", datalen, 2);
    if (pos035e) {
        pos = pos035e + 12;
        sqlLen = pos[0] + pos[1]*256 + pos[2]*256*256 + pos[3]*256*256*256;
        pos += (4 + 29);
        tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize-1;
        memcpy(res, pos, tocopy);
        res[tocopy] = '\0';
        return TNS_NORMAL;
    } else {
        return TNS_SAVE;
    }
}

static int requestParserHelper_home64bit10g_plsql(unsigned char *data, long datalen, char *res, int resMaxSize) {
    unsigned char *pos, *pos035e;
    int sqlLen, tocopy;

    pos035e = memfind(data, "\x03\x5e", datalen, 2);
    if (pos035e) {
        pos = pos035e + 56;
        if (0xfe == *pos) {
            segmentsReform(pos+1, res, &resMaxSize);
        } else {
            sqlLen = *pos;
            if (pos + sqlLen > data+datalen) {
                fprintf(stderr, "%d : sql length error\n", __LINE__);
                return TNS_SAVE;
            }
            tocopy = sqlLen<resMaxSize ? sqlLen : resMaxSize;
            memcpy(res, pos+1, tocopy);
            res[tocopy] = '\0';
        }
        return TNS_NORMAL;
    } else  {
        return TNS_SAVE;
    }
}

static int requestParser(unsigned char *data, long datalen, char *res, int resMaxSize) {
    int len;
    TNS_HEADER *tnsh = (TNS_HEADER *)data;

    if (ntohs(tnsh->length) >= datalen) {
        return requestParserHelper_64bitOracle10g(data+10, datalen-10, res, resMaxSize);
    }

    memset(bufForTnsRebuid, 0, sizeof(bufForTnsRebuid));
    len = tnsRebuild(data, datalen, bufForTnsRebuid, sizeof(bufForTnsRebuid)-1);
    return requestParserHelper_64bitOracle10g(bufForTnsRebuid, len, res, resMaxSize);
}

/*======================================================================================*/
void sigfun(int sig){
    switch(sig){
        case SIGINT:
        case SIGTERM:
        case SIGSEGV:
        case SIGBUS:
            unlink(filename_request);
            unlink(filename_response);
            exit(0);
            break;
        default:
            exit(0);
            break;
    }
}

/* ����'sqlStatement'��ĵ�һ�γ��ֵģ���������ķֺš� */
char *findNextSemicolon(char *sqlStatement) {
    char *pos;
    int singleQuoteFlag, doubleQuoteFlag;

    pos = sqlStatement;
    singleQuoteFlag = doubleQuoteFlag = 0;
    while (*pos != '\0') {
        if (';'==*pos && 0==singleQuoteFlag && 0==doubleQuoteFlag) {
            return pos;
        }

        /* ˫������ĵ����� */
        if ('\'' == *pos && 0==doubleQuoteFlag) {
            singleQuoteFlag = (1 == singleQuoteFlag) ? 0 : 1;
            pos ++; continue;
        }

        /* ���������˫���� */
        if ('"' == *pos && 0==singleQuoteFlag) {
            doubleQuoteFlag = (1 == doubleQuoteFlag) ? 0 : 1;
            pos ++; continue;
        }

        /* �����ڵ����� */
        if ('\\' == *pos && (1==doubleQuoteFlag || 1==singleQuoteFlag)) {
            if ('\'' == *(pos+1) || '"'==*(pos+1)) {
                pos += 2;
            } else {
                pos ++;
            }
            continue;
        }
        pos ++;
    }
    return NULL;
}

/* <1>���sql��ϣ�ÿ����÷ֺŷָ�
   <2>sql�����������(", ''"), ����һ��ʱҪ����
   <3>��ͷ��sql���䣬��β��ע�ͣ�Ҫ����ע��*/
int getHighestLevelSqlAction(char *sqlStatement) {
    char *start, *pos, actionWord[64];
    int tocopy, sqlLen, returnFlag;
    int sqlLevel = 0;

    sqlLen = strlen(sqlStatement);
    pos = sqlStatement;
    returnFlag = 19;
    while (pos < sqlStatement + sqlLen) {
        /* �ҵ�1�γ��ֵ���ĸ. �ù�����Ҫ����ע�� */
        while (!isalpha((int)*pos) && (pos < (sqlStatement+sqlLen))) {
            /* ����ע��. sqlserverע����2��/ * * /��ע�ͣ��Լ�--��ע�� */
            if ('/'==pos[0] && '*'==pos[1]) {
                pos = strstr(pos, "*/");
                if (!pos) return returnFlag;
                pos += 2;
            } else if ('-'==pos[0] && '-'==pos[1]) {
                pos = strchr(pos, '\n');
                if (!pos) return returnFlag;
                pos++;
            } else {
                pos++;
            }
        }
        start = pos;

        //�Ҹ���ĸ�����1�γ��ֵĿհ��ַ�, ��sql���ָ��(�ֺ�;)
        pos = strpbrk(start, " \r\n\t\f;");
        if (NULL == pos) {
            tocopy = (strlen(start) > (sizeof(actionWord)-1)) ? (sizeof(actionWord)-1) : strlen(start);
        } else {
            tocopy = ((pos-start) > (sizeof(actionWord)-1)) ? (sizeof(actionWord)-1) : (pos-start);
        }

        memcpy(actionWord, start, tocopy);
        actionWord[tocopy] = '\0';

        /* delete, insert, update, select ������4,3,2,1��������0 */
        if (strncasecmp(actionWord, "delete", strlen("delete")) == 0) return 8;
        if (strncasecmp(actionWord, "insert", strlen("insert")) == 0) {
            if (sqlLevel < 3) sqlLevel = 3;
        } else if (strncasecmp(actionWord, "update", strlen("update")) == 0) {
            if (sqlLevel < 2) sqlLevel = 2;
        } else if (strncasecmp(actionWord, "select", strlen("select")) == 0){
            if (sqlLevel < 1) sqlLevel = 1;
        }

        pos = findNextSemicolon(start);
        if (NULL == pos) break;
        pos++; /* �����ֺ�(;),������һ��sql */
    }

    switch (sqlLevel) {
        case 0: return 20;
        case 1: return 6;
        case 2: return 7;
        case 3: return 9;
        case 4: return 8;
    }
    return 20; /* ����������� */
}

int getTypeOfLocation(unsigned char *requestp, int requestlen, unsigned char *responsep, int responselen) {
    unsigned char *request = requestp+10;
    unsigned char *response = responsep+10;
    unsigned char *pos;

    if (requestlen<24 && responselen<24) return PKT_OTHER;

    /* �˴�����while��break����, �����Ҫ�ö��ص�if else, ��goto�ˣ��ѿ� */
    /* 11 69, 11 68, 11 6b�ȴ�ͷ�� */
    while (0x11 == request[0]) {
        int len = (requestlen-2 > 22) ? 22 : (requestlen-2);
        pos = memfind(request+2, "\x03\x5e", len, 2);
        if (pos) {
            request = pos;
            if ((0x03==request[0]  && 0x5e==request[1])) {
                if (0x10==response[0] && 0x17==response[1]) return PKT_035E__1017;
                return PKT_11XX_035E__1017;
            }
            break;
        }
        pos = memfind(request+2, "\x03\x05", len, 2);
        if (pos) {
            request = pos;
            break;
        }
        pos = memfind(request+2, "\x03\x4a", len, 2);
        if (pos) {
            request = pos;
            break;
        }
        pos = memfind(request+2, "\x03\x2b", len, 2);
        if (pos) {
            request = pos;
            break;
        }
        pos = memfind(request+2, "\x03\x47", len, 2);
        if (pos) {
            request = pos;
            break;
        }
        break;
    }

    /* sqlplus, PL/sql developer, oracle sql developer */
    if ((0x03==request[0]  && 0x5e==request[1])) {
        if (0x10==response[0] && 0x17==response[1]) return PKT_035E__1017;
        if (0x06==response[0] && 0x02==response[1]) return PKT_035E__0602;
        if (0x04==response[0]) return PKT_035E__04XX;
        return PKT_035E__XXXX;
    }

    /* 03 05����������� */
    if (0x03==request[0]  && 0x05==request[1]) {
        if (0x10==response[0] && 0x17==response[1]) return PKT_035E__1017;
        if (0x06==response[0] && 0x02==response[1]) return PKT_035E__0602;
        if (0x04==response[0]) return PKT_035E__04XX;
        return PKT_OTHER;
    }

    /* ODBC���� */
    if (0x03==request[0]  && 0x4a==request[1]) {
        return PKT_034A__XXXX;
    }

    if (0x03==request[0]  && 0x2b==request[1] && 0x08==response[0]) {
        return PKT_032B__08XX;
    }

    if (0x03==request[0]  && 0x47==request[1]) {
        if (0x06==response[0] && 0x02==response[1]) return PKT_0347__0602;
        if (0x04==response[0]) return PKT_0347__04XX;
    }

    return PKT_OTHER;
}

int getHexStr(char *data, int len, char *res, int resMaxSize) {
    int i, j;
    for (i=0, j=0; i<len && j<resMaxSize; i++, j+=3) {
        sprintf(res+j, "%02x ", data[i]);
    }
    return j;
}

/* read()�ķ�װ���ɹ����ض�ȡ���ֽ�����ʧ�ܷ���-1 */
ssize_t readBytes(int fd, void *buf, size_t n) {
    char *pos = buf;
    ssize_t nrd, nLeft=n;

    while (nLeft > 0) {
        if ( (nrd = read(fd, pos, nLeft)) < 0) {
            if (EINTR == errno) {
                nrd = 0;  /* �ٴε���read */
            } else {
                fprintf(stderr, "read() failed");
                return -1;
            }
        } else if (0 == nrd) {
            break; /* EOF */
        }
        nLeft -= nrd;
        pos += nrd;
    }
    return (n-nLeft);
}

/* ���ļ�'fileName'��'len'�ֽڵ�'buf'.
   ���سɹ������ֽ���, ʧ�ܷ���-1 */
ssize_t readFile(char *fileName, void *buf, size_t n) {
    char *pos = buf;
    int fd, nrd;

    fd = open(fileName, O_RDONLY);
    if (fd < 0) { fprintf(stderr, "Fails to open the file(%s)", fileName); return -1; }
    if ((nrd = readBytes(fd, pos, n)) < 0) { fprintf(stderr, "Fails to read the file(%s)", fileName); return -1; }
    close(fd);
    return nrd;
}

#if TNS_DEBUG
int setUsername_0376(unsigned char *data, int len) {
    unsigned char *pos = data+ (10 + 3);
    char username[512] = {0};
    char key[128] = {0};

    if (0xfe == *pos) pos += 4;
    else pos++;

    pos += 8;

    if (0xfe == *pos) pos += 4;
    else pos++;

    pos += 4;

    if (0xfe == *pos) pos += 4;
    else pos++;
    if (0xfe == *pos) pos += 4;
    else pos++;

    memcpy(username, pos+1, *pos);
    username[*pos] = '\0';

    redisContext *conn = NULL;
    redisReply *reply =NULL;

    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    getUsernameKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 86400", key, username);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    #if TNS_DEBUG
    printf("setUsername_0376: username=%s, key=%s\n", username, key);
    #endif

    return 0;
}
#else
int setUsername_0376(unsigned char *data, int len) {
    unsigned char *pos = data+ (10 + 4);
    char username[512] = {0};
    char key[128] = {0};
    int sqllen;

    sqllen = *pos;
    pos += 15;

    memcpy(username, pos, len);
    username[len] = '\0';

    redisContext *conn = NULL;
    redisReply *reply =NULL;

    conn = redisConnect(REDISSERVERHOST, REDISSERVERPORT);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        redisFree(conn);
        conn=NULL;
        return -1;
    }

    reply =(redisReply*)redisCommand(conn,"select %d", REDIS_ORACLE_TABLE);
    if(conn->err) {
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);//free reply

    getUsernameKey(src_ip, src_port, dst_ip, dst_port, key);
    reply = (redisReply*)redisCommand(conn, "set %s %s EX 86400", key, username);
    if(conn->err){
        fprintf(stderr,"error %d:%s\n",conn->err, conn->errstr);
        if(reply){
            freeReplyObject(reply);
            return 0;
        }
        redisFree(conn);
    }
    freeReplyObject(reply);
    redisFree(conn);
    reply = NULL;

    #if TNS_DEBUG
    printf("setUsername_0376: username=%s, key=%s\n", username, key);
    #endif

    return 0;
}
#endif

#if 1
unsigned char requestBuf[2*1024*1024], responseBuf[2*1024*1024];
//int main(int argc,char **argv) {
int mainoracle(char *filePath, ORACLE_SHM_MEM *sharedm){
    unsigned char *requestp = requestBuf, *responsep = responseBuf;
    char  tempstr[2048];
    unsigned long capture_time;
    int requestLen, responseLen, len, dir_id, tmpret, i;
    unsigned int hash;
    int app_id;
    int app_type, version, seqid;
    char *resPos, src_mac[24], dst_mac[24];

    isLast = 0;
    line_num = 0;
    memset(bufForColValuestmp, 0, sizeof(bufForColValuestmp));
    memset(colInfos, 0, sizeof(COLUMN_INFO)*MAX_COLUMN);
    oracleVersion = 10;
    totalColInfoNum = 0;
    currentColInfoNum = 0;

/*
    signal(SIGINT, sigfun);
    signal(SIGTERM, sigfun);
    signal(SIGSEGV, sigfun);

    if(argc!=2) {
        printf("Usage:%s <FILENAME>\n",argv[0]);
        return -1;
    }
*/
    /* �����ļ���
    strcpy(filename_request, argv[1]);*/
    strcpy(filename_request, filePath);
    len = strlen(filename_request);
    strncpy(tempstr, filename_request, len-7);
    tempstr[len-7] = '\0';
    sprintf(filename_response, "%sresponse", tempstr);

    /* ���ڶδ���ʱɾ���ļ� */
    sprintf(cmdRmRequest, "rm -f %s", filename_request);
    sprintf(cmdRmResponse, "rm -f %s", filename_response);

    /* �ȶ��ļ�, ��֤request��response�����ڲŽ��� */
    requestLen = readFile(filename_request, requestBuf, sizeof(requestBuf)-1);
    if (requestLen < 0) {
        deleteFile(filename_request, filename_response);
        return -1;
    }
    if (requestp[4] != PKT_TYPE_DATA) {
        deleteFile(filename_request,filename_response);
        return 0;
    }

    responseLen = readFile(filename_response, responseBuf, sizeof(responseBuf)-1);
    if (requestLen < 0) {
        deleteFile(filename_request, filename_response);
        return -1;
    }

    long requestCaptureTime = getFileTime(filename_request);
    long responseCaptureTime = getFileTime(filename_response);
    long tmpdif = requestCaptureTime - responseCaptureTime;
    unsigned long interval_time = (tmpdif < 0) ? (-tmpdif) : tmpdif;

    deleteFile(filename_request, filename_response);

#if TNS_DEBUG
    printf("=========================================================\n");
    printf("request = %02x %02x, response = %02x %02x\n", requestBuf[10], requestBuf[11], responseBuf[10], responseBuf[11]);
#endif

    tmpret=sscanf(filename_request,
    "/dev/shm/oracle/%d/%lu_%u_%d_%u_%12[^_]_%u_%u_%12[^_]_%u_%d_%d_request",
    &dir_id, &capture_time, &hash, &app_type, &src_ip, src_mac, &src_port, &dst_ip, dst_mac, &dst_port, &version, &seqid);

    checkOldList(sharedm);

    /* version=30_..��10g�汾�� 31_...��11g�汾 */
    if (30 == version) oracleVersion = 10;
    else if (31 == version) oracleVersion = 11;
    else {
        fprintf(stderr, "unknown version (%d)\n", version);
        return -1;
    }

    /* �û��� */
    if (0x03==requestp[10] && 0x76==requestp[11]) {
        #if TNS_DEBUG
        printf("clean111111\n");
        #endif
        shmDelOneRecod(sharedm, hash, src_ip, src_port, dst_ip, dst_port);
        setUsername_0376(requestp, requestLen);
        #if TNS_DEBUG
        printf("ruku username: request=%s\n", sql_str);
        #endif
        writeDBfile(dir_id, capture_time, 20, src_ip, src_port, src_mac, dst_ip, dst_port, dst_mac, 0, 0, sql_str, "");
        return 0;
    }

    /* �����������,�ظ���, ��ʾ��select�غϽ��� */
    if ((0x03==requestp[10] && 0x05==requestp[11] && 0x04==responsep[10])
        || (0x03==requestp[10] && 0x5E==requestp[11] && 0x04==responsep[10])) {
        #if TNS_DEBUG
        printf("clean22222\n");
        #endif
        shmDelOneRecod(sharedm, hash, src_ip, src_port, dst_ip, dst_port);
        return 0;
    }

    pktType = getTypeOfLocation(requestp, requestLen, responsep, responseLen);
    if (PKT_OTHER == pktType) {
        return 0;
    }

    /* ����request */
    memset(sql_str, 0, sizeof(sql_str));
    if (0x11 == requestp[10] || (0x03 == requestp[10] && 0x5E==requestp[11])) {
        tmpret = requestParser(requestp, requestLen, sql_str, sizeof(sql_str)-1);
        if (tmpret < 0) {
            memset(sql_str, 0, sizeof(sql_str));
            unprintToSpace(requestp+10, requestLen-10, sql_str, sizeof(sql_str)-1);
        }
    } else {
        unprintToSpace(requestp+10, requestLen-10, sql_str, sizeof(sql_str)-1);
    }
    app_id = getHighestLevelSqlAction(sql_str);

    #if TNS_DEBUG
    if (app_id != 6 && 0x11==requestp[10] && 0x10==responsep[10] && 0x17==responsep[11]) {
        int zz;
        for (zz=10; zz<requestLen; zz++)
            fprintf(stderr, "%02x ", (unsigned char)requestp[zz]);
        fprintf(stderr, "\n");
    }

    #endif

    /* ����response */
    memset(response_str, 0, sizeof(response_str));
    if ((0x10==responsep[10] && 0x17==responsep[11])
        || (0x06==responsep[10] && 0x02==responsep[11])
        || (0x03==requestp[10] && 0x2b==requestp[11] && 0x08==responsep[10])) {
        tmpret = responseParser(responsep, responseLen, response_str, sizeof(response_str)-1);
        if (tmpret < 0) {
            memset(response_str, 0, sizeof(response_str));
            unprintToSpace(responsep+10, responseLen-10, response_str, sizeof(response_str)-1);
        }
    } else {
        unprintToSpace(responsep+10, responseLen-10, response_str, sizeof(response_str)-1);
    }

//===========================================================================
    /* ����select�׻غ� */
    memset(bufForColValuesmain, 0, sizeof(bufForColValuesmain));
    resPos = bufForColValuesmain;
    for (i=0; i<totalColInfoNum; i++) {
        if (i != totalColInfoNum-1) sprintf(resPos, "%s;:s", colInfos[i].colName);
        else sprintf(resPos, "%s;:n", colInfos[i].colName);
        resPos += strlen(resPos);
    }
    strcpy(resPos, response_str);

    if (6 == app_id && 0x10==responsep[10] && 0x17==responsep[11]) {
        #if TNS_DEBUG
        printf("clean33333\n");
        #endif
        shmDelOneRecod(sharedm, hash, src_ip, src_port, dst_ip, dst_port);
        /* ���γ�������, �����ֵ�� */
        if (isLast) {
            #if TNS_DEBUG
            printf("ruku111: 1017 request = %s\nresponse=%s\nresponse_str=%s\n", sql_str, bufForColValuesmain,response_str);
            #endif
            /* select�׻غϴ�����, ��дredis�� */
            writeDBfile(dir_id, capture_time, app_id, src_ip, src_port, src_mac, dst_ip, dst_port, dst_mac, interval_time, line_num, sql_str, bufForColValuesmain);
        } else {
            /* select, ����Ϣ, ������, ��ֵ��(�еĻ�)����д�� */
            #if TNS_DEBUG
            printf("save1017  request = %s\nresponse=%s\n", sql_str, bufForColValuesmain);
            #endif
            saveSelectColInfosColValues(sharedm,
                hash, src_ip, src_port, src_mac, dst_ip, dst_port, dst_mac, capture_time, requestCaptureTime, responseCaptureTime, line_num, dir_id,
                sql_str,
                colInfos, totalColInfoNum, totalColInfoNum,
                "", bufForColValuesmain);
        }
        return 0;
    } else if (0x06==responsep[10] && 0x02==responsep[11]){
        if (exists(sharedm, hash, src_ip, src_port, dst_ip, dst_port)) {
            if (isLast) {
                #if TNS_DEBUG
                printf("ruku222: 0602 request=%s\nrespones=%s\n", sql_str, response_str);
                #endif
                shmDelOneRecodWithLastColValues(sharedm, hash, src_ip, src_port, dst_ip, dst_port, response_str, line_num, capture_time, responseCaptureTime);
            } else {
                #if TNS_DEBUG
                printf("save0602 request=%s\nrespones=%s\n", sql_str, response_str);
                #endif
                saveColValues(sharedm, hash, src_ip, src_port, dst_ip, dst_port, NULL, response_str, line_num, capture_time, responseCaptureTime);
            }
            return 0;
        } else {
            #if TNS_DEBUG
            printf("ruku333 0602=%s\n", response_str);
            #endif
            writeDBfile(dir_id, capture_time, 6,
                        src_ip, src_port, src_mac,
                        dst_ip, dst_port, dst_mac,
                        interval_time, line_num, sql_str, bufForColValuesmain);
            return 0;
        }
    } else {
        #if TNS_DEBUG
        printf("other clean\n");
        #endif
        shmDelOneRecod(sharedm, hash, src_ip, src_port, dst_ip, dst_port);
    }

//===========================================================================
    if (20 == app_id) {
        trim(response_str);
        trim(sql_str);
        if (strlen(response_str)<20 && strlen(sql_str)<20) {
            #if TNS_DEBUG
            printf("other not ruku\n");
            #endif
            return 0;
        }
    }

    /* ODBC */
    if (31 == app_type) {
        app_id = 31;
    }

#if 0
    /* ����ƥ��
       ע: ����ƥ�����ŵ�response�������, ��Ϊresponse��ı�app_id��ֵ */
    CACHE_POLICY_CONF *policy = (CACHE_POLICY_CONF*)get_audit_cache_policy_shm();
    if(NULL == policy){
        printf("Fails to get CACHE_POLICY_CONF");
        return 0;
    }
    sprintf(zinfo.cspHead.policytime, "%d", getPolicyTime(capture_time));
    struct in_addr in;
    char src_ip_str[30] = {0};
    in.s_addr=src_ip;
    strcpy(src_ip_str, inet_ntoa(in));
    strcpy(zinfo.cspHead.userip, src_ip_str);
    zinfo.type = app_id;
    if (0 == policy_match(&zinfo, policy)) {
        return 0;
    }
#endif

    /* д����ļ� */
    #if TNS_DEBUG
    printf("ruku other(%d): request=%s\n respnose=%s\n", app_id, sql_str, response_str);
    #endif
    writeDBfile(dir_id, capture_time, app_id, src_ip, src_port, src_mac, dst_ip, dst_port, dst_mac, interval_time, line_num, sql_str, response_str);

    return 0;
}
#else

char buf1[10000] = {0};

int main() {

#if 0
    pktType = PKT_035E__1017;
    memset(buf1, 0, sizeof(buf1));
    responseParser(peer1_1017, sizeof(peer1_1017), buf1, sizeof(buf1)-1);
    printf("----------------------------------\nn=%d\n%s\n", n, buf1);

    pktType = PKT_035E__0602;
    memset(buf1, 0, sizeof(buf1));
    responseParser(peer1_0602, sizeof(peer1_0602), buf1, sizeof(buf1)-1);
    printf("----------------------------------\nn=%d\n%s\n", n, buf1);


    pktType = PKT_035E__1017;
    memset(buf1, 0, sizeof(buf1));
    responseParser(peer2_1017, sizeof(peer2_1017), buf1, sizeof(buf1)-1);
    printf("----------------------------------\nn=%d\n%s\n", n, buf1);

    pktType = PKT_035E__0602;
    memset(buf1, 0, sizeof(buf1));
    responseParser(peer2_0602, sizeof(peer2_0602), buf1, sizeof(buf1)-1);
    printf("----------------------------------\nn=%d\n%s\n", n, buf1);
#endif
    return 0;
}

#endif
