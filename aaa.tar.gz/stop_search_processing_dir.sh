#!/bin/bash

killall search_processing_dir
