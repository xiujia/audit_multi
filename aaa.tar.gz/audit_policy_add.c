#include "audit_policy.h"
#include "../policy/policy.h"
#include "../include/inp.h"

int main(){
	
	return audit_policy_add();
}
