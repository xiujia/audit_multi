#!/bin/bash

cd ./build
rm -f *.tar.gz
tar czvf bin.tar.gz *

