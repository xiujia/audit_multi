#ifndef _CHUNK_H
#define _CHUNK_H


char * dechunk( char * pucChunkBuff, char * pucDechunkBuff,unsigned long * piDechunkLen,int pucChunkBuffLen,unsigned long lenMax);




#endif
