#include <sys/types.h>
#include <dirent.h>
#include <sys/time.h>
#include <unistd.h>
/* MongoDB���ݿ�Ľӿڷ�װ
   URI�ĸ�ʽ(http://docs.mongodb.org/manual/reference/connection-string/)
   mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]
   gcc -o audit_mongo_insert audit_mongo_insert.c $(pkg-config --cflags --libs libmongoc-1.0) -Wall -g
*/

#include <bson.h>
#include <bcon.h>
#include <mongoc.h>
#include <stdio.h>

#define HOST "localhost"
#define POST "27017"
#define URI "mongodb://localhost:27017/"
#define DB_NAME "mongoDB"

#define DEBUG_OPEN 1
#if DEBUG_OPEN
#define DEBUG_LOG(s) fprintf(stderr, "<%s>:%d:%s\n", __FILE__, __LINE__, (s))
#else
#define DEBUG_LOG(s)
#endif
#define PRINT_ERR_MSG(s) fprintf(stderr, "<%s>:%d:%s\n", __FILE__, __LINE__, (s))

typedef struct __MONGO {
    mongoc_client_t *client;
    mongoc_collection_t *collection;
    mongoc_cursor_t *cursor;
    bson_error_t error;
} MONGO;

#define THREAD_NUM 10
#define LINE_LEN 10000
#define KEY_LEN 100
#define VALUE_LEN 1000

#define CACHE_TABLE_NAME_PREFIX		"cache_monitor_data_"
#define CACHE_PORTAL_TELNET_PREFIX	"cache_portal_telnet_data_"
#define SQLSERVER_TABLE_NAME_PREFIX "sqlserver_monitor_data_"
#define AUDIT_FILE_PATH			    "/data/audit/sql/"
char tmpbuf[10*1024*1024];
char line[10240];
char pair[10240];

struct keyValues {
    char table[256];
    unsigned long capture_time; //ʱ��ĺ��뼶����
    char app_id[32];
    char src_ip[32];
    char src_mac[32];
    char src_port[32];
    char dst_ip[32];
    char dst_mac[32];
    char dst_port[32];
    char department[1024];
    char web_session[1024];
    char user_name[1024];
    char web_url[5000];
    char operation_command[1024*1024*2];
    char web_content[1024];
    char operation_sql[1024];
    char user_id[32];
    char response_content[1024*1024*2];
    char tform[1024];
    char level_1[1024];
    char alarm_id[1024];
    char process_state[1024];
    char file_content[1024*1024*2];
    char saveflag[8];
    char charset[32];

    long request_len;
    long response_len;
    long file_content_len;
};

struct keyValues KVs, tmpKVs;

int mongoConnect(MONGO *mongo) {
    mongoc_init ();
    mongo->client = mongoc_client_new (URI);
    if (NULL == mongo->client) {
      PRINT_ERR_MSG("Failed to parse URI.\n");
      return -1;
    }
    return 0;
}

int mongoUseCollection(MONGO *mongo, char *dbName, char *collectionName) {
    mongo->collection = mongoc_client_get_collection (mongo->client, dbName, collectionName);
    return 0;
}

#if 0
int localTimeDhcc(unsigned long usUTC, unsigned long *usLocal) {
    struct timeval a;
    gettimeofday(&a, NULL);

    *usLocal = a.tv_sec * 1000 + a.tv_usec/1000 ;
    return 0;
}
#endif

/*
private long capture_time; //ʱ��ĺ��뼶����
	private String app_id;
	private String src_ip;
	private String src_mac;
	private String src_port;
	private String dst_ip;
	private String dst_mac;
	private String dst_port;
	private String department;
	private String web_session;
	private String user_name;
	private String web_url;
	private String web_url_id;
	private String operation_command;
	private String web_content;
	private String operation_sql;
	private String user_id;
	private String response_content;
	private String tform;
	private String level_1;
	private String alarm_id;
	private String process_state;
	private String file_content;
*/
int mongoMultipleInsert(MONGO *mongo, struct keyValues *kvs) {
    bson_error_t error;
    bson_oid_t oid;
    bson_t *doc;

    doc = bson_new ();
    bson_oid_init (&oid, NULL);
    BSON_APPEND_OID (doc, "_id", &oid);
    BSON_APPEND_INT64 (doc, "capture_time",  kvs->capture_time);
    BSON_APPEND_UTF8 (doc, "app_id",  kvs->app_id);
    BSON_APPEND_UTF8 (doc, "src_ip",  kvs->src_ip);
    BSON_APPEND_UTF8 (doc, "src_mac",  kvs->src_mac);
    BSON_APPEND_UTF8 (doc, "src_port",  kvs->src_port);
    BSON_APPEND_UTF8 (doc, "dst_ip",  kvs->dst_ip);
    BSON_APPEND_UTF8 (doc, "dst_mac",  kvs->dst_mac);
    BSON_APPEND_UTF8 (doc, "dst_port",  kvs->dst_port);
    BSON_APPEND_UTF8 (doc, "department",  kvs->department);
    BSON_APPEND_UTF8 (doc, "web_session",  kvs->web_session);
    BSON_APPEND_UTF8 (doc, "user_name",  kvs->user_name);
    BSON_APPEND_UTF8 (doc, "web_url",  kvs->web_url);
    BSON_APPEND_UTF8 (doc, "operation_command",  kvs->operation_command);
    BSON_APPEND_UTF8 (doc, "web_content",  kvs->web_content);
    BSON_APPEND_UTF8 (doc, "operation_sql",  kvs->operation_sql);
    BSON_APPEND_UTF8 (doc, "user_id",  kvs->user_id);
    BSON_APPEND_BINARY (doc, "response_content", BSON_SUBTYPE_BINARY, (uint8_t *)(kvs->response_content), kvs->response_len);
    BSON_APPEND_UTF8 (doc, "tform",  kvs->tform);
    BSON_APPEND_UTF8 (doc, "level_1",  kvs->level_1);
    BSON_APPEND_UTF8 (doc, "alarm_id",  kvs->alarm_id);
    BSON_APPEND_UTF8 (doc, "process_state",  kvs->process_state);
    BSON_APPEND_BINARY (doc, "file_content", BSON_SUBTYPE_BINARY, (uint8_t *)(kvs->file_content), kvs->file_content_len);
    BSON_APPEND_UTF8 (doc, "saveflag",  kvs->saveflag);
    BSON_APPEND_UTF8 (doc, "charset",  kvs->charset);

    if (!mongoc_collection_insert (mongo->collection, MONGOC_INSERT_NONE, doc, NULL, &error)) {
        printf ("%s\n", error.message);
        if (mongoConnect(mongo) < 0) {
            return -1;
        }
        if (!mongoc_collection_insert (mongo->collection, MONGOC_INSERT_NONE, doc, NULL, &error)) {
            printf ("%s\n", error.message);
            exit(-1);
        }
    }

    bson_destroy (doc);
    return 0;
}

int mongoClose(MONGO *mongo) {
	if (mongo->collection) mongoc_collection_destroy (mongo->collection);
	if (mongo->client) mongoc_client_destroy (mongo->client);
	return 0;
}

/* ��ȡ�ļ���С�������ļ���С��ʧ�ܷ���-1
   ע�� - ������������Ϊunsigned longʱ������ӦΪ����-1�ķ���ֵ*/
long getFileSize(const char *fileName) {
    struct stat buf;
    if (NULL==fileName) { PRINT_ERR_MSG("Incorrect parameter"); return -1; }
    if(stat(fileName, &buf)<0) { PRINT_ERR_MSG("Failed to get state of the file"); return -1; }
    return (long)buf.st_size;
}

#if 1
int pairParse(char *pair, struct keyValues *kv){
    char name[64], value[1024];

    value[0] = name[0] = '\0';
    sscanf(pair, "%[^=]=%s", name, value);
    if (strcmp(name, "rowkey") == 0) {
        sscanf(value, "%lu", &kv->capture_time);
    } else if (strcmp(name, "table") == 0) {
        strcpy(kv->table, value);
    } else if (strcmp(name, "app_id") == 0) {
        strcpy(kv->app_id, value);
    } else if (strcmp(name, "src_ip") == 0) {
        strcpy(kv->src_ip, value);
    } else if (strcmp(name, "src_mac") == 0) {
        strcpy(kv->src_mac, value);
    } else if (strcmp(name, "src_port") == 0) {
        strcpy(kv->src_port, value);
    } else if (strcmp(name, "dst_ip") == 0) {
        strcpy(kv->dst_ip, value);
    } else if (strcmp(name, "dst_mac") == 0) {
        strcpy(kv->dst_mac, value);
    } else if (strcmp(name, "dst_port") == 0) {
        strcpy(kv->dst_port, value);
    } else if (strcmp(name, "department") == 0) {
        strcpy(kv->department, value);
    } else if (strcmp(name, "web_session") == 0) {
        strcpy(kv->web_session, value);
    } else if (strcmp(name, "user_name") == 0) {
        strcpy(kv->user_name, value);
    } else if (strcmp(name, "web_url") == 0) {
        strcpy(kv->web_url, value);
    } else if (strcmp(name, "operation_command") == 0) {
        strcpy(kv->operation_command, value);
    } else if (strcmp(name, "web_content") == 0) {
        strcpy(kv->web_content, value);
    } else if (strcmp(name, "operation_sql") == 0) {
        strcpy(kv->operation_sql, value);
    } else if (strcmp(name, "user_id") == 0) {
        strcpy(kv->user_id, value);
    } else if (strcmp(name, "response_content") == 0) {
        strcpy(kv->response_content, value);
    } else if (strcmp(name, "tform") == 0) {
        strcpy(kv->tform, value);
    } else if (strcmp(name, "level_1") == 0) {
        strcpy(kv->level_1, value);
    } else if (strcmp(name, "alarm_id") == 0) {
        strcpy(kv->alarm_id, value);
    } else if (strcmp(name, "process_state") == 0) {
        strcpy(kv->process_state, value);
    } else if (strcmp(name, "file_content") == 0) {
        strcpy(kv->file_content, value);
    } else if (strcmp(name, "saveflag") == 0) {
        strcpy(kv->saveflag, value);
    } else if (strcmp(name, "charset") == 0) {
        strcpy(kv->charset, value);
    }
    return 0;
}

int LineParse(char *line, struct keyValues *kv) {
    char *start, *end;
    int tocopy;

    memset(kv, 0, sizeof(struct keyValues));

    start = strstr(line, "rowkey");
    if (NULL == start) {
        return -1;
    }
    end = strstr(start, "|colfam");
    if (NULL == end) {
        return -1;
    }
    tocopy = ((end-start) >= sizeof(pair)) ? sizeof(pair) : (end-start);
    memcpy(pair, start, tocopy);
    pair[tocopy] = 0;

    pairParse(pair, kv);

    start = end + strlen("|colfam");
    while ((end = strstr(start, "|colfam")) != NULL) {
        start += 2;
        tocopy = ((end-start) >= sizeof(pair)) ? sizeof(pair) : (end-start);
        memcpy(pair, start, tocopy);
        pair[tocopy] = 0;
        pairParse(pair, kv);
        start = end + strlen("|colfam");
    }
    return 0;
}
#endif

#define APP_ID_HIS 1
#define APP_ID_SUPERSERVER 2
#define APP_ID_TELNET 3
#define APP_ID_PORTAL 4
#define APP_ID_FTP 5
#define APP_ID_SQLSERVER_SELECT 6
#define APP_ID_SQLSERVER_UPDATE 7
#define APP_ID_SQLSERVER_DELETE 8
#define APP_ID_SQLSERVER_INSERT 9
#define APP_ID_SQLSERVER_CREATE 10
#define APP_ID_SQLSERVER_DROP 11
#define APP_ID_SQLSERVER_PRE_LOGIN 12
#define APP_ID_SQLSERVER_LOGIN 13
#define APP_ID_SQLSERVER_FAT 14
#define APP_ID_SQLSERVER_BULK_LOAD 15
#define APP_ID_SQLSERVER_RPC 16
#define APP_ID_SQLSERVER_ATTENTION 17
#define APP_ID_SQLSERVER_TMR 18
#define APP_ID_SQLSERVER_OTHER 19
#define APP_ID_SQLSERVER_SSPI 20

int getKeyValues(MONGO *conn, char *data, long contentLen) {
    char *pos=NULL, *start=NULL, *end=NULL;
    int lineLen=0, tmpLen=0;
    int operate_len = 0;
    char tableName[256];
    int type=0, tocopy;
    unsigned long tmpTime;

    pos = start = data;
    while((end = strstr(pos, "|colfam\n"))) {
        end += 8;
        lineLen = end - pos;
        if (lineLen <= 0) {
            PRINT_ERR_MSG("end - pos < 0");
            break;
        } else if (lineLen >= sizeof(line)) {
            PRINT_ERR_MSG("No enough space in @line");
            break;
        }
        memcpy(line, pos, lineLen);
        line[lineLen]='\0';

        memset(&KVs, 0, sizeof(struct keyValues));
        LineParse(line, &KVs);
        tmpTime = KVs.capture_time;
        KVs.capture_time /= 1000;
#if DEBUG_OPEN
fprintf(stderr, "****************************************************************************\n"
                "<%s>:%d:line = %s\n"
                "table=%s, capture_time=%lu, tmpTime=%lu, app_id=%s,\n"
                "src_ip=%s, src_mac=%s, src_port=%s, dst_ip=%s, dst_mac=%s, dst_port=%s,\n"
                "department=%s, web_session=%s, user_name=%s, web_url=%s,\n"
                "operation_command=%s, web_content=%s, operation_sql=%s, user_id=%s,\n"
                "response_content=%s, tform=%s, level_1=%s, alarm_id=%s, process_state=%s,\n"
                "file_content=%s, saveflag=%s, charset=%s\n"
                "****************************************************************************\n",
                __FILE__, __LINE__, line,
                KVs.table, KVs.capture_time, tmpTime, KVs.app_id,
                KVs.src_ip, KVs.src_mac, KVs.src_port, KVs.dst_ip, KVs.dst_mac, KVs.dst_port,
                KVs.department, KVs.web_session, KVs.user_name, KVs.web_url,
                KVs.operation_command, KVs.web_content, KVs.operation_sql, KVs.user_id,
                KVs.response_content, KVs.tform, KVs.level_1, KVs.alarm_id, KVs.process_state,
                KVs.file_content, KVs.saveflag, KVs.charset);
#endif
        type = atoi(KVs.app_id);

        /* sqlserver, cache_superserver */
        if (type >= APP_ID_SQLSERVER_SELECT || APP_ID_SUPERSERVER == type) {
            operate_len = atoi(KVs.operation_command);
            pos = end;
            end += ( operate_len + 1);

            /* ���������һ�У��������������"rowkey="��ͷ */
            tmpLen = end - start;
            if(tmpLen != contentLen) {
                if(strncmp(end, "rowkey=", 7) != 0){
                    fprintf(stderr, "endStr != rowkey(end[0-3]=%c%c)\n", end[0],end[1]);
                    break;
                }
            }

            tocopy = 0;
            if(operate_len > 0) {
                tocopy = operate_len > (sizeof(KVs.operation_command)-1) ?
                         (sizeof(KVs.operation_command)-1) :
                         operate_len;
                KVs.request_len = tocopy;
                memcpy(KVs.operation_command, pos, tocopy);
            }
            KVs.operation_command[tocopy] = '\0';

            /* response���� */
            pos = end;
            end = strstr(pos,"|colfam\n");
            if (NULL == end) {
                break;
            }
            end += 8;
            lineLen = end - pos;
            if (lineLen <= 0) {
                PRINT_ERR_MSG("end - pos < 0");
                break;
            } else if (lineLen >= sizeof(line)) {
                PRINT_ERR_MSG("No enough space\n");
                break;
            }
            memcpy(line, pos, lineLen);
            line[lineLen]='\0';
            LineParse(line, &tmpKVs);

#if DEBUG_OPEN
            fprintf(stderr, "****************************************************************************\n"
                            "<%s>:%d:line = %s,\n"
                            "table=%s, capture_time=%lu, tmpTime=%lu, app_id=%s,\n"
                            "src_ip=%s, src_mac=%s, src_port=%s, dst_ip=%s, dst_mac=%s, dst_port=%s,\n"
                            "department=%s, web_session=%s, user_name=%s, web_url=%s,\n"
                            "operation_command=%s, web_content=%s, operation_sql=%s, user_id=%s,\n"
                            "response_content=%s, tform=%s, level_1=%s, alarm_id=%s, process_state=%s,\n"
                            "file_content=%s, saveflag=%s, charset=%s\n"
                            "****************************************************************************\n",
                            __FILE__, __LINE__, line,
                            tmpKVs.table, tmpKVs.capture_time, tmpTime, tmpKVs.app_id,
                            tmpKVs.src_ip, tmpKVs.src_mac, tmpKVs.src_port, tmpKVs.dst_ip, tmpKVs.dst_mac, tmpKVs.dst_port,
                            tmpKVs.department, tmpKVs.web_session, tmpKVs.user_name, tmpKVs.web_url,
                            tmpKVs.operation_command, tmpKVs.web_content, tmpKVs.operation_sql, tmpKVs.user_id,
                            tmpKVs.response_content, tmpKVs.tform, tmpKVs.level_1, tmpKVs.alarm_id, tmpKVs.process_state,
                            tmpKVs.file_content, tmpKVs.saveflag, tmpKVs.charset);
#endif

            operate_len = atoi(tmpKVs.response_content);
            pos = end;
            end += ( operate_len + 1);

            /* ���������һ�У��������������"rowkey="��ͷ */
            tmpLen = end - start;
            if(tmpLen != contentLen) {
                if(strncmp(end, "rowkey=", 7) != 0){
                    PRINT_ERR_MSG("endStr != rowkey");
                    break;
                }
            }
            tocopy = 0;
            if(operate_len > 0) {
                tocopy = operate_len > (sizeof(tmpKVs.response_content)-1) ?
                         (sizeof(tmpKVs.response_content)-1) :
                         operate_len;
                KVs.response_len = tocopy;
                memcpy(KVs.response_content, pos, tocopy);
            }
            KVs.response_content[tocopy] = '\0';
        } else if (APP_ID_HIS==type || APP_ID_PORTAL==type) {
            operate_len = atoi(KVs.file_content);
            pos = end;
            end += ( operate_len + 1);

            /* ���������һ�У��������������"rowkey="��ͷ */
            tmpLen = end - start;
            if(tmpLen != contentLen) {
                if(strncmp(end, "rowkey=", 7) != 0){
                    break;
                }
            }
            tocopy = 0;
            if(operate_len > 0) {
                tocopy = operate_len > (sizeof(KVs.file_content)-1) ?
                         (sizeof(KVs.file_content)-1) :
                         operate_len;
                KVs.file_content_len = tocopy;
                memcpy(KVs.file_content, pos, tocopy);
            }
            KVs.file_content[tocopy] = '\0';
        } else if (APP_ID_TELNET==type || APP_ID_FTP==type) {
            operate_len = atoi(KVs.response_content);
            pos = end;
            end += ( operate_len + 1);

            /* ���������һ�У��������������"rowkey="��ͷ */
            tmpLen = end - start;
            if(tmpLen != contentLen) {
                if(strncmp(end, "rowkey=", 7) != 0){
                    break;
                }
            }

            tocopy = 0;
            if(operate_len > 0) {
                tocopy = operate_len > (sizeof(KVs.response_content)-1) ?
                         (sizeof(KVs.response_content)-1) :
                         operate_len;
				KVs.response_len = tocopy;
				memcpy(KVs.response_content, pos, tocopy);
            }
            KVs.response_content[tocopy] = '\0';
        }

        /* �����ݿ�mongodb */

        if (type<6) {
            /* cache(his/portal/telent/ftp/superserver) */
            sprintf(tableName, "%s%s", CACHE_TABLE_NAME_PREFIX, KVs.table);
            mongoUseCollection(conn, DB_NAME, tableName);
            mongoMultipleInsert(conn, &KVs);
        } else if(type >= 6){
	         /* SQL Server */
            sprintf(tableName, "%s%s", SQLSERVER_TABLE_NAME_PREFIX, KVs.table);
            mongoUseCollection(conn, DB_NAME, tableName);
            mongoMultipleInsert(conn, &KVs);
        }

        /* Cache��Portal/telnet�ٶ����һ�ε������ */
        if(type > 2 && type<6){
            sprintf(tableName, "%s%s", CACHE_PORTAL_TELNET_PREFIX, KVs.table);
            mongoUseCollection(conn, DB_NAME, tableName);
            mongoMultipleInsert(conn, &KVs);
        }

        pos = end;
        if(pos -start >= contentLen){
            break;
        }
    }
    return 0;
}

int NC_daemon_audit(void) {
    pid_t pid;
    int ret;
    if ((pid = fork()) < 0) {
        return -1;
    } else if (pid != 0) {
        exit(0); /* parent goes bye-bye */
    }
    if((ret=setsid()) < 0) { /* become session leader */
        printf("unable to setsid.\n");
    }
     setpgrp();
     return 0;
}

/* read()�ķ�װ���ɹ����ض�ȡ���ֽ�����ʧ�ܷ���-1 */
ssize_t readBytes(int fd, void *buf, size_t n) {
    char *pos = buf;
    ssize_t nrd, nLeft=n;

    while (nLeft > 0) {
        if ( (nrd = read(fd, pos, nLeft)) < 0) {
            if (EINTR == errno) {
                nrd = 0;  /* �ٴε���read */
            } else {
	            PRINT_ERR_MSG("read() failed");
	            return -1;
            }
        } else if (0 == nrd) {
            break; /* EOF */
        }
        nLeft -= nrd;
        pos += nrd;
    }
    return (n-nLeft);
}

/* ���ļ�'fileName'��'len'�ֽڵ�'buf'.
   ���سɹ������ֽ���, ʧ�ܷ���-1 */
ssize_t readFile(char *fileName, void *buf, size_t n) {
    char *pos = buf;
    int fd, nrd;

    if (NULL==fileName || NULL==buf || n<=0) {PRINT_ERR_MSG("Incorrect parameter"); return -1;}
    fd = open(fileName, O_RDONLY);
    if (fd < 0) { PRINT_ERR_MSG("Fails to open the file"); return -1; }
    if ((nrd = readBytes(fd, pos, n)) < 0) { PRINT_ERR_MSG("read failed"); return -1; }
    close(fd);
    return nrd;
}

int handleOnlyOneFile(char *fileName) {
    char filePath[512], dirname[]="/data/audit/sql/";
    int retval;
    MONGO conn;

    retval = mongoConnect(&conn);
    if (retval < 0) {
        return -1;
    }

    sprintf(filePath, "%s%s", dirname, fileName);
    retval = readFile(filePath, tmpbuf, sizeof(tmpbuf)-1);
    if (retval <= 0) return 0;
    unlink(filePath);

    getKeyValues(&conn, tmpbuf, retval);
    mongoClose(&conn);
    return 0;
}

#if 1
char helpStr[] = "\n\n***********************************************************\n"
                 "USAGE:\n"
                 "audit_mongo_insert <daemonFlag> [filename]\n"
                 "<daemonFlag>(0/1): Set daemon mode, 1 for YES, 0 for NO\n"
                 "[filename]: Optional. Specify the only file need to be handled\n"
                 "***********************************************************\n\n";
int main(int argc,char ** argv) {
    char filePath[512], dirname[]="/data/audit/sql/";
    int retval;
    DIR *dp;
    struct dirent *dirp;
    MONGO conn;
    int flag;

    if (2 == argc || 3 == argc) {
        flag = atoi(argv[1]);
        if (flag!=0 && flag != 1) {
            perror(helpStr);
            exit(0);
        }
    } else {
        perror(helpStr);
        exit(0);
    }

    /* ��̨���� */
    if (1 == flag) NC_daemon_audit();

    /* ֻ����һ���ļ� */
    if (3 == argc) {
        handleOnlyOneFile(argv[2]);
        return 0;
    }

    retval = mongoConnect(&conn);
    if (retval < 0) {
        return -1;
    }

    while(1) {
        //��ȡ·��'dirname'�µ����5000���ļ��������浽'file_name'��
        if((dp=opendir(dirname)) == NULL) {
            PRINT_ERR_MSG("Open dir failed");
            return 0;
        }
        while((dirp=readdir(dp)) != NULL) {
            if((strcmp(dirp->d_name,".")==0)||(strcmp(dirp->d_name,"..")==0)){
                continue;
            }
            sprintf(filePath, "%s%s", dirname, dirp->d_name);
            retval = readFile(filePath, tmpbuf, sizeof(tmpbuf)-1);
            if (retval <= 0) continue;
            unlink(filePath);

            getKeyValues(&conn, tmpbuf, retval);
        }
        closedir(dp);
        usleep(1000);
    }
    mongoClose(&conn);
}
#endif
#if 0
int main() {
    char testBuf[] =
        "rowkey=123456789"
        "|colfam1:table=20150818"
        "|colfam1:app_id=2"
        "|colfam1:saveflag=1"
        "|colfam1:src_ip=192.168.1.1"
        "|colfam1:src_mac=11-11-11-11-11-11"
        "|colfam1:src_port=88"
        "|colfam1:dst_ip=192.168.1.2"
        "|colfam1:dst_mac=22-22-22-22-22-22"
        "|colfam1:dst_port=99"
        "|colfam1:user_id=12"
        "|colfam1:operation_command=0"
        "|colfam"
        "\n"
        "\n"
	    "rowkey=123456789"
	    "|colfam1:table=20150818"
	    "|colfam1:app_id=2"
	    "|colfam1:saveflag=1"
	    "|colfam1:src_ip=192.168.1.1"
	    "|colfam1:src_mac=11-11-11-11-11-11"
	    "|colfam1:src_port=88"
	    "|colfam1:dst_ip=192.168.1.2"
	    "|colfam1:dst_mac=22-22-22-22-22-22"
	    "|colfam1:dst_port=99"
	    "|colfam1:user_id=12"
	    "|colfam1:response_content=0"
	    "|colfam"
        "\n"
	    "\n"
        "rowkey=123"
        "|colfam1:table=20150919"
        "|colfam1:app_id=1"
        "|colfam1:saveflag=0"
        "|colfam1:src_ip=192.168.1.100"
        "|colfam1:src_mac=11-11-11-11-11-11"
        "|colfam1:src_port=880"
        "|colfam1:dst_ip=192.168.1.200"
        "|colfam1:dst_mac=22-22-22-22-22-22"
        "|colfam1:dst_port=990"
        "|colfam1:user_id=120"
        "|colfam1:operation_command=2"
        "|colfam"
        "\n"
        "11"
        "\n"
        "rowkey=123"
        "|colfam1:table=20150919"
        "|colfam1:app_id=1"
        "|colfam1:saveflag=0"
        "|colfam1:src_ip=192.168.1.100"
        "|colfam1:src_mac=22-22-22-22-22-22"
        "|colfam1:src_port=880"
        "|colfam1:dst_ip=192.168.1.200"
        "|colfam1:dst_mac=22-22-22-22-22-22"
        "|colfam1:dst_port=990"
        "|colfam1:user_id=120"
        "|colfam1:response_content=2"
        "|colfam"
        "\n"
        "22"
	    "\n";

    int retval;
    MONGO conn;


    retval = mongoConnect(&conn);
    if (retval < 0) {
        return 0;
    }

    getKeyValues(&conn, testBuf, strlen(testBuf));
	return 0;
}
#endif
