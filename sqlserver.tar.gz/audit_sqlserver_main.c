/* gcc audit_sqlserver_main.c -o newTest -g -Wall */

#include<ctype.h>
#include<stdio.h>
#include<time.h>
#include<string.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>
#include<ctype.h>
#include<sys/types.h>
#include<dirent.h>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>

#include"audit_api.h"
#include"audit_database_sql.h"
#include"./TDS_parser.c"

#define DEBUG_OPEN 1
#if DEBUG_OPEN
#define DEBUG_LOG(s) fprintf(stderr, "<%s>:%d:%s\n", __FILE__, __LINE__, (s))
#else
#define DEBUG_LOG(s)
#endif
#define PRINT_ERR_MSG(s) fprintf(stderr, "<%s>:%d:%s\n", __FILE__, __LINE__, (s))


#define ITEM_MAX 10 /* �����ݿ���ļ��������������ֵ */
#define REQUEST_RESPONSE_BUFFER_LIMIT (10*1024*1024) /* �����ļ���С���ܳ�10M */
#define SQLSERVER_REQUEST_RESPONSE_TMP "/dev/shm/sqlserver_tmp/"

int processId = 0;

typedef struct {
    unsigned short sport;
    unsigned short dport;
    unsigned short app_id;
    unsigned short user_id;
    unsigned int sip;
    unsigned int dip;
    char smac[64];
    char dmac[64];
    int reqsize;
    int respsize;
    unsigned int seq;
    unsigned long time;
    char *data;
    char * request;
    char * response;
    int processId;
}TITLE_CONTNET_TYPE;

/* �����ļ����ĵ�һ���ֶε�ֵ������Ӧ�� */
#define SQLSERVER_TMP_ID_PREFIX "10_"
#define CACHE_STUDIO_TMP_ID_PREFIX "20_"
#define CACHE_HIS_PORTAL_TMP_ID_PREFIX "100_"

#define SQLSERVER_TMP_ID 10
#define CACHE_STUDIO_TMP_ID 20
#define CACHE_HIS_PORTAL_TMP_ID 100

static char cur_flie_name[256] = {0};/* ��ǰ�����ݿ���ļ�����ȫ·���� */
static char cur_dstflie_name[256] = {0};
static int item_cnt = 0;/* ÿ�������ݿ���ļ������������ֵ */
static int fname_suffix_n = 0;
char requestResponseBuf[10*1024*1024] = {0},
     resultBuf[1024*1024*5], tmpBuf[10*1024*1024] = {0};

/* ɾ��'str'��ͷ��ĩβ�����Ŀհ��ַ�. ԭַ����
   ���ؽ�����ĳ��� */
static int trim(char *str) {
    char *start = str,
         *end = str+strlen(str)-1;
    int num;

    if (NULL==str || '\0'==str[0]) return 0;

    while (start<=end && isspace(*start)) start++;
    while (end > start && isspace(*end)) end--;

    if (start > end) {
        str[0] = '\0';
        num = 0;
    } else {
        if (start != str) {
            memmove(str, start, end-start+1);
        }
        str[end-start+1] = '\0';
        num = end-start+1;
    }

    return num;
}

static long GetFileSize(char *filename)
{
    struct stat buf;
    if(stat(filename, &buf)<0) {
        return -1;
    }
    return (long)buf.st_size;
}

/* ����'slen'�Ĵ�'s'��, 1���������Ķ�����ɴ�ӡ�ַ����һ���ո�, ��������浽'dst'��
 * ����'dst'�ַ����ĳ��� */
static int unprintable_to_space(char *src, int slen, char *dst, int dst_maxsize) {
    int i=0, j=0;

    memset(dst, 0, dst_maxsize);
    while (i<slen && j<(dst_maxsize-1)) {
        if ('\0' == src[i]) {
            i++;
        } else if (isprint(src[i]) && !isspace(src[i])) {
            dst[j++] = src[i++];
        } else if (isspace(src[i])) {
            dst[j++] = src[i++];
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        } else {
            dst[j++] = ' ';
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        }
    }
    dst[j] = '\0';

    return j;
}

/* ���ļ�'fname'д��'len'�ֽڵ�'content'.���ļ��������򴴽���
 * ���سɹ�д����ֽ���, ʧ�ܷ���-1 */
static int write_file(char *fname, char *content, int len) {
    int fd, nwr;

    if (NULL==fname || NULL==content || len<0) { PRINT_ERR_MSG("NULL==fname || NULL==content || len<=0"); return -1; }
    if (0 == len) { return 0; }
    fd = open(fname, O_CREAT|O_RDWR|O_APPEND, 0666);
    if (fd < 0) {
        PRINT_ERR_MSG("open file failed");
        return -1;
    }

    if ((nwr = write(fd, content, len)) < 0) {
        PRINT_ERR_MSG("write file failed");
        close(fd);
        return -1;
    }
    close(fd);

    return nwr;
}

/* ��ȡ'ip'�ĵ����ʽ, 'ipstr'������, 'len'��'ipstr'�Ĵ�С
   'ip'�������� */
static int getStrIp(u_int32_t ip, char *ipstr, size_t len) {
    struct in_addr addr;
    addr.s_addr = ip;
    inet_ntop(AF_INET, &addr, ipstr, len);
    return 0;
}

/* �ѻ����request/response���ݣ��͸�������Ϣ�����浽�����ݿ���ļ��С�
   �ɹ�����0, ʧ�ܷ���-1��
   ע�� -
   <1>response��request��2���ļ�����1���ַ�������ʶ������͵ģ�����д��
      ���ݿ�������
   <2>�ļ�����ʽ='SQLSERVER_PREFIX'����audit_time�����̵߳İ�������thread_id��
   <3>�����ݿ�Ļ����ļ��ĸ�ʽ -
      rowkey=[time1]|colfam1:table=[time2]|colfam1:app_id=[app_id]|colfam1:saveflag=[0/1]|colfam1:src_ip=x.x.x.x|colfam1:src_mac=[x:x:x:x:x:x]|colfam1:src_port=[src_port]|colfam1:dst_ip=x.x.x.x|colfam1:dst_mac=x:x:x:x:x:x|colfam1:dst_port=[dst_port]|colfam1:user_id=[user_id]|colfam1:operation_command=[request]|colfam\n
      \nrowkey=[time1]|colfam1:table=[time2]|colfam1:app_id=[app_id]|colfam1:saveflag=[0/1]|colfam1:src_ip=x.x.x.x|colfam1:src_mac=[x:x:x:x:x:x]|colfam1:src_port=[src_port]|colfam1:dst_ip=x.x.x.x|colfam1:dst_mac=x:x:x:x:x:x|colfam1:dst_port=[dst_port]|colfam1:user_id=[user_id]|colfam1:response_content=[response]|colfam\n
      ÿ2��rowkey֮�䣬��1�����С�
*/
#define SQLSERVER_SQL_TMP_DIR "/data/audit/sql_tmp/"
#define SQLSERVER_SQL_DIR "/data/audit/sql/"
#define SQLSERVER_PREFIX "Sql_sqlserver_"

/* read()�ķ�װ���ɹ����ض�ȡ���ֽ�����ʧ�ܷ���-1 */
ssize_t readBytes(int fd, void *buf, size_t n) {
    char *pos = buf;
    ssize_t nrd, nLeft=n;

    while (nLeft > 0) {
        if ( (nrd = read(fd, pos, nLeft)) < 0) {
            if (EINTR == errno) {
                nrd = 0;  /* �ٴε���read */
            } else {
                PRINT_ERR_MSG("read() failed");
                return -1;
            }
        } else if (0 == nrd) {
            break; /* EOF */
        }
        nLeft -= nrd;
        pos += nrd;
    }
    return (n-nLeft);
}

/* ���ļ�'fileName'��'len'�ֽڵ�'buf'.
   ���سɹ������ֽ���, ʧ�ܷ���-1 */
ssize_t readFile(char *fileName, void *buf, size_t n) {
    char *pos = buf;
    int fd, nrd;

    if (NULL==fileName || NULL==buf || n<=0) {PRINT_ERR_MSG("Incorrect parameter"); return -1;}
    fd = open(fileName, O_RDONLY);
    if (fd < 0) { PRINT_ERR_MSG("Fails to open the file"); return -1; }
    if ((nrd = readBytes(fd, pos, n)) < 0) { PRINT_ERR_MSG("read failed"); return -1; }
    close(fd);
    return nrd;
}

int strReplaceOne(char *src, char *dst, char *oldpart, char *newpart) {
    char *pos, *cur;
    pos = strstr(src, oldpart);
    if (NULL == pos) {
        strcpy(dst, src);
        return 0;
    }

    cur = dst;
    memcpy(cur, src, pos-src);
    cur += (pos-src);
    memcpy(cur, newpart, strlen(newpart));
    cur += strlen(newpart);
    pos += strlen(oldpart);
    strcpy(cur, pos);
    cur[strlen(pos)] = '\0';
    return cur+strlen(pos)-dst;
}

const char days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

struct tm *dhcc_localtime(time_t time, long time_zone, struct tm *tm_time) {
    unsigned  int pass_4year, hour_per_year;

    time = time + time_zone*60*60;
    if(time < 0) {
       time = 0;
    }

    tm_time->tm_sec=(int)(time % 60);
    time /= 60;
    tm_time->tm_min=(int)(time % 60);
    time /= 60;
    pass_4year=((unsigned int)time / (1461 * 24));
    tm_time->tm_year=(pass_4year << 2) + 70;
    time %= 1461 * 24;

    for (;;)
    {
        hour_per_year = 365 * 24;

        if ((tm_time->tm_year & 3) == 0)
        {
            hour_per_year += 24;
        }
        if (time < hour_per_year)
        {
            break;
        }
        tm_time->tm_year++;
        time -= hour_per_year;
    }

    tm_time->tm_hour=(int)(time % 24);
    time /= 24;
    time++;
    if ((tm_time->tm_year & 3) == 0)
    {
        if (time > 60)
        {
            time--;
        }
        else
        {
            if (time == 60)
            {
                tm_time->tm_mon = 1;
                tm_time->tm_mday = 29;
            }
        }
    }
    for (tm_time->tm_mon = 0; days[tm_time->tm_mon] < time; tm_time->tm_mon++)
    {
          time -= days[tm_time->tm_mon];
    }
    tm_time->tm_mday = (int)(time);

        return tm_time;
}

void log_time(struct tm *t_time)
{
    if((t_time->tm_hour) >=24) {
        t_time->tm_mday += 1;
        t_time->tm_hour -= 24;
    }

    switch(t_time->tm_mon) {
        case 0 ... 10:
            if(t_time->tm_mday > days[t_time->tm_mon]) {
                t_time->tm_mon += 1;
                t_time->tm_mday = 1;
            }

        case 11:
            {
                if(t_time->tm_mday > days[t_time->tm_mon]) {
                    t_time->tm_mon = (t_time->tm_mon) - 11;
                    t_time->tm_mday = (t_time->tm_mday) - (days[t_time->tm_mon]);
                    t_time->tm_year += 1;
                }
            }

        default:
            break;
    }
}

void getTime3(char *times, size_t maxsize){
    time_t now;
    struct tm  timenow;

    time(&now);
    dhcc_localtime(now, 8, &timenow);
    log_time(&timenow);
    snprintf(times, maxsize, "%04d_%02d", timenow.tm_year+1900, timenow.tm_mon+1);
}

/* �ļ����ϴ��޸�ʱ�䵽��ǰʱ�䣬����'secs'�룬�򷵻�1�����򷵻�0 */
int IsOld(char *filePath, int secs) {
    time_t t;
    int retval;
    struct stat ft;

    retval = time(&t);
    if (retval < 0) return 1;

    retval = stat(filePath, &ft);
    if (retval < 0) return 1;

    if ((long)t - (long)(ft.st_mtime) > secs) return 1;
    return 0;
}

int audit_sqlserver(TITLE_CONTNET_TYPE *data) {
    char buffer[1024]={0}, time_for_table_item[32]={0},
         srcipstr[32]={0}, dstipstr[32]={0}, srcmac[64]={0}, dstmac[64]={0};
    int pkt_type;

    /* ��������sqlserver����� */
    if (data->app_id != SQLSERVER_TMP_ID) {
        fprintf(stderr, "<%s>:%d:Wrong function.(app_id=%d)\n", __FILE__, __LINE__, data->app_id);
        return 0;
    }

    /* ȡ"2015-08"��ʽʱ�� */
    getTime3(time_for_table_item, sizeof(time_for_table_item)-1);

    /* ���������ݿ�Ļ����ļ�����ȫ·�� */
    if (0==item_cnt || '\0'==cur_flie_name[0] || '\0'==cur_dstflie_name[0]) {
        item_cnt = 0;
        sprintf(cur_flie_name,
            SQLSERVER_SQL_TMP_DIR
            SQLSERVER_PREFIX
            "%s_%d_%d", time_for_table_item, fname_suffix_n, processId);
        sprintf(cur_dstflie_name,
            SQLSERVER_SQL_DIR
            SQLSERVER_PREFIX
            "%s_%d_%d", time_for_table_item, fname_suffix_n, processId);
        fname_suffix_n++;
    }

    /* ���� */
    pkt_type = TDS_parser(data->request, data->reqsize, resultBuf, sizeof(resultBuf));
    if (pkt_type != select_flag && pkt_type != update_flag && pkt_type != delete_flag
        && pkt_type != insert_flag && pkt_type != creat_flag && pkt_type != drop_flag
        && pkt_type != other_sql_flag) {
#if DEBUG_OPEN
        fprintf(stderr, "<%s>:%d:Not sql (pkt_type=%d)", __FILE__, __LINE__,pkt_type);
#endif
        return 0;
    }
    unprintable_to_space(data->request+8, data->reqsize, tmpBuf, sizeof(tmpBuf)-1);
    trim(tmpBuf);
    if ((strlen(tmpBuf)+strlen(resultBuf)) < 10) {
#if DEBUG_OPEN
        fprintf(stderr, "<%s>:%d:Too little data : resultBuf=%s, tmpBuf=%s, pkt_type=%d\n",
        __FILE__, __LINE__, resultBuf, tmpBuf, pkt_type);
#endif
        return 0;
    }

    /* ȷ��Ҫ������ļ����ٴ���ip/mac */
    /* ���ʽip (cli��Ӧ �������src    ser ��Ӧdes)*/
    getStrIp(ntohl(data->sip), srcipstr, 32);
    getStrIp(ntohl(data->dip), dstipstr, 32);

    /* mac */
    sprintf(srcmac, "%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",
                    data->smac[0], data->smac[1], data->smac[2], data->smac[3], data->smac[4], data->smac[5],
                    data->smac[6], data->smac[7], data->smac[8], data->smac[9], data->smac[10], data->smac[11]);
    sprintf(dstmac, "%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",
                    data->dmac[0], data->dmac[1], data->dmac[2], data->dmac[3], data->dmac[4], data->dmac[5],
                    data->dmac[6], data->dmac[7], data->dmac[8], data->dmac[9], data->dmac[10], data->dmac[11]);

    /* request����
       ע - 'operation_command'��ƫ����������ƫ�����ݺ��\n */
    sprintf(buffer,
        "rowkey=%lu"
        "|colfam1:table=%s"
        "|colfam1:app_id=%d"
        "|colfam1:src_ip=%s"
        "|colfam1:src_mac=%s"
        "|colfam1:src_port=%hu"
        "|colfam1:dst_ip=%s"
        "|colfam1:dst_mac=%s"
        "|colfam1:dst_port=%hu"
        "|colfam1:user_id=%hu"
        "|colfam1:charset=%s"
        "|colfam1:operation_command=%d"
        "|colfam\n",
        data->time, time_for_table_item, pkt_type, srcipstr, srcmac, data->sport,
        dstipstr, dstmac, data->dport, data->user_id, "UTF-8", (int)(strlen(resultBuf)+4+strlen(tmpBuf)));
    DEBUG_LOG(buffer);

    write_file(cur_flie_name, buffer, strlen(buffer));
    write_file(cur_flie_name, resultBuf, strlen(resultBuf));
    write_file(cur_flie_name, ";:r\n", 4);
    write_file(cur_flie_name, tmpBuf, strlen(tmpBuf));

    /* response���� */
    if (data->respsize > 0) {
        if (select_flag == pkt_type) {
            TDS_parser(data->response, data->respsize, resultBuf, sizeof(resultBuf));
        } else {
            resultBuf[0] = '\0';
        }

        /* ȥ�����ķǲ������ַ�����ַ��� */
        unprintable_to_space(data->response+8, data->respsize-8, tmpBuf, sizeof(tmpBuf)-1);
        trim(tmpBuf);
    } else {
        resultBuf[0] = '\0';
        tmpBuf[0] = '\0';
    }

    /* ע - 'response_content'��ƫ����������ƫ�����ݺ��\n */
    sprintf(buffer,
        "\n"
        "rowkey=%lu"
        "|colfam1:table=%s"
        "|colfam1:app_id=%d"
        "|colfam1:src_ip=%s"
        "|colfam1:src_mac=%s"
        "|colfam1:src_port=%hu"
        "|colfam1:dst_ip=%s"
        "|colfam1:dst_mac=%s"
        "|colfam1:dst_port=%hu"
        "|colfam1:user_id=%hu"
        "|colfam1:charset=%s"
        "|colfam1:response_content=%d"
        "|colfam\n",
        data->time, time_for_table_item, pkt_type, srcipstr, srcmac, data->sport,
        dstipstr, dstmac, data->dport, data->user_id, "UTF-8", (int)(strlen(resultBuf)+4+strlen(tmpBuf)));
    DEBUG_LOG(buffer);

    write_file(cur_flie_name, buffer, strlen(buffer));
    write_file(cur_flie_name, resultBuf, strlen(resultBuf));
    write_file(cur_flie_name, ";:r\n", 4);
    write_file(cur_flie_name, tmpBuf, strlen(tmpBuf));
    write_file(cur_flie_name, "\n", 1);

    /* �ƶ������ݿ���ļ� */
    item_cnt++;
    if (item_cnt >= ITEM_MAX || IsOld(cur_flie_name, 60)) {
        DEBUG_LOG("Move a file from sql_tmp to sql");
        rename(cur_flie_name, cur_dstflie_name);
        unlink(cur_flie_name);
        item_cnt = 0;
        cur_flie_name[0] = '\0';
        cur_dstflie_name[0] = '\0';
    }

    return 0;
}

/* ======================================================================================================== */
#define CMDLEN  10485760
char RequestFileName[1000];
char ResponseFileName[1000];
char cmd1[CMDLEN];
char cmd2[CMDLEN];
char fileContentRequest[CMDLEN];
char fileContentResponse[CMDLEN];

/* ʹ��ǰ����תΪ��̨���� */
int NC_daemon_audit(void) {
    pid_t pid;
    int ret;
    if ((pid = fork()) < 0) {
        return -1;
    } else if (pid != 0) {
        exit(0); /* parent goes bye-bye */
    }

    if((ret=setsid()) < 0) { /* become session leader */
        PRINT_ERR_MSG("unable to setsid.");
        exit(0);
    }
     setpgrp();
     return 0;
}

void GetValues(TITLE_CONTNET_TYPE *tContent, char *filename){
    /* ���� - 10_2887326051_000fe25c06a0_64234_168466306_80c16ef872cd_1433_0_5_1440916826045169_request */
    sscanf(filename, "%hu_%u_%[^_]_%hu_%u_%[^_]_%hu_%u_%hu_%lu_request",
                    &tContent->app_id, &tContent->sip, tContent->smac, &tContent->sport,
                    &tContent->dip, tContent->dmac, &tContent->dport, &tContent->seq,
                    &tContent->user_id, &tContent->time);
}

unsigned int FileInit(char * filename,TITLE_CONTNET_TYPE *tContent, char *fileContent, int maxsize){
    FILE * fp = NULL;
    long fsize =0;
    long readsize = 0;
    memset(fileContent,0,CMDLEN*sizeof(char));

    fsize = GetFileSize(filename);
    if(fsize <=0){
        return -1;
    }
    if(fsize > CMDLEN*sizeof(char)){
        fprintf(stderr, "<%s>:%d:Big file.(filename=%s, fsize=%ld)\n", __FILE__, __LINE__,filename, fsize);
        fsize = CMDLEN*sizeof(char) - 1;
    }

    fp = fopen(filename,"r+");
    if(!fp){
        fprintf(stderr, "<%s>:%d:Open file(%s) failed. \n", __FILE__, __LINE__,filename);
        return  -1;
    }

    readsize = fread(fileContent, 1, fsize, fp);
    if(readsize != fsize){
        fprintf(stderr, "<%s>:%d:fread file(%s) error.\n", __FILE__, __LINE__,filename);
        fclose(fp);
        return -1;
    }

    fclose(fp);
    fp = NULL;

    return fsize;
}

void parse_request_file(TITLE_CONTNET_TYPE *tContent,char * requestPath){
    tContent->reqsize=FileInit(requestPath,tContent, fileContentRequest, sizeof(fileContentRequest)-1);
}

void parse_response_file(TITLE_CONTNET_TYPE *tContent,char * responsePath){
    tContent->respsize=FileInit(responsePath,tContent, fileContentResponse, sizeof(fileContentResponse)-1);
}

#define REQUEST_RESPONSE_CACHE_PATH "/dev/shm/"
char helpStr[] = "\n\n*************************************************************\n"
                 "USAGE:\n"
                 "audit_sqlserver_main <id> <daemonFlag>\n"
                 "<id>[0...9]:       Specify which dir to read.\n"
                 "<daemonFlag>[0/1]: Set daemon mode, 1 for YES, 0 for NO\n"
                 "*************************************************************\n\n";
int main(int argc,char **argv){
    DIR *srcDir;
    struct dirent *srcDp;
    int dir = 0, id, flag, exist;
    char *pos, dirName[1024], fileBaseName1[1024], fileBaseName2[1024];
    TITLE_CONTNET_TYPE tContent;

    if (argc != 3) {
        perror(helpStr);
        exit(0);
    } else {
        id = atoi(argv[1]);
        flag = atoi(argv[2]);

        if (id<0 || id >9 || (flag!=1 && flag!=0)) {
            perror(helpStr);
            exit(0);
        }
        processId = id;
    }

    /* ��̨���� */
    if (1 == flag) NC_daemon_audit();

    sprintf(dirName, REQUEST_RESPONSE_CACHE_PATH "%d/", id);

    while(1){
        if (NULL == (srcDir = opendir(dirName))) {
            PRINT_ERR_MSG("opendir error");
            return -1;
        }

        while ((srcDp = readdir(srcDir)) != NULL) {
            if(strcmp(srcDp->d_name,".") == 0 || strcmp(srcDp->d_name,"..") == 0){
                continue;
            }

            /* ��������studio���ļ� */
            if(memcmp(srcDp->d_name, SQLSERVER_TMP_ID_PREFIX, strlen(SQLSERVER_TMP_ID_PREFIX))!=0){
                continue;
            }

            memset(&tContent, 0, sizeof(TITLE_CONTNET_TYPE));
            tContent.processId = dir;

            memset(cmd1, 0, sizeof(cmd1));
            memset(cmd2, 0, sizeof(cmd2));
            memset(RequestFileName, 0, sizeof(RequestFileName));
            memset(ResponseFileName, 0, sizeof(ResponseFileName));

            strcpy(fileBaseName1, srcDp->d_name);
            if ((pos = strstr(fileBaseName1, "_request")) != NULL) {
                *pos = '\0';
                sprintf(fileBaseName2, "%s_response", fileBaseName1);
                *pos = '_';
                sprintf(RequestFileName, "%s%s", dirName, fileBaseName1);
                sprintf(ResponseFileName, "%s%s", dirName, fileBaseName2);
                GetValues(&tContent, fileBaseName1);
            } else if ((pos = strstr(fileBaseName1,"_response")) != NULL) {
                *pos = '\0';
                sprintf(fileBaseName2, "%s_request", fileBaseName1);
                *pos = '_';
                sprintf(RequestFileName,"%s%s", dirName, fileBaseName2);
                sprintf(ResponseFileName,"%s%s", dirName, fileBaseName1);
                GetValues(&tContent, fileBaseName2);
            } else {
                sprintf(fileBaseName2, "%s%s", dirName, fileBaseName1);
                fprintf(stderr, "<%s>:%d:No request/resonse in file name(%s), remove it.\n", __FILE__, __LINE__,fileBaseName2);
                unlink(fileBaseName2);
            }

            tContent.request=fileContentRequest;
            tContent.response=fileContentResponse;

#if DEBUG_OPEN
            fprintf(stderr, "<%s>:%d:"
                    "app_id=%hu, sip=%u, sport=%hu, smac=%s, dip=%u, dport=%hu, dmac=%s, seq=%u, user_id=%hu, time=%lu\n",
                    __FILE__, __LINE__,
                    tContent.app_id, tContent.sip, tContent.sport, tContent.smac,
                    tContent.dip, tContent.dport, tContent.dmac, tContent.seq,
                    tContent.user_id, tContent.time);
#endif
            parse_request_file(&tContent, RequestFileName);
            parse_response_file(&tContent, ResponseFileName);

            /* ֻ��һ������ʱ�����ô��ڵ��ļ���ʱ����ɾ�� */
            if((exist=access(RequestFileName,0))!=0){
                if (IsOld(ResponseFileName, 120) == 1) {
                    unlink(ResponseFileName);
                }
                continue;
            }

            if((exist=access(ResponseFileName,0))!=0){
                if (IsOld(RequestFileName, 120) == 1) {
                    unlink(RequestFileName);
                }
                continue;
            }

            audit_sqlserver(&tContent);

            unlink(RequestFileName);
            unlink(ResponseFileName);
        }
        closedir(srcDir);
        usleep(1000);
    }

    return 0;
}

