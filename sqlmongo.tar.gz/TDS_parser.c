
/* ����TDSЭ������
   TDSЭ��ȫ��Tabular Data Stream Protocol����һ�����ں�SQL Server ͨѶ��
   Ӧ�ò�Э��
   ע: ���ڱ��ļ���ʶ��������ֻҪ��TDS�ĵ��и��������һ�ɲ����ĵ�ԭ�ģ�������Сд
   ��ʽ����Ȼ����Щ������ʽ���ң��������׺��ĵ���Ӧ���� */

#include<stdio.h>
#include<string.h>
#include<iconv.h>
#include<ctype.h>

#define __NEW_TEST 0

#if 1
#define DEBUG_PRINT(s) fprintf(stderr, "%s:%d:%s\n", __FILE__, __LINE__, (s))
#else
#define DEBUG_PRINT(s)
#endif

char ColValBefore[10240], ColValAfter[10240];

/*==================================================================================*/
/* �ֽڶ��� */
#pragma pack(1)


/*==================================================================================*/
/* TDSЭ��汾���ƺ� */
/* After a protocol feature is introduced, subsequent versions of the TDS protocol
   support that feature until that feature is removed */
#define __TDS_7_0 1
#define __TDS_7_1 1
#define __TDS_7_2 1
#define __TDS_7_3 1
#define __TDS_7_4 0

/*==================================================================================*/
/* 2.2.5.4.1С��
   FIXEDLENTYPEȡֵ��Χ
   Non-nullable values are returned using these fixed-length data types.
   There is no data associated with NULLTYPE.
   For the rest of the fixed-length data types, the length of data is predefined by the type.
   There is no TYPE_VARLEN field in the TYPE_INFO rule for these types.
   In the TYPE_VARBYTE rule for these types, the TYPE_VARLEN field is BYTELEN, and the value is
   1 for INT1TYPE/BITTYPE,
   2 for INT2TYPE,
   4 for INT4TYPE/DATETIM4TYPE/FLT4TYPE/MONEY4TYPE, and
   8 for MONEYTYPE/DATETIMETYPE/FLT8TYPE/INT8TYPE.
   The value represents the number of bytes of data to be followed.
   The SQL data types of the corresponding fixed-length data types are in the comment part
of each data type. */
#define NULLTYPE 0x1F     // Null,�޺�������
#define INT1TYPE 0x30     // TinyInt��1�ֽ�
#define BITTYPE 0x32      // Bit��1�ֽ�
#define INT2TYPE 0x34     // SmallInt��2�ֽ�
#define INT4TYPE 0x38     // Int��4�ֽ�
#define DATETIM4TYPE 0x3A // SmallDateTime��4�ֽ�
#define FLT4TYPE 0x3B     // Real��4�ֽ�
#define MONEYTYPE 0x3C    // Money��8�ֽ�
#define DATETIMETYPE 0x3D // DateTime��8�ֽ�
#define FLT8TYPE 0x3E     // Float��8�ֽ�
#define MONEY4TYPE 0x7A   // SmallMoney��4�ֽ�
#define INT8TYPE 0x7F     // BigInt��8�ֽ�

/*==================================================================================*/
/* 2.2.5.4.2С��
   VARLENTYPE = BYTELEN_TYPE/USHORTLEN_TYPE/LONGLEN_TYPE */

/* BYTELEN_TYPEȡֵ��Χ
   the length value associated with these data types is specified within a BYTE */
#define GUIDTYPE 0x24            //UniqueIdentifier. For GUIDTYPE, the only valid lengths are 0x10 for non-null instances and 0x00 for NULL instances.
#define INTNTYPE 0x26            //(see below) For INTNTYPE, the only valid lengths are 0x01, 0x02, 0x04, and 0x08, which map to tinyint, smallint, int, and bigint SQL data types respectively.
#define DECIMALTYPE 0x37         //Decimal (legacy support)
#define NUMERICTYPE 0x3F         //Numeric (legacy support)
#define BITNTYPE 0x68            //(see below) For BITNTYPE, the only valid lengths are 0x01 for non-null instances and 0x00 for NULL instances.
#define DECIMALNTYPE 0x6A        //Decimal
#define NUMERICNTYPE 0x6C        //Numeric
#define FLTNTYPE 0x6D            //(see below) For FLTNTYPE, the only valid lengths are 0x04 and 0x08, which map to 7-digit precision float and 15-digit precision float SQL data types respectively.
#define MONEYNTYPE 0x6E          //(see below) For MONEYNTYPE, the only valid lengths are 0x04 and 0x08, which map to smallmoney and money SQL data types respectively.
#define DATETIMNTYPE 0x6F        //(see below) For DATETIMNTYPE, the only valid lengths are 0x04 and 0x08, which map to smalldatetime and datetime SQL data types respectively.
#if __TDS_7_3
#define DATENTYPE 0x28           //(introduced in TDS 7.3) For DATENTYPE, the only valid lengths are 0x03 for non-NULL instances and 0x00 for NULL instances.
#define TIMENTYPE 0x29           //(introduced in TDS 7.3)
#define DATETIME2NTYPE 0x2A      //(introduced in TDS 7.3)
#define DATETIMEOFFSETNTYPE 0x2B //(introduced in TDS 7.3)
#endif
#define CHARTYPE 0x2F            //Char (legacy support)
#define VARCHARTYPE 0x27         //VarChar (legacy support)
#define BINARYTYPE 0x2D          //Binary (legacy support)
#define VARBINARYTYPE 0x25       //VarBinary (legacy support)

/* USHORTLEN_TYPEȡֵ��Χ
   the length value associated with these data types is specified within a USHORT */
#define BIGVARBINTYPE 0xA5       //VarBinary
#define BIGVARCHRTYPE 0xA7       //VarChar
#define BIGBINARYTYPE 0xAD       //Binary
#define BIGCHARTYPE 0xAF         //Char
#define NVARCHARTYPE 0xE7        //NVarChar
#define NCHARTYPE 0xEF           //NChar

/* LONGLEN_TYPEȡֵ��Χ
   the length value associated with these data types is specified within a LONG*/
#if __TDS_7_2
#define XMLTYPE 0xF1             //XML (introduced in TDS 7.2) XMLTYPE is only a valid LONGLEN_TYPE for BulkLoadBCP.
#endif
#define TEXTTYPE 0x23            //Text
#define IMAGETYPE 0x22           //Image
#define NTEXTTYPE 0x63           //NText
#if __TDS_7_2
#define SSVARIANTTYPE 0x62       //Sql_Variant (introduced in TDS 7.2), MaxLength for an SSVARIANTTYPE is 8009 (8000 for strings).
#endif

/* ����ֵ */
#if __TDS_7_2
#define UDTTYPE 0xF0             //CLR UDT (introduced in TDS 7.2)
#endif


/*==================================================================================*/
/* 2.2.5.4.3С��
   PARTLENTYPE = XMLTYPE / BIGVARCHRTYPE / BIGVARBINTYPE / NVARCHARTYPE / UDTTYPE
   */
/* BIGVARCHRTYPE, BIGVARBINTYPE, and NVARCHARTYPE can represent two types each:
   <1>The regular type with a known maximum size range from 0 to 8000, defined by USHORTLEN_TYPE.
   <2>A type with unlimited max size, known as varchar(max), varbinary(max) and nvarchar(max),
   which has a max size of 0xFFFF, defined by PARTLENTYPE. This class of types was introduced
   in TDS 7.2. */

/*==================================================================================*/
/* �ֽ���ת�� */
#define HOST_IS_LITTLE_ENDIAN 1 /* �����ֽ��� */

/* ��'data'ָ���'n'���ֽڵ����ݣ��任���෴��˳�� */
void mem_reverse(void *data, int n) {
    char *pos = data, tmp;
    int start=0, end=n-1;

    while (start < end) {
        tmp = pos[start];
        pos[start] = pos[end];
        pos[end] = tmp;
        start++, end--;
    }
}

/* ����ֽ���תΪ�����ֽ��򡣵������ֽ�����Ǵ��ʱ���ú��������κβ��� */
void big_2_host(void *val, int size) {
#if HOST_IS_LITTLE_ENDIAN
    mem_reverse(val, size);
#endif
}

/* С���ֽ���תΪ�����ֽ��򡣵������ֽ������С��ʱ���ú��������κβ��� */
void little_2_host(char *val, int size) {
#if !(HOST_IS_LITTLE_ENDIAN)
    mem_reverse(val, size);
#endif
}

/* ��'data'ָ���'len'�ֽڵ����ݣ���ת��ʮ�����ƵĿɼ���ʽ�ַ��������浽
   ���Ϊ'des_maxlen'�ֽڵĿռ�'des'�С��ַ�����ʽΪ:
   00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f<br>
   10 11 12 13 14 15 16 17 18 19 1a 1b 1c 1d 1e 1f<br>
   ......
   ��'des_maxlen'�ֽڲ��㣬��ô�Ͱ�'des'������ͷ��أ�ʣ�µ��ֽڲ�ת����
   ����ʼ���ڽ����ĩβ����'\0'. */
int binary_to_hex_visible (char *data, int len, char *des, int des_maxlen) {
    char *datapos, *despos, tmp;
    int num_in_line;
    const int BR_LEN = 4, CHARS_PER_LINE = 16, PAD_SIZE = 1;

    datapos = data;
    despos = des;
    num_in_line = 0;
    while ((datapos < (data+len)) && (des_maxlen-(despos-des) >= 2+PAD_SIZE)) {
        tmp = *datapos/16;
        *despos++ = (tmp >=0 && tmp<=9) ? (tmp+48) : (tmp+55);
        tmp = *datapos%16;
        *despos++ = (tmp >=0 && tmp<=9) ? (tmp+48) : (tmp+55);
        datapos++;

        num_in_line++;
        if (CHARS_PER_LINE == num_in_line) {
            if (des_maxlen-(despos-des) < BR_LEN+PAD_SIZE ) {
                fprintf(stderr, "Space is too small\n");
                break;
            }
            *despos++ = '<';
            *despos++ = 'b';
            *despos++ = 'r';
            *despos++ = '>';
            num_in_line = 0;
        } else {
            if (des_maxlen-(despos-des) < 1+PAD_SIZE ) {
                fprintf(stderr, "Space is too small\n");
                break;
            }
            *despos++ = ' ';
        }
    }
    *despos++ = '\0';
    return (despos - des);
}

/* ����:"12345"תΪ"0x3132333435" */
int binaryToHexVisible (char *data, int len, char *des, int des_maxlen) {
    char *datapos, *despos, tmp;

    datapos = data;
    despos = des;
    *despos++ = '0';
    *despos++ = 'x';
    while ((datapos < (data+len)) && des_maxlen > (despos-des)) {
        tmp = *datapos/16;
        *despos++ = (tmp >=0 && tmp<=9) ? (tmp+48) : (tmp+55);
        tmp = *datapos%16;
        *despos++ = (tmp >=0 && tmp<=9) ? (tmp+48) : (tmp+55);
        datapos++;
    }
    *despos++ = '\0';
    return (despos - des);
}


/* ����'slen'�Ĵ�'s'��, 1���������Ķ�����ɴ�ӡ�ַ����һ���ո�, ��������浽'dst'��
 * ����'dst'�ַ����ĳ��� */
static int unprintable_to_space_tds(char *src, int slen, char *dst, int dst_maxsize) {
    int i=0, j=0;

    memset(dst, 0, dst_maxsize);
    while (i<slen && j<(dst_maxsize-1)) {
        if ('\0' == src[i]) {
            i++;
        } else if (isprint(src[i]) && !isspace(src[i])) {
            dst[j++] = src[i++];
        } else if (isspace(src[i])) {
            dst[j++] = src[i++];
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        } else {
            dst[j++] = ' ';
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        }
    }
    dst[j] = '\0';

    return j;
}


/* �ַ���ת�����ɹ��򷵻ؽ�������ȣ�ʧ�ܷ���-1
   ע�� - GBK/GB2312�ȣ�����һ�֣���������֮��ת������iconv()�ϳ��� */
int codeConv(char* srcCharSet, char *dstCharSet, char *src, size_t srcLen, char *dst, size_t dstMaxSize) {
    iconv_t cd;
    size_t tmpLen = dstMaxSize;
    char *tmppos = dst;

    if (NULL==srcCharSet || NULL==dstCharSet || NULL==src || NULL==dst || srcLen<0 || dstMaxSize<0 ) {
        perror("Incorrect parameter\n");
        return -1;
    }

    /* �����߶���GBK��һ��ʱ������Ҫת�� */
    if ((('G'==srcCharSet[0] || 'g'==srcCharSet[0]) && ('B'==srcCharSet[1] || 'b'==srcCharSet[1]))
        && (('G'==dstCharSet[0] || 'g'==dstCharSet[0]) && ('B'==dstCharSet[1] || 'b'==dstCharSet[1]))) {
        memcpy(dst, src, srcLen);
        return srcLen;
    }

    cd = iconv_open(dstCharSet, srcCharSet);
    if((iconv_t)-1 == cd ){ perror("iconv_open() failed\n"); return -1; }

    memset(dst, 0, dstMaxSize);
    if(iconv(cd, &src, &srcLen, &tmppos, &tmpLen) < 0){
        iconv_close(cd);
        perror("iconv() failed\n");
        return -1;
    }
    iconv_close(cd);

    dst[dstMaxSize - tmpLen] = '\0';
    return (dstMaxSize - tmpLen);
}

/*
<1>���������ܱ�4������Ϊ���ꡣ����2004���������,2010�겻�����꣩
<2>�������ܱ�400�����������ꡣ(��2000�������꣬1900�겻������)
<3>������ֵ�ܴ�����,�������������3200,����������172800�������ꡣ��172800�������꣬86400�겻������(��Ϊ��Ȼ������3200������������172800)*/
int isLeapYear(long year) {
    if (year % 100 != 0 && year % 4 == 0) {
        return 1;
    }
    if (year % 100 == 0 && year % 400 == 0) {
        return 1;
    }
    return 0;
}

int getDaysInYear(long year) {
    if (isLeapYear(year)) return 366;
    return 365;
}

int getDaysInMonth(int year, int month) {
    switch (month) {
        case 1: case 3:case 5: case 7:case 8: case 10:case 12:
            return 31;
        case 2:
            if (isLeapYear(year)) return 29;
            else return 28;
        default:
            return 30;
    }
}


/* 'days'��Ҫ��������ڣ����빫ԪY��1��1�յ��������������죬��������Ҫ��������졣 */
int getDateFromDaysSinceYYYY0101 (int days, int YYYY, int *year, int *month, int *day) {
    int tmpYear, tmpMonth, tmpDay, dayInCurYear, dayInCurMonth;
    long leftDays;

    tmpYear = YYYY;
    leftDays = days;
    while ((dayInCurYear = getDaysInYear(tmpYear)) <= leftDays) {
        leftDays -= dayInCurYear;
        tmpYear ++;
    }
    *year = tmpYear;

    if (0 == leftDays) {
        *month = 1;
        *day = 1;
        return 0;
    }

    tmpMonth = 1;
    while ((dayInCurMonth = getDaysInMonth(tmpYear, tmpMonth)) <= leftDays) {
        leftDays -= dayInCurMonth;
        tmpMonth ++;
    }
    *month = tmpMonth;

    tmpDay = 1;
    while (leftDays-- > 0) tmpDay++;
    *day = tmpDay;

    return 0;
}


/* 'days'��Ҫ��������ڣ����빫Ԫ1��1��1�յ��������������죬��������Ҫ��������졣 */
int getDateFromDaysSince00010101 (int days, int *year, int *month, int *day) {
    return getDateFromDaysSinceYYYY0101(days, 1, year, month, day);
}

/* 'days'��Ҫ��������ھ��빫Ԫ1900��1��1�յ��������������죬��������Ҫ��������졣 */
int getDateFromDaysSince19000101 (int days, int *year, int *month, int *day) {
    return getDateFromDaysSinceYYYY0101(days, 1900, year, month, day);
}

/* 'mins'��Ҫ�����ʱ�����00:00:00�ķ����� */
int getTimeFromMinsSince12AM(int mins, int *hour, int *min, int *sec) {
    int curHour, leftMins;
    curHour = 0;
    leftMins = mins;
    while (leftMins >= 60) {
        curHour ++;
        leftMins -= 60;
    }
    *hour = curHour;
    *min = leftMins;
    *sec = 0;
    return 0;
}

/* 'ssecs'��Ҫ�����ʱ�����00:00:00�ж��ٸ�10^(-'scale')�롣 */
int getTimeFromScaleSecsSince12AM(unsigned long ssecs, int scale, int *hour, int *min, int *sec, int *msec, int *usec) {
    unsigned long secs;
    int curHour, curMin, base;
    int i;

    /* ΢�� */
    base = 1;
    for (i=7; i<=scale; i++) {
        base *= 10;
    }
    if (scale >= 6) {
        *usec = (ssecs/base)%1000;
    } else {
        *usec = 0;
    }

    /* ���� */
    base = 1;
    for (i=4; i<=scale; i++) {
        base *= 10;
    }
    if (scale >= 3) {
        *msec = (ssecs/base)%1000;
    } else {
        *msec = 0;
    }

    /* Сʱ */
    secs = ssecs;
    for (i=0; i<scale; i++) {
        secs /= 10;
    }
    curHour = 0;
    while (secs >= 3600) {
        curHour ++;
        secs -= 3600;
    }
    *hour = curHour;

    /* ����/�� */
    curMin = 0;
    while (secs >= 60) {
        curMin ++;
        secs -= 60;
    }
    *min = curMin;
    *sec = secs;
    return 0;
}

/*==================================================================================*/
/* ��ӡ����־�ȸ������� */
#define PRINT_ERR_MSG(s) fprintf(stderr, "ERROR : <%s> : %d : %s\n", __FILE__, __LINE__, (s))

#define CLR_ZERO_CHARS(pos, len)                    \
do {                                                \
    int i, j;                                       \
    for (i=0,j=0; i<len;) {                         \
        if ('\0'!=pos[i]) pos[j++]=pos[i++];        \
        else i++;                                   \
    }                                               \
    pos[j] = '\0';                                  \
}while(0)

#define STEP(pos, leftlen, type_size, type, obj)    \
do {                                                \
    if (leftlen >= (type_size)) {                   \
        (obj) = *(type *)(pos);                     \
        (pos) += (type_size);                       \
    } else {PRINT_ERR_MSG("short of length"); return -1;}      \
}while(0)

/* 'pos'��ǰ��'nbytes'�ֽ� */
#define STEP_N(pos, len, nbytes)                    \
do {                                                \
    if ((len) >= (nbytes)) {                        \
        (pos) += nbytes;                            \
    } else {                                        \
        PRINT_ERR_MSG("short of length"); return -1;           \
    }                                               \
}while(0)

/* ��'pointer'ָ��'pos'��'pos'��ǰ��'nbytes'�ֽ� */
#define STEP_PL(pos, len, pointer, nbytes)          \
do {                                                \
    (pointer) = (unsigned char *)(pos);                              \
    if ((len) >= (nbytes)) {                        \
        (pos) += nbytes;                            \
    } else {                                        \
        PRINT_ERR_MSG("short of length"); return -1;    \
    }                                               \
}while(0)

#define COPY_STR(dst, size, src, slen)              \
do {                                                \
    if ((size)>(slen)) {                            \
        memcpy(dst,src,slen);                       \
    } else {PRINT_ERR_MSG("lack of space"); return -1;} \
}while(0)

/*==================================================================================*/
/* 2.2.3�ڣ�TDSЭ��ͷ */
/* TDSЭ��ͷ��'type'�ֶε�ȡֵ��
   <1>���г�'TYPE_Attention_signal'�⣬������������
   <2>server���͵����а�������'TYPE_Tabular_result'����*/
#define TYPE_SQL_batch 0x01
#define TYPE_Pre_TDS7_Login 0x02 /* Only legacy clients that support SQL Server versions that were released prior to sql_server 7.0 can use Pre-TDS7 Login. */
#define TYPE_RPC  0x03
#define TYPE_Tabular_result  0x04
#define TYPE_Attention_signal 0x06
#define TYPE_Bulk_load_data 0x07 /* This message sent to the server contains bulk data to be inserted. */
#define TYPE_Federated_Authentication_Token 0x08 /* Federated authentication is not supported by SQL Server. */
#define TYPE_Transaction_manager_request 0x0e
#define TYPE_TDS7_Login 0x10 /* Only clients that support sql_server 7.0 or later can use TDS7 Login. */
#define TYPE_SSPI 0x11
#define TYPE_Pre_Login 0x12

/* ���ݿ�������ͱ�ʶ */
#define Pre_Login_flag 12
#define Pre_TDS7_Login_flag 13
#define TDS7_Login_flag 13
#define Federated_Authentication_Token_flag 14
#define Bulk_load_data_flag 15
#define RPC_flag 16
#define Attention_signal_flag 17
#define Transaction_manager_request_flag 18
#define SSPI_flag 17
#define select_flag 6
#define update_flag 7
#define delete_flag 8
#define insert_flag 9
#define creat_flag 10
#define drop_flag 11
#define other_sql_flag 19
#define other_flag 20

#define error_flag (-1)


/* TDSЭ��ͷ��'status'�ֶ���λ��������������λ�Ķ��塣��������λӦ�ú��� */
#define STATUS_Normal_message 0x00   /* "Normal" message */
#define STATUS_EOM 0x01  /* End of message (EOM). The packet is the last packet in the whole request. */
#define STATUS_Ignore_this_event 0x02 /* (From client to server) Ignore this event (0x01 MUST also be set) */
#if __TDS_7_1
#define STATUS_RESETCONNECTION 0x08 /* (From client to server) Reset this connection before processing event */
#endif
#if __TDS_7_3
#define STATUS_RESETCONNECTIONSKIPTRAN 0x10 /* (From client to server) Reset the connection before processing event but do not modify the transactionstate */
#endif

/* TDSЭ��ͷ����8�ֽ� */
struct TDS_header {
    unsigned char Type; /* type of message */
    unsigned char Status; /* a bit field used to indicate the message state. */
    /* It is the number o f bytes from the start of this header to the start of
       the next packet header. Length is a 2-byte, unsigned short int and is
       represented in network byte order (big-endian). */
    unsigned short Length;/* TDS���ĳ��ȣ�����8�ֽڵı�Э��ͷ�������ֽ���(������ֽ���) */
    /* the process ID on the server, corresponding to the current connection
       It is provided for debugging purposes.
       This is a 2-byte value and is represented in network byte order (big-endian) */
    unsigned short SPID;/* server�϶�Ӧ�����ӵĽ���ID������Э��ջdebug���ɺ��ԡ������ֽ���(������ֽ���) */
    /* used for numbering message packets that contain data in addition to the packet header.
       This value is currently ignored. */
    unsigned char PacketID;
    unsigned char Window;/* This 1 byte is currently not used */
};

/*==================================================================================*/
/* ����2.2.4�ڣ��б�tokenTypeֵ(��ALTMETADATA_TOKEN)�����ĸ���� */
#define is_zero_length_token(token) ((token)&0x30 == 0x10) /* û�������� */
#define is_fixed_length_token_1(token) ((token)&0x3c == 0x30) /* ���1�ֽ����� */
#define is_fixed_length_token_2(token) ((token)&0x3c == 0x34) /* ���2�ֽ����� */
#define is_fixed_length_token_4(token) ((token)&0x3c == 0x38) /* ���4�ֽ����� */
#define is_fixed_length_token_8(token) ((token)&0x3c == 0x3c) /* ���8�ֽ����� */
#define is_variale_length_token(token) ((token)&0x30 == 0x20) /* ���1������ֵ+�ó��ȵ����� */
#define is_variale_count_token(token) ((token)&0x30 == 0x00) /* ���1����ĸ���n+n���� */

/*==================================================================================*/
/* 2.2.5.1�� */
/* All integer types are represented in reverse byte order (little-endian) unless
   otherwise specified
   ע�� - �ڹ�˾�����ϣ�long/unsigned long/long long /unsigned long long����8λ */
typedef unsigned char BYTE;                /* BYTE = 8BIT */
typedef unsigned char BYTELEN;             /* BYTELEN = BYTE */
typedef unsigned short USHORT;             /* USHORT = 2BYTE */
typedef long LONG;                         /* LONG = 4BYTE */
typedef unsigned int ULONG;                /* ULONG = 4BYTE */
typedef unsigned int DWORD;                /* DWORD = 32BIT */
typedef long long LONGLONG;                /* LONGLONG = 8BYTE */
typedef unsigned long ULONGLONG;           /* ULONGLONG = 8BYTE */
typedef unsigned char UCHAR;               /* UCHAR = BYTE */
typedef unsigned short USHORTLEN;          /* USHORTLEN = 2BYTE */
typedef unsigned short USHORTCHARBINLEN;   /* USHORTCHARBINLEN = 2BYTE */
typedef int LONGLEN;                       /* LONGLEN = 4BYTE */
typedef unsigned int ULONGLEN;             /* ULONGLEN = 4BYTE */
typedef unsigned long ULONGLONGLEN;        /* ULONGLONGLEN = 8BYTE */
typedef unsigned char PRECISION;           /* PRECISION = 8BIT */
typedef unsigned char SCALE;               /* SCALE = 8BIT */
#define GEN_NULL 0x00 /* A single byte (8-bit) value representing a NULL value */
#define CHARBIN_NULL2 0xffff /* a T-SQL NULL value for a character or binary data type. */
#define CHARBIN_NULL4 0xffffffff /* a T-SQL NULL value for a character or binary data type. */
#define FRESERVEDBYTE 0x00; /* a BYTE value used for padding that does not transmit information. */
typedef unsigned short UNICODECHAR;

/*==================================================================================*/
/* 2.2.5.1.2�ڣ�COLLATION���� */
struct __COLLATION {
    ULONG Flags;
    UCHAR SortId;
};

/* ��'len'�ֽڵ�'data'ָ������ݿ�ͷ��'struct __COLLATION'�ṹ��������������
   'res'���棬�ýṹ������󸳸�'len'�����ء�
   �ɹ�����0��ʧ�ܷ���-1�� */
int COLLATION_parse (char *data, int *len, struct __COLLATION *res) {
    int leftlen = *len;
    char *pos = data;

    if (leftlen <= 0) {PRINT_ERR_MSG("leftlen <= 0"); return -1;}
    STEP(pos, *len-(pos-data), 4, ULONG, res->Flags);
    STEP(pos, *len-(pos-data), 1, UCHAR, res->SortId);
    *len = pos-data;
    return 0;
}

/*==================================================================================*/
/* 2.2.5.2.2С�� */
struct __B_VARCHAR {
    BYTELEN wlen; /* ��λ2�ֽ� */
    UCHAR *data; /* �ĵ�����CHAR���ͣ����Ǵ󲿷��ֽ����Ͷ���UCHAR,��CHAR���ĵ���û���� */
};

struct __US_VARCHAR {
    USHORTLEN wlen; /* ��λ2�ֽ� */
    UCHAR *data;
};

struct __B_VARBYTE {
    BYTELEN blen; /* ��λ1�ֽ� */
    BYTE *data;
};

struct __US_VARBYTE {
    USHORTLEN blen; /* ��λ1�ֽ� */
    BYTE *data;
};

struct __L_VARBYTE {
    LONGLEN blen; /* ��λ1�ֽ� */
    BYTE *data;
};

int B_VARCHAR_parse (char *data, int *len, struct __B_VARCHAR *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}

    STEP(pos, *len-(pos-data), 1, UCHAR, res->wlen);
    STEP_PL(pos, *len-(pos-data), res->data, res->wlen *2);

    *len = pos-data;
    return 0;
}

int US_VARCHAR_parse (char *data, int *len, struct __US_VARCHAR *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}

    STEP(pos, *len-(pos-data), 2, USHORTLEN, res->wlen);
    STEP_PL(pos, *len-(pos-data), res->data, res->wlen *2);

    *len = pos-data;
    return 0;
}

int B_VARBYTE_parse (char *data, int *len, struct __B_VARBYTE *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}
    STEP(pos, *len-(pos-data), 1, BYTELEN, res->blen);
    STEP_PL(pos, *len-(pos-data), res->data, res->blen);

    *len = pos-data;
    return 0;
}

int US_VARBYTE_parse (char *data, int *len, struct __US_VARBYTE *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}
    STEP(pos, *len-(pos-data), 2, USHORTLEN, res->blen);
    STEP_PL(pos, *len-(pos-data), res->data, res->blen);

    *len = pos-data;
    return 0;
}

int L_VARBYTE_parse (char *data, int *len, struct __L_VARBYTE *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}
    STEP(pos, *len-(pos-data), 4, LONGLEN, res->blen);
    STEP_PL(pos, *len-(pos-data), res->data, res->blen);

    *len = pos-data;
    return 0;
}

/*==================================================================================*/
/* 2.2.5.2.3С��: TYPE_VARLEN / PLP_BODY / TYPE_VARBYTE */

/* Data type-dependent integers can be either a BYTELEN, USHORTCHARBINLEN, or LONGLEN in length.
   This length is dependent on the TYPE_INFO associated with the message.
   <1>If the data type (for example, FIXEDLENTYPE or VARLENTYPE rule of the TYPE_INFO rule) is of type SSVARIANTTYPE,
TEXTTYPE, NTEXTTYPE, or IMAGETYPE, the integer length is LONGLEN.
   <2>If the data type is BIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, or
BIGVARBINARYTYPE, the integer length is USHORTCHARBINLEN.
   <3>For all other data types, the integer length is BYTELEN.

   len3 - SSVARIANTTYPE, TEXTTYPE, NTEXTTYPE, IMAGETYPE
   len2 - BIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, BIGVARBINARYTYPE
   len1 - ���� */
struct __TYPE_VARLEN {
    ULONGLONGLEN reallen;
    BYTELEN len1;
    USHORTCHARBINLEN len2;
    LONGLEN len4;
};

#if __TDS_7_2
#define PLP_NULL 0xFFFFFFFFFFFFFFFF        /* 8�ֽ� */
#define UNKNOWN_PLP_LEN 0xFFFFFFFFFFFFFFFE /* 8�ֽڣ���ǰ�ߣ������1λ��ͬ */
#define PLP_TERMINATOR 0x00000000          /* 4�ֽ� */

struct __PLP_CHUNK {
    ULONGLEN len;
    BYTE *data;
};

/* PLP_BODY������3�ָ�ʽ
   ��'len'�����PLP_NULLʱ��'struct __PLP_BODY'��ֻ����1����Ĵ�С
   ��'len'�����UNKNOWN_PLP_LENʱ��'len'������PLP_CHUNK������PLP_TERMINATOR��β
   ��'len'��������ֵʱ��'len'������PLP_CHUNK������ЩPLP_CHUNK���ܳ���'len'�ֽ�
   Unlike fixed or variable byte stream formats, Partially length-prefixed bytes (PARTLENTYPE), introduced in TDS 7.2, do not require the full data length to be specified before the actual data is streamed out.
   Thus, it is ideal for those applications where the data length is not known upfront (that is, xml serialization).
   A value sent as PLP can be either
   <1>NULL,
   <2>a length followed by chunks (as defined by PLP_CHUNK),
   <3>or an unknown length token followed by chunks, which MUST end with a PLP_TERMINATOR.

   <1>TYPE_INFO rule specifies a Partially Length-prefixed Data type (PARTLENTYPE, see 2.2.5.4.3).
   <2>In the UNKNOWN_PLP_LEN case, the data is represented as a series of zero or more chunks, each
consisting of the length field followed by length bytes of data (see the PLP_CHUNK rule). The data
is terminated by PLP_TERMINATOR (which is essentially a zero-length chunk).
   <3>In the actual data length case, the ULONGLONGLEN specifies the length of the data and is followed
by any number of PLP_CHUNKs containing the data. The length of the data specified by
ULONGLONGLEN is used as a hint for the receiver. The receiver SHOULD validate that the length
value specified by ULONGLONGLEN matches the actual data length. */
struct __PLP_BODY {
    ULONGLONGLEN len;
    struct __PLP_CHUNK PLP_CHUNK;
};

/* TYPE_VARBYTE������NULL,���ֽ�����
   ����NULLʱ�������¼���ȡֵ
   CHARBIN_NULL2 - BIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, BIGVARBINARYTYPE
   CHARBIN_NULL4 - TEXTTYPE, NTEXTTYPE, IMAGETYPE
   GEN_NULL - ����
   ����NULLʱ����
   PLP_BODY - PARTLENTYPE���������ȡֵ(2.2.5.4.3С��)
   [TYPE_VARLEN] *BYTE - ����һ������֮�������

   TYPE_VARBYTE = GEN_NULL
                / CHARBIN_NULL
                / PLP_BODY
                / ([TYPE_VARLEN] *BYTE)
   <1>The 2-byte CHARBIN_NULL rule is used for BIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, and BIGVARBINARYTYPE types,
   <2>and the 4-byte CHARBIN_NULL rule is used for TEXTTYPE, NTEXTTYPE, and IMAGETYPE.
   <3>The GEN_NULL rule applies to all other types aside from PLP*/
struct __TYPE_VARBYTE {
#if __TDS_7_2
    struct __PLP_BODY PLP_BODY;
#endif
    struct __TYPE_VARLEN len;
    BYTE *data;
};

/* 2.2.5.5.3С�ڣ�XML_INFO����
   XML_INFO = SCHEMA_PRESENT [DBNAME OWNING_SCHEMA XML_SCHEMA_COLLECTION]
   ��SCHEMA_PRESENT=0x01ʱ���к���[]�в��֡�=0x00��û�С� */
struct __XML_INFO {
    BYTE SCHEMA_PRESENT;/* specifies "0x01" if the type has an associated schema collection and DBNAME, OWNING_SCHEMA and XML_SCHEMA_COLLECTION MUST be included in the stream, or '0x00'otherwise. */
    struct __B_VARCHAR DBNAME; /* the name of the database where the schema collection is defined */
    struct __B_VARCHAR OWNING_SCHEMA; /* the name of the relational schema containing the schema collection. */
    struct __US_VARCHAR XML_SCHEMA_COLLECTION; /* the name of the XML schema collection to which the type is bound. */
};

/* 2.2.5.5.2С�ڣ�UDT_INFO���� */
#if __TDS_7_2

struct __UDT_INFO_IN_COLMETADATA {
    USHORT MAX_BYTE_SIZE;            /* max length in bytes */
    struct __B_VARCHAR DB_NAME1;     /* database name of the UDT */
    struct __B_VARCHAR SCHEMA_NAME;  /* schema name of the UDT */
    struct __B_VARCHAR TYPE_NAME;    /* type name of the UDT */
    struct __US_VARCHAR ASSEMBLY_QUALIFIED_NAME; /* name of the CLR assembly */
};

struct __UDT_INFO_IN_RPC {
    struct __B_VARCHAR DB_NAME1;     /* database name of the UDT */
    struct __B_VARCHAR SCHEMA_NAME;  /* schema name of the UDT */
    struct __B_VARCHAR TYPE_NAME;    /* type name of the UDT */
};

/* UDT_INFO = UDT_INFO_IN_COLMETADATA / UDT_INFO_IN_RPC */
struct __UDT_INFO {
    struct __UDT_INFO_IN_COLMETADATA UDT_INFO_IN_COLMETADATA; /* when sent as part of COLMETADATA */
    struct __UDT_INFO_IN_RPC UDT_INFO_IN_RPC; /* when sent as part of RPC call */
};


/* 2.2.5.6С�ڣ�TYPE_INFO����
   <1>DATE MUST NOT have a TYPE_VARLEN. The value is either 3 bytes or 0 bytes (null).
   <2>TIME, DATETIME2, and DATETIMEOFFSET MUST NOT have a TYPE_VARLEN. The lengths are
determined by the SCALE as indicated in section 2.2.5.4.2.
   <3>PRECISION and SCALE MUST occur if the type is NUMERIC, NUMERICN, DECIMAL, or DECIMALN.
   <4>SCALE (without PRECISION) MUST occur if the type is TIME, DATETIME2, or DATETIMEOFFSET
(introduced in TDS 7.3). PRECISION MUST be less than or equal to decimal 38 and SCALE MUST be
less than or equal to the precision value.
   <5>COLLATION occurs only if the type is BIGCHARTYPE, BIGVARCHRTYPE, TEXTTYPE, NTEXTTYPE,
NCHARTYPE, or NVARCHARTYPE.
   <6>UDT_INFO always occurs if the type is UDTTYPE.
   <7>XML_INFO always occurs if the type is XMLTYPE.
   <8>USHORTMAXLEN does not occur if PARTLENTYPE is XMLTYPE or UDTTYPE.
   USHORTMAXLEN = %xFFFF
   TYPE_INFO = FIXEDLENTYPE
            / (VARLENTYPE TYPE_VARLEN [COLLATION])
            / (VARLENTYPE TYPE_VARLEN [PRECISION SCALE])
            / (VARLENTYPE SCALE) ; (introduced in TDS 7.3)
            / VARLENTYPE ; (introduced in TDS 7.3)
            / (PARTLENTYPE
              [USHORTMAXLEN]
              [COLLATION]
              [XML_INFO]
              [UDT_INFO])*/
#define FIXEDLENTYPE_ONLY 0
#define VARLENTYPE_TYPE_VARLEN 1
#define VARLENTYPE_TYPE_VARLEN_COLLATION 2
#define VARLENTYPE_TYPE_VARLEN_PRECISION_SCALE 3
#define VARLENTYPE_SCALE 4
#define VARLENTYPE_ONLY 5
#define PARTLENTYPE_USHORTMAXLEN 6
#define PARTLENTYPE_USHORTMAXLEN_COLLATION 7
#define PARTLENTYPE_XML_INFO 8
#define PARTLENTYPE_UDT_INFO 9

struct __TYPE_INFO {
    int typeFlag;
    /* ȡ2.2.5.4.1�ں�2.2.5.4.2�ڵ�ֵ
       ��ֵ��TYPE_INFO��������3����ʽ��������3���ϲ���һ��
       <1>2.2.5.4.1�ڶ����FIXEDLENTYPE
       <2>2.2.5.4.2�ڶ����VARLENTYPE
       <3>2.2.5.4.3�ڶ����PARTLENTYPE */
    UCHAR LENTYPE;
    /* 2.2.5.2.3�ڶ���
       'LENTYPE'��SSVARIANTTYPE,TEXTTYPE, NTEXTTYPE, or IMAGETYPEʱ��'TYPE_VARLEN'=4�ֽ�
       'LENTYPE'��BIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, or BIGVARBINARYTYPEʱ��'TYPE_VARLEN'=2�ֽ�
       'LENTYPE'������ֵʱ��'TYPE_VARLEN'=1�ֽ�
       DATE MUST NOT have a TYPE_VARLEN. The value is either 3 bytes or 0 bytes (null).
       TIME, DATETIME2, and DATETIMEOFFSET MUST NOT have a TYPE_VARLEN. The lengths are determined by the SCALE as indicated in section 2.2.5.4.2*/
    ULONG TYPE_VARLEN_4; /* ��ӦSSVARIANTTYPE, TEXTTYPE, NTEXTTYPE, or IMAGETYPE */
    USHORT TYPE_VARLEN_2; /* ��ӦBIGCHARTYPE, BIGVARCHARTYPE, NCHARTYPE, NVARCHARTYPE, BIGBINARYTYPE, or BIGVARBINARYTYPE */
    UCHAR TYPE_VARLEN_1; /* ��Ӧ�������� */
    /* 2/.2.5.1.2�ڶ���
       'LENTYPE'�� BIGCHARTYPE, BIGVARCHRTYPE, TEXTTYPE, NTEXTTYPE, NCHARTYPE, or NVARCHARTYPEʱ, TYPE_INFO���и��� */
    char COLLATION[5];
    /* 2.2.5.1�ڶ���
       PRECISION and SCALE MUST occur if 'LENTYPE' is NUMERIC, NUMERICN, DECIMAL, or DECIMALN.
       SCALE (without PRECISION) MUST occur if the type is TIME, DATETIME2, or DATETIMEOFFSET (introduced in TDS 7.3). */
    PRECISION __PRECISION; /* the precision of a numeric number */
    SCALE __SCALE; /* the scale of a numeric number */
#if __TDS_7_2
    struct __XML_INFO XML_INFO;
    struct __UDT_INFO UDT_INFO;
#endif
};


int PLP_BODY_parse(char *data, int *len, struct __PLP_BODY *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}

    STEP(pos, *len-(pos-data), 8, ULONGLONGLEN, res->len);
    if (PLP_NULL != res->len) {
        if (UNKNOWN_PLP_LEN == res->len) {
            STEP(pos, *len-(pos-data), 8, ULONGLONGLEN, res->PLP_CHUNK.len);
            while (res->PLP_CHUNK.len != PLP_TERMINATOR) {
                STEP_PL(pos, *len-(pos-data), res->PLP_CHUNK.data, res->PLP_CHUNK.len);
                STEP(pos, *len-(pos-data), 8, ULONGLONGLEN, res->PLP_CHUNK.len);
            }
            STEP_N(pos, *len-(pos-data), 4);
        } else {
            STEP_N(pos, *len-(pos-data), res->len);
        }
    }
    *len = pos-data;
    return 0;
}
#endif



int TYPE_VARLEN_parse(char *data, int *len, unsigned char LENTYPE, struct __TYPE_VARLEN *res) {
    char *pos = data;

    if (*len <= 0) {PRINT_ERR_MSG("*len <= 0"); return -1;}
    switch (LENTYPE) {
#if __TDS_7_2
        case SSVARIANTTYPE:
#endif
        case TEXTTYPE:
        case NTEXTTYPE:
        case IMAGETYPE:
            STEP(pos, *len-(pos-data), 4, LONGLEN, res->len4);
            res->reallen = res->len4;
            break;
        case BIGCHARTYPE:
        case BIGVARCHRTYPE:
        case NCHARTYPE:
        case NVARCHARTYPE:
        case BIGBINARYTYPE:
        case BIGVARBINTYPE:
            STEP(pos, *len-(pos-data), 2, USHORTCHARBINLEN, res->len2);
            res->reallen = res->len2;
            break;
#if __TDS_7_2
        case XMLTYPE: /*case BIGVARCHRTYPE: case BIGVARBINTYPE: case NVARCHARTYPE:*/
        case UDTTYPE:
            break;
#endif
        default:
            STEP(pos, *len-(pos-data), 1, BYTELEN, res->len1);
            res->reallen = res->len1;
    }

    *len = pos-data;
    return 0;
}

int TYPE_VARBYTE_parse (char *data, int *len, struct __TYPE_INFO *typeInfoRes, struct __TYPE_VARBYTE *res) {
    char *pos = data;
    ULONGLEN tmplen;

    /* TYPE_VARBYTE = PLP_BODY
       ע�� - PLP_CHUNK���len��data���Ҫcopy��res->len.reallen��res->data�������Ժ�ʹ��*/
    switch (typeInfoRes->typeFlag) {
        case PARTLENTYPE_USHORTMAXLEN:
        case PARTLENTYPE_USHORTMAXLEN_COLLATION:
        case PARTLENTYPE_XML_INFO:
        case PARTLENTYPE_UDT_INFO:
            STEP(pos, *len, 8, ULONGLONGLEN, res->PLP_BODY.len);
            if (0xFFFFFFFFFFFFFFFF == res->PLP_BODY.len) {
                *len = pos -data;
                res->len.reallen = 0;
                res->data = NULL;
                return 0;
            } else {
                STEP(pos, *len-(pos-data), 4, ULONGLEN, tmplen);
                while (tmplen != 0) {
                    res->PLP_BODY.PLP_CHUNK.len = tmplen;
                    STEP_PL(pos, *len-(pos-data), res->PLP_BODY.PLP_CHUNK.data, res->PLP_BODY.PLP_CHUNK.len);
                    STEP(pos, *len-(pos-data), 4, ULONGLEN, tmplen);
                }
                *len = pos - data;
                res->len.reallen = res->PLP_BODY.PLP_CHUNK.len;
                res->data = res->PLP_BODY.PLP_CHUNK.data;
                return 0;
            }

    }

    /* TYPE_VARBYTE = GEN_NULL / CHARBIN_NULL2 / CHARBIN_NULL4 / TYPE_VARLEN *BYTE */
    switch (typeInfoRes->LENTYPE) {
        case GUIDTYPE:
        case INTNTYPE:            //(see below) For INTNTYPE, the only valid lengths are 0x01, 0x02, 0x04, and 0x08, which map to tinyint, smallint, int, and bigint SQL data types respectively.
        case DECIMALTYPE:         //Decimal (legacy support)
        case NUMERICTYPE:         //Numeric (legacy support)
        case BITNTYPE:            //(see below) For BITNTYPE, the only valid lengths are 0x01 for non-null instances and 0x00 for NULL instances.
        case DECIMALNTYPE:       //Decimal
        case NUMERICNTYPE:        //Numeric
        case FLTNTYPE:            //(see below) For FLTNTYPE, the only valid lengths are 0x04 and 0x08, which map to 7-digit precision float and 15-digit precision float SQL data types respectively.
        case MONEYNTYPE:          //(see below) For MONEYNTYPE, the only valid lengths are 0x04 and 0x08, which map to smallmoney and money SQL data types respectively.
        case DATETIMNTYPE:        //(see below) For DATETIMNTYPE, the only valid lengths are 0x04 and 0x08, which map to smalldatetime and datetime SQL data types respectively.
#if __TDS_7_3
        case DATENTYPE:           //(introduced in TDS 7.3) For DATENTYPE, the only valid lengths are 0x03 for non-NULL instances and 0x00 for NULL instances.
        case TIMENTYPE:           //(introduced in TDS 7.3)
        case DATETIME2NTYPE:      //(introduced in TDS 7.3)
        case DATETIMEOFFSETNTYPE: //(introduced in TDS 7.3)
#endif
        case CHARTYPE:            //Char (legacy support)
        case VARCHARTYPE:         //VarChar (legacy support)
        case BINARYTYPE :         //Binary (legacy support)
        case VARBINARYTYPE:       //VarBinary (legacy support)
            if (GEN_NULL == *pos) {
                res->data = NULL;
                *len = 1;
                return 0;
            }
            STEP(pos, *len, 1, BYTELEN, res->len.len1);
            res->len.reallen = res->len.len1;
            STEP_PL(pos, *len-(pos-data), res->data, res->len.reallen);
            *len = pos-data;
            return 0;
        case BIGVARBINTYPE:
        case BIGVARCHRTYPE:
        case BIGBINARYTYPE:
        case BIGCHARTYPE:
        case NVARCHARTYPE:
        case NCHARTYPE:
            if (CHARBIN_NULL2 == *(USHORT *)pos) {
                res->data = NULL;
                *len = 2;
                return 0;
            }
            STEP(pos, *len, 2, USHORTCHARBINLEN, res->len.len2);
            res->len.reallen = res->len.len2;
            STEP_PL(pos, *len-(pos-data), res->data, res->len.reallen);
            *len = pos-data;
            return 0;
#if __TDS_7_2
        case XMLTYPE:
#endif
        case TEXTTYPE:
        case IMAGETYPE:
        case NTEXTTYPE:
#if __TDS_7_2
        case SSVARIANTTYPE:
#endif
			if (CHARBIN_NULL4 == *(ULONG *)pos) {
                res->data = NULL;
			    *len = 4;
			    return 0;
			}
            STEP(pos, *len, 4, LONGLEN, res->len.len4);
            res->len.reallen = res->len.len4;
            STEP_PL(pos, *len-(pos-data), res->data, res->len.reallen);
            *len = pos - data;
            return 0;
	}

    /* TYPE_VARBYTE = *BYTE */
    switch (typeInfoRes->LENTYPE) {
        case NULLTYPE:     // Null,�޺�������
            res->data = NULL;
            *len = 0;
            return 0;
        case INT1TYPE:     // TinyInt��1�ֽ�
        case BITTYPE:      // Bit��1�ֽ�
            res->data = (BYTE *)data;
            *len = 1;
            return 0;
        case INT2TYPE:     // SmallInt��2�ֽ�
            res->data = (BYTE *)data;
            *len = 2;
            return 0;
        case INT4TYPE:     // Int��4�ֽ�
        case DATETIM4TYPE: // SmallDateTime��4�ֽ�
        case FLT4TYPE:     // Real��4�ֽ�
        case MONEY4TYPE:   // SmallMoney��4�ֽ�
	        res->data = (BYTE *)data;
	        *len = 4;
	        return 0;
        case MONEYTYPE:    // Money��8�ֽ�
        case DATETIMETYPE: // DateTime��8�ֽ�
        case FLT8TYPE:     // Float��8�ֽ�
        case INT8TYPE:     // BigInt��8�ֽ�
	        res->data = (BYTE *)data;
	        *len = 8;
	        return 0;
    }
    *len = pos-data;
    return 0;
}

/*==================================================================================*/
/* 2.2.5.3С�ڣ�ALL_HEADERS���� */
/* 'struct __ALL_HEADERS'��'HeaderType'�Ŀ���ȡֵ */
#if __TDS_7_2
#define HeaderType_Query_Notifications 0x0001
#define HeaderType_Transaction_Descriptor 0x0002
#if __TDS_7_4
#define HeaderType_Trace_Activity 0x0003
#endif

struct __Header {
    DWORD HeaderLength; /* Total length of an individual header, including itself */
    USHORT HeaderType;  /* The type of header, */
    BYTE *HeaderData;   /* The data stream for the header */
};

struct __ALL_HEADERS {
    DWORD TotalLength;      /* Total length of ALL_HEADERS stream, including itself */
    struct __Header Header; /* Ӧ���Ƕ��Header�����˴�Ϊ�˵������������� */
};

/* ALL_HEADERS��3�����͵�HeaderData�Ľṹ */
struct Query_Notifications_Header {
    USHORT NotifyId_len; /* ��λ1�ֽ� */
    UCHAR *NotifyId; /* user specified value when subscribing to the query notification */
    USHORT SSBDeployment_len; /* ��λ1�ֽ� */
    UCHAR *SSBDeployment;
    ULONG NotifyTimeout; /* ��ѡ�أ�duration in which the query notification subscription is valid */
};

struct Transaction_Descriptor_Header {
    ULONGLONG TransactionDescriptor; /* number of requests currently active on the connection */
    /* For each connection, a number that uniquely identifies the transaction the
       request is associated with.Initially generated by the server when a new
       transaction is created and returned to the client as part of the ENVCHANGE
       token stream. */
    DWORD OutstandingRequestCount;
};

#if __TDS_7_4
struct Trace_Activity_Header {
    BYTE ActivityId[20];/* client Activity ID for debugging purposes */
};
#endif

int ALL_HEADERS_parse (char *data, int *len, struct __ALL_HEADERS *res) {
    char *pos = data;

    STEP(pos, *len, 4, DWORD, res->TotalLength);
    if (*len >= res->TotalLength)
        pos = data + res->TotalLength; /* ע���ֵ�������ṹ���ֽ��� */
    else {
        if ('\0'==pos[1] && '\0'==pos[3]) {
            *len = 0;
            return 0;
        }
        PRINT_ERR_MSG("lack of data");
        return -1;
    }
    *len = pos - data;
    return 0;
}
#endif

/*==================================================================================*/

int UDT_INFO_parse (char *data, int *len, int isRPC, struct __UDT_INFO *res) {
    char *pos = data;
    int leftlen, retval;

    if (isRPC) {
        leftlen = *len;
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_RPC.DB_NAME1));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_RPC.SCHEMA_NAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_RPC.TYPE_NAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);
    } else {
        STEP(pos, *len, 2, USHORT, res->UDT_INFO_IN_COLMETADATA.MAX_BYTE_SIZE);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_COLMETADATA.DB_NAME1));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_COLMETADATA.SCHEMA_NAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_COLMETADATA.TYPE_NAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = US_VARCHAR_parse(pos, &leftlen, &(res->UDT_INFO_IN_COLMETADATA.ASSEMBLY_QUALIFIED_NAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);
    }

    *len = pos - data;
    return 0;
}
#endif

/*==================================================================================*/
#if __TDS_7_2
int XML_INFO_parse (char *data, int *len, struct __XML_INFO *res) {
    char *pos = data;
    int leftlen, retval;

    STEP(pos, *len, 1, BYTE, res->SCHEMA_PRESENT);
    if (0x01 == res->SCHEMA_PRESENT) {
        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->DBNAME));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->OWNING_SCHEMA));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = (*len - (pos-data));
        retval = US_VARCHAR_parse(pos, &leftlen, &(res->XML_SCHEMA_COLLECTION));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);
    }

    *len = pos - data;
    return 0;
}

#endif

/*==================================================================================*/
/* 2.2.5.4С�ڣ���Щ�����Ƶ��ļ��������� */

/*==================================================================================*/
/* 2.2.5.5С�ڣ�TVP���������������2.2.5.6�ڵ�TYPE_INFO���壬����Ų��2.2.5.6�ں��� */

/*==================================================================================*/
/* 2.2.5.6С�ڣ�TYPE_INFO����
   <1>DATE MUST NOT have a TYPE_VARLEN. The value is either 3 bytes or 0 bytes (null).
   <2>TIME, DATETIME2, and DATETIMEOFFSET MUST NOT have a TYPE_VARLEN. The lengths are
determined by the SCALE as indicated in section 2.2.5.4.2.
   <3>PRECISION and SCALE MUST occur if the type is NUMERIC, NUMERICN, DECIMAL, or DECIMALN.
   <4>SCALE (without PRECISION) MUST occur if the type is TIME, DATETIME2, or DATETIMEOFFSET
(introduced in TDS 7.3). PRECISION MUST be less than or equal to decimal 38 and SCALE MUST be
less than or equal to the precision value.
   <5>COLLATION occurs only if the type is BIGCHARTYPE, BIGVARCHRTYPE, TEXTTYPE, NTEXTTYPE,
NCHARTYPE, or NVARCHARTYPE.
   <6>UDT_INFO always occurs if the type is UDTTYPE.
   <7>XML_INFO always occurs if the type is XMLTYPE.
   <8>USHORTMAXLEN does not occur if PARTLENTYPE is XMLTYPE or UDTTYPE.
   USHORTMAXLEN = %xFFFF
   TYPE_INFO = FIXEDLENTYPE
            / (VARLENTYPE TYPE_VARLEN [COLLATION])
            / (VARLENTYPE TYPE_VARLEN [PRECISION SCALE])
            / (VARLENTYPE SCALE) ; (introduced in TDS 7.3)
            / VARLENTYPE ; (introduced in TDS 7.3)
            / (PARTLENTYPE
              [USHORTMAXLEN]
              [COLLATION]
              [XML_INFO]
              [UDT_INFO])*/

/* TYPE_INFO�Ľ���
   'data'ָ��TYPE_INFO���ݵĿ�ͷ
   'len'�����ݵ��ֽڳ��ȣ����������������TYPE_INFO���ݲ��ֵ��ֽڳ���
   'TYPE_INFO'����������
   �ɹ�����0��ʧ�ܷ���-1*/
int TYPE_INFO_parse (char *data, int *len, struct __TYPE_INFO *TYPE_INFO, int isRPC) {
    char * pos = data;
    int leftlen, retval;

    STEP(pos, *len, 1, UCHAR, TYPE_INFO->LENTYPE);

    switch (TYPE_INFO->LENTYPE) {
#if __TDS_7_2
        case XMLTYPE:/* TYPE_INFO = PARTLENTYPE XML_INFO */
            leftlen = *len - (pos-data);
            retval = XML_INFO_parse(pos, &leftlen, &(TYPE_INFO->XML_INFO));
            if (retval < 0) return -1;
            STEP_N(pos, *len - (pos-data), leftlen);
            *len = pos - data;
            TYPE_INFO->typeFlag = PARTLENTYPE_XML_INFO;
            return 0;
        case UDTTYPE:/* TYPE_INFO = PARTLENTYPE UDT_INFO */
            leftlen = *len - (pos-data);
            retval = UDT_INFO_parse(pos, &leftlen, isRPC, &(TYPE_INFO->UDT_INFO));
            if (retval < 0) return -1;
            STEP_N(pos, *len - (pos-data), leftlen);
            *len = pos - data;
            TYPE_INFO->typeFlag = PARTLENTYPE_UDT_INFO;
            return 0;
#endif
        case BIGVARBINTYPE:/* TYPE_INFO = PARTLENTYPE 0xFFFF */
            if (0xFFFF == *(USHORTLEN *)pos) {
                STEP_N(pos, *len-(pos-data), 2);
                *len = pos - data;
                TYPE_INFO->typeFlag = PARTLENTYPE_USHORTMAXLEN;
                return 0;
            }
        case BIGVARCHRTYPE:/* TYPE_INFO = PARTLENTYPE 0xFFFF COLLATION */
        case NVARCHARTYPE:
            if (0xFFFF == *(USHORTLEN *)pos) {
                STEP_N(pos, *len-(pos-data), 7);
                *len = pos - data;
                TYPE_INFO->typeFlag = PARTLENTYPE_USHORTMAXLEN_COLLATION;
                return 0;
            }
    }

    /* TYPE_INFO = FIXEDLENTYPE */
    switch (TYPE_INFO->LENTYPE) {
        /* FIXEDLENTYPE���ͷ�Χ */
        case NULLTYPE:
        case INT1TYPE:
        case BITTYPE:
        case INT2TYPE:
        case INT4TYPE:
        case DATETIM4TYPE:
        case FLT4TYPE:
        case MONEYTYPE:
        case DATETIMETYPE:
        case FLT8TYPE:
        case MONEY4TYPE:
        case INT8TYPE:
            *len = 1;
            TYPE_INFO->typeFlag = FIXEDLENTYPE_ONLY;
            return 0;

        /* VARLENTYPE=BYTELEN_TYPE / USHORTLEN_TYPE / LONGLEN_TYPE���ͷ�Χ */
        /* BYTELEN_TYPE��Χ */
        case GUIDTYPE:
        case INTNTYPE:
        case DECIMALTYPE:
        case NUMERICTYPE:
        case BITNTYPE:
        case DECIMALNTYPE:
        case NUMERICNTYPE:
        case FLTNTYPE:
        case MONEYNTYPE:
        case DATETIMNTYPE:
#if __TDS_7_3
        case DATENTYPE:
        case TIMENTYPE:
        case DATETIME2NTYPE:
        case DATETIMEOFFSETNTYPE:
#endif
        case CHARTYPE:
        case VARCHARTYPE:
        case BINARYTYPE:
        case VARBINARYTYPE:

        /* USHORTLEN_TYPE��Χ */
        case BIGVARBINTYPE:
        case BIGVARCHRTYPE:
        case BIGBINARYTYPE:
        case BIGCHARTYPE:
        case NVARCHARTYPE:
        case NCHARTYPE:

        /* LONGLEN_TYPE��Χ */
#if __TDS_7_2
        case XMLTYPE:
#endif
        case TEXTTYPE:
        case IMAGETYPE:
        case NTEXTTYPE:
#if __TDS_7_2
        case SSVARIANTTYPE:
#endif

#if __TDS_7_3
            /* TYPE_INFO = VARLENTYPE */
            /* <1>DATE MUST NOT have a TYPE_VARLEN. The value is either 3 bytes or 0 bytes (null). */
            if (DATENTYPE == TYPE_INFO->LENTYPE) {
                *len = 1;
                TYPE_INFO->typeFlag = VARLENTYPE_ONLY;
                return 0;
            }

            /* TYPE_INFO = VARLENTYPE SCALE */
            /* <2>TIME, DATETIME2, and DATETIMEOFFSET MUST NOT have a TYPE_VARLEN. The lengths are determined by the SCALE */
            /* <4>SCALE (without PRECISION) MUST occur if the type is TIME, DATETIME2, or DATETIMEOFFSET (introduced in TDS 7.3). PRECISION MUST be less than or equal to decimal 38 and SCALE MUST be less than or equal to the precision value. */
            if (TIMENTYPE==TYPE_INFO->LENTYPE || DATETIME2NTYPE==TYPE_INFO->LENTYPE
                || DATETIMEOFFSETNTYPE==TYPE_INFO->LENTYPE) {
                STEP(pos, *len-(pos-data), 1, SCALE, TYPE_INFO->__SCALE);
                *len = 2;
                TYPE_INFO->typeFlag = VARLENTYPE_SCALE;
                return 0;
            }
#endif

            /* TYPE_INFO = VARLENTYPE TYPE_VARLEN PRECISION SCALE*/
            /* <3>PRECISION and SCALE MUST occur if the type is NUMERIC, NUMERICN, DECIMAL, or DECIMALN. */
            if (NUMERICTYPE==TYPE_INFO->LENTYPE || NUMERICNTYPE==TYPE_INFO->LENTYPE
                || DECIMALTYPE==TYPE_INFO->LENTYPE || DECIMALNTYPE==TYPE_INFO->LENTYPE) {
                STEP(pos, *len-(pos-data), 1, UCHAR, TYPE_INFO->TYPE_VARLEN_1);
                STEP(pos, *len-(pos-data), 1, PRECISION, TYPE_INFO->__PRECISION);
                STEP(pos, *len-(pos-data), 1, SCALE, TYPE_INFO->__SCALE);
                *len = 4;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN_PRECISION_SCALE;
                return 0;
            }

            /* TYPE_INFO = VARLENTYPE TYPE_VARLEN COLLATION*/
            /* <5>COLLATION occurs only if the type is BIGCHARTYPE, BIGVARCHRTYPE, TEXTTYPE, NTEXTTYPE, NCHARTYPE, or NVARCHARTYPE */
            if (BIGCHARTYPE==TYPE_INFO->LENTYPE || BIGVARCHRTYPE==TYPE_INFO->LENTYPE
                || NCHARTYPE==TYPE_INFO->LENTYPE || NVARCHARTYPE==TYPE_INFO->LENTYPE ) {
                STEP(pos, *len-(pos-data), 2, USHORT, TYPE_INFO->TYPE_VARLEN_2);
                memcpy(TYPE_INFO->COLLATION, pos, 5);
                *len = 8;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN_COLLATION;
                return 0;
            }
            if (TEXTTYPE==TYPE_INFO->LENTYPE || NTEXTTYPE==TYPE_INFO->LENTYPE) {
                STEP(pos, *len-(pos-data), 4, ULONG, TYPE_INFO->TYPE_VARLEN_4);
                memcpy(TYPE_INFO->COLLATION, pos, 5);
                *len = 10;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN_COLLATION;
                return 0;
            }

            /* TYPE_INFO = VARLENTYPE TYPE_VARLEN*/
            if (TEXTTYPE==TYPE_INFO->LENTYPE || NTEXTTYPE==TYPE_INFO->LENTYPE || IMAGETYPE==TYPE_INFO->LENTYPE
#if __TDS_7_2
                || SSVARIANTTYPE==TYPE_INFO->LENTYPE
#endif
                ) {
                STEP(pos, *len-(pos-data), 4, ULONG, TYPE_INFO->TYPE_VARLEN_4);
                *len = 5;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN;
                return 0;
            } else if (BIGCHARTYPE==TYPE_INFO->LENTYPE || BIGVARCHRTYPE==TYPE_INFO->LENTYPE
                       || NCHARTYPE==TYPE_INFO->LENTYPE || NVARCHARTYPE==TYPE_INFO->LENTYPE
                       || BIGBINARYTYPE==TYPE_INFO->LENTYPE || BIGVARBINTYPE==TYPE_INFO->LENTYPE ) {
                STEP(pos, *len-(pos-data), 2, USHORT, TYPE_INFO->TYPE_VARLEN_2);
                *len = 3;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN;
                return 0;
            } else {
                STEP(pos, *len-(pos-data), 1, UCHAR, TYPE_INFO->TYPE_VARLEN_1);
                *len = 2;
                TYPE_INFO->typeFlag = VARLENTYPE_TYPE_VARLEN;
                return 0;
            }
    }
    return -1;
}

/*==================================================================================*/
/* 2.2.5.5С�ڣ�TVP���������������2.2.5.6�ڵ�TYPE_INFO���壬����Ų���˴�
   At the present time, TVPs are permitted to be used only as input parameters and do not appear as output
parameters or in result set columns.
   TVPs MUST be sent only by a TDS client that reports itself as a TDS major version 7.3 or later. If a
client reporting itself as older than TDS 7.3 attempts to send a TVP, the server MUST reject the
request with a TDS protocol error.*/

struct __TVP_TYPENAME {
    struct __B_VARCHAR DbName; /* Database where TVP type resides */
    struct __B_VARCHAR OwningSchema; /* Schema where TVP type resides */
    struct __B_VARCHAR TypeName; /* TVP type name */
};

struct __TYPE_INFO;
struct __TvpColumnMetaData {
    ULONG UserType; /* UserType of column */
    USHORT Flags;
    struct __TYPE_INFO TYPE_INFO;
    struct __B_VARCHAR ColName; /* Name of column */
};

struct __TVP_COLMETADATA {
    USHORT Count; /* Column count up to 1024 max, ������0xFFFF,�򱾽ṹ�����һ���򣬺���û���� */
    struct __TvpColumnMetaData TvpColumnMetaData;
};

struct __TVP_ORDER_UNIQUE_sub {
    USHORT ColNum; /* A single-column ordinal, start with 1 */
    BYTE OrderUniqueFlags; /*  */
};

struct __TVP_ORDER_UNIQUE {
    BYTE TVP_ORDER_UNIQUE_TOKEN; /* =0x10 */
    USHORT Count; /* Count of ColNums to follow */
    struct __TVP_ORDER_UNIQUE_sub sub; /* Count���ýṹ */
};

struct __TVP_COLUMN_ORDERING {
    BYTE TVP_COLUMN_ORDERING_TOKEN; /* =0x11 */
    USHORT Count; /* Count of ColNums to follow */
    USHORT ColNum; /* A single-column ordinal, start with 1 ��������'Count'��'ColNum'���˴���������*/
};

/* Terminator tag for TVP type meaning no moreTVP_ROWs to
   follow and end of successful transmission of a single TVP */
#define TVP_END_TOKEN 0x00
struct __TVP_ROW_other {
    BYTE TokenType; /* =TVP_ROW_TOKEN */
    struct __TYPE_VARBYTE AllColumnData; /* ���struct __TYPE_VARBYTE������������. The actual data for the TVP column. */
};

struct __TVP_TYPE_INFO {
    BYTE TVPTYPE; /* =0xF3 */
    struct __TVP_TYPENAME TVP_TYPENAME; /* Type name of the TVP */
    struct __TVP_COLMETADATA TVP_COLMETADATA; /* Column-specific metadata */
    struct __TVP_ORDER_UNIQUE TVP_ORDER_UNIQUE; /* Optional metadata token */
    struct __TVP_COLUMN_ORDERING TVP_COLUMN_ORDERING; /* Optional metadata token */
    struct __TVP_ROW_other TVP_ROW; /* 0..N TVP_ROW tokens �ж�����˴������ã���TVP_END_TOKEN��β */
};


/*===============================================================================*/
/* ����2.2.5.7�� */
/* The metadata and encrypted value that describe an encryption key. */
struct __EncryptionKeyValue {
    struct __US_VARBYTE EncryptedKey;  /* The ciphertext containing the encryption key that is secured with the master. */
    struct __B_VARCHAR KeyStoreName;   /* The key store name component of the location where the master key is saved */
    struct __US_VARCHAR KeyPath;       /* The key path component of the location where the master key is saved. */
    struct __B_VARCHAR AsymmetricAlgo; /* The name of the algorithm that is used for encrypting the encryption key */
};

struct __EK_INFO {
    ULONG DatabaseId; /* A 4 byte integer value that represents the database ID where the column encryption key is stored. */
    ULONG CekId; /* An identifier for the column encryption key. */
    ULONG CekVersion; /* The key version of the column encryption key.  */
    ULONGLONG CekMDVersion; /* The metadata version for the column encryption key. */
    BYTE Count; /* The count of EncryptionKeyValue elements that are present in the message. */
    struct __EncryptionKeyValue EncryptionKeyValue; /*  */
};

int EK_INFO_parse (char *data, int *len, struct __EK_INFO *res) {
    char *pos = data;
    int leftlen, retval, n;

    STEP(pos, *len-(pos-data), 4, ULONG, res->DatabaseId);
    STEP(pos, *len-(pos-data), 4, ULONG, res->CekId);
    STEP(pos, *len-(pos-data), 4, ULONG, res->CekVersion);
    STEP(pos, *len-(pos-data), 8, ULONGLONG, res->CekMDVersion);
    STEP(pos, *len-(pos-data), 1, BYTE, res->Count);

    n = res->Count;
    while (n-- > 0) {
        leftlen = *len - (pos - data);
        retval = US_VARBYTE_parse(pos, &leftlen, &(res->EncryptionKeyValue.EncryptedKey));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = *len - (pos - data);
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->EncryptionKeyValue.KeyStoreName));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = *len - (pos - data);
        retval = US_VARCHAR_parse(pos, &leftlen, &(res->EncryptionKeyValue.KeyPath));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);

        leftlen = *len - (pos - data);
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->EncryptionKeyValue.AsymmetricAlgo));
        if (retval < 0) return -1;
        STEP_N(pos, *len-(pos-data), leftlen);
    }

    *len = pos - data;
    return 0;
}



/*==================================================================================*/
/* 2.2.5.8��, token��־�������ݵ�2.2.4���ж�, ����ʵ�ֺ궨�� */
#define ALTMETADATA_TOKEN 0x88   /* 1000 1000, ����Variable Count Tokens */
#define ALTROW_TOKEN 0xD3        /* 1101 0011, ����Zero Length Token */
#define COLMETADATA_TOKEN 0x81   /* 1000 0001, ����Variable Count Tokens */
#define COLINFO_TOKEN 0xA5       /* 1010 0101, ����Variable Length Tokens */
#define DONE_TOKEN 0xFD          /* 1111 1101, ����Fixed Length Token */
#define DONEPROC_TOKEN 0xFE      /* 1111 1110, ����Fixed Length Token */
#define DONEINPROC_TOKEN   0xFF  /* 1111 1111, ����Fixed Length Token */
#define ENVCHANGE_TOKEN 0xE3     /* 1110 0011, ����Variable Length Tokens */
#define ERROR_TOKEN 0xAA         /* 1010 1010, ����Variable Length Tokens */
#if __TDS_7_4
#define FEATUREEXTACK_TOKEN 0xAE /* 1010 1110, ����Variable Length Tokens */
#define FEDAUTHINFO_TOKEN 0xEE   /* 1110 1110, ����Variable Length Tokens */
#endif
#define INFO_TOKEN 0xAB          /* 1010 1011, ����Variable Length Tokens */
#define LOGINACK_TOKEN 0xAD      /* 1010 1101, ����Variable Length Tokens */
#if __TDS_7_3
#define NBCROW_TOKEN    0xD2     /* 1101 0010, ����Zero Length Token */
#endif
#define OFFSET_TOKEN 0x78        /* 0111 1000, ����Fixed Length Token */
#define ORDER_TOKEN 0xA9         /* 1010 1001, ����Variable Length Tokens */
#define RETURNSTATUS_TOKEN 0x79  /* 0111 1001, ����Fixed Length Token */
#define RETURNVALUE_TOKEN 0xAC   /* 1010 1100, ����Variable Length Tokens */
#define ROW_TOKEN 0xD1           /* 1101 0001, ����Zero Length Token  */
#if __TDS_7_4
#define SESSIONSTATE_TOKEN 0xE4  /* 1110 0100, ����Variable Length Tokens */
#endif
#define SSPI_TOKEN   0xED        /* 1110 1101, ����Variable Length Tokens */
#define TABNAME_TOKEN 0xA4       /* 1010 0100, ����Variable Length Tokens */

#define TVP_ROW_TOKEN 0x01       /* 2.2.5.5.5.2�ڣ�0000 0001,  */

/*==================================================================================*/
/* 2.2.7.1��, ALTMETADATA_TOKEN
   <1>Describes the data type, length, and name of column data that result from a SQL
   statement that generates totals.
   <2>The token value is 0x88.
   <3>This token is used to tell the client the data type and length of the column data. It describes the
   format of the data found in an ALTROW data stream. The ALTMETADATA and corresponding ALTROW
   MUST be in the same result set.
   <4>All ALTMETADATA data streams are grouped.
   <5>A preceding COLMETADATA MUST exist before an ALTMETADATA token. There might be COLINFO and
   TABNAME streams between COLMETADATA and ALTMETADATA. */

struct __TableName {
#if __TDS_7_2
    BYTE NumParts;
    struct __US_VARCHAR PartName; /* 'NumParts'��'PartName' */
#else
    struct __US_VARCHAR TableName;
#endif
};

/* 'struct __ComputeData.op'��ȡֵ��Χ������sqlserver��һЩ�ۺϺ��� */
#define AOPSTDEV 0x30  //Standard deviation (STDEV)
#define AOPSTDEVP 0x31 //Standard deviation of the population (STDEVP)
#define AOPVAR 0x32    //Variance (VAR)
#define AOPVARP 0x33   //Variance of population (VARP)
#define AOPCNT 0x4B    //Count of rows (COUNT)
#define AOPSUM 0x4D    //Sum of the values in the rows (SUM)
#define AOPAVG 0x4F    //Average of the values in the rows (AVG)
#define AOPMIN 0x51    //Minimum value of the rows (MIN)
#define AOPMAX 0x52    //Maximum value of the rows (MAX)

struct __ComputeData {
    BYTE Op;        /* The type of aggregate operator */
    USHORT Operand; /* The column number, starting from 1, in the result set that is the operand to the aggregate operator. */
#if __TDS_7_2
    ULONG UserType; /* The user typeID of the data type of the column. */
#else
    USHORT UserType;
#endif
    USHORT Flags;
    struct __TYPE_INFO TYPE_INFO; /* �е����� */
    struct __TableName TableName; /* ��ѡ������TYPE_INFO�жϡ�The TableName field is specified only if text, ntext, or image columns are included in the result set. */
    struct __B_VARCHAR ColName;   /* The column name. */
};

struct __ALTMETADATA {
    BYTE TokenType; /* =ALTMETADATA_TOKEN */
    USHORT Count;   /* The count of columns (number of aggregate operators) */
    USHORT Id;      /* The Id of the SQL statement to which the total column formats apply. */
    UCHAR ByCols;   /* The number of grouping columns in the SQL statement that generates totals. */
    USHORT ColNum; /* ע�� - specifying the column number as it appears in the COMPUTE clause. 'ColNum' appears 'ByCols' times. ����ֻ�������� */
    struct __ComputeData ComputeData; /* 'ByCols'��ComputeData��������ֻ�������� */
};

/* ���� - ���token�е�����ʣ�'ColNum'ȷ����'ByCols'��������'ComputeData'û��˵���Ƕ��ٸ�,'Count'����'ByCols' */
int ALTMETADATA_token_parse(char *token, int *tlen, struct __ALTMETADATA *res, int isRPC) {
    char *pos = token;
    int aCount, leftlen, retval;

    res->TokenType = *pos++;
    if (ALTMETADATA_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Count);
    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Id);
    STEP(pos, *tlen-(pos-token), 1, UCHAR, res->ByCols);

    aCount = res->ByCols;
    while (aCount-- > 0) {
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ColNum);
    }

    aCount = res->ByCols;
    while (aCount-- > 0) {

        STEP(pos, *tlen-(pos-token), 1, BYTE, res->ComputeData.Op);
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ComputeData.Operand);
#if __TDS_7_2
        STEP(pos, *tlen-(pos-token), 4, ULONG, res->ComputeData.UserType);
#else
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ComputeData.UserType);
#endif
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ComputeData.Flags);

        leftlen = *tlen - (pos-token);
        retval = TYPE_INFO_parse(pos, &leftlen, &(res->ComputeData.TYPE_INFO), isRPC);
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);

        switch (res->ComputeData.TYPE_INFO.LENTYPE) {
            case TEXTTYPE:
            case IMAGETYPE:
            case NTEXTTYPE:
#if __TDS_7_2
                STEP(pos, *tlen-(pos-token), 2, BYTE, res->ComputeData.TableName.NumParts);

                leftlen = *tlen - (pos-token);
                retval = US_VARCHAR_parse(pos, &leftlen, &(res->ComputeData.TableName.PartName));
                if (retval < 0) return -1;
                STEP_N(pos, *tlen-(pos-token), leftlen);
#else
                leftlen = *tlen - (pos-token);
                retval = US_VARCHAR_parse(pos, &leftlen, &(res->ComputeData.TableName.TableName));
                if (retval < 0) return -1;
                STEP_N(pos, *tlen-(pos-token), leftlen);
#endif
                leftlen = *tlen - (pos-token);
                retval = B_VARCHAR_parse(pos, &leftlen, &(res->ComputeData.ColName));
                if (retval < 0) return -1;
                STEP_N(pos, *tlen-(pos-token), leftlen);
        }
    }

    *tlen = pos - token;
    return 0;
}

/*==================================================================================*/
/* 2.2.7.2��, ALTROW_TOKEN */
/* <1>Used to send a complete row of total data, where the data format is provided
      by the ALTMETADATA token (2.2.7.1��).
   <2>The ALTROW token is similar to the ROW_TOKEN, but also contains an Id field.
      This Id matches an Id given in ALTMETADATA (one Id for each SQL statement).
      This provides the mechanism for matching row data with correct SQL statements.*/
struct __ALTROW {
    BYTE TokenType; /* =ALTROW_TOKEN */
    USHORT Id; /* The Id of the SQL statement that generates totals to which the total column formats apply */
    struct __TYPE_VARBYTE ComputeData; /* The actual data for the column. The ComputeData element is repeated Count times (where Count is specified in ALTMETADATA_TOKEN). �˴����������� */
};

int ALTROW_token_parse(char *token, int *tlen, struct __ALTROW *res, int Count, struct __TYPE_INFO *TYPE_INFO) {
    char *pos = token;
    int leftlen, retval;

    res->TokenType = *pos++;
    if (ALTROW_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Id);

    while (Count-- > 0) {
        leftlen = *tlen-(pos-token);
        retval = TYPE_VARBYTE_parse(pos, &leftlen, TYPE_INFO, &(res->ComputeData));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);
    }

    *tlen = pos - token;
    return 0;
}

/*==================================================================================*/
/* 2.2.7.3��, COLINFO_TOKEN */
/* Describes the column information in browse mode */

#define EXPRESSION 0x04 /* the column was the result of an expression */
#define KEY 0x08 /* the column is part of a key for the associated table */
#define HIDDEN 0x10 /* the column was not requested, but was added because it was part of a key for the associated table */
#define DIFFERENT_NAME 0x20 /* the column name is different than the requested column name in the case of a column alias */

struct __CpLProperty {
    BYTE ColNum;   /* The column number in the result set */
    BYTE TableNum; /* The number of the base table that the column was derived from. */
    BYTE Status;   /*  */
    struct __B_VARCHAR ColName; /* The base column name. This only occurs if DIFFERENT_NAME is set in Status.(���Ҫע��) */
};

struct __COLINFO {
    BYTE TokenType; /* COLINFO_TOKEN */
    USHORT Length;  /* The actual data length, in bytes, of the ColProperty stream. The length does not include token type and length field. */
    struct __CpLProperty CpLProperty; /* ����ýṹ���˴�Ϊ���� */
};

int COLINFO_token_parse(char *token, int *tlen, struct __COLINFO *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (COLINFO_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);
    STEP_N(pos, *tlen-(pos-token), res->Length); /* ֱ�����������'CpLProperty'�� */

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.4 */
#if __TDS_7_4
struct __COLMETADATA_CekTable {
    USHORT EkValueCount; /* The size of CekTable. It represents the number of entries in CekTable.*/
    struct __EK_INFO EK_INFO;
};
#endif

#if __TDS_7_2
struct __COLMETADATA_TableName {
    BYTE NumParts; /* PartName�ĸ��� */
    struct __US_VARCHAR PartName;
};
#endif

#if __TDS_7_4
#define EncryptionAlgoType_DE 1 //Deterministic encryption
#define EncryptionAlgoType_RE 2 //Randomized encryption
/* This describes the encryption metadata for a column. */
struct __COLMETADATA_CryptoMetaData {
    USHORT Ordinal; /* Where the encryption key information is located in CekTable. Ordinal starts at 0. */
    ULONG UserType; /* ��TDS7.2��ʼ��unsigned long�� */
    struct __TYPE_INFO BaseTypeInfo; /* TYPE_INFO���� */
    BYTE EncryptionAlgo; /* A byte that describes the encryption algorithm that is used. */
    struct __B_VARCHAR AlgoName; /* Algorithm name literal that is used to encrypt the plaintext value. Unicode����*/
    BYTE EncryptionAlgoType; /* encryption algorithm type */
    BYTE NormVersion; /* The normalization version to which plaintext data MUST be normalized. Version numbering starts at 0x01.  */
};
#endif

struct __COLMETADATA_ColumnData {
#if __TDS_7_2
    ULONG UserType; /* The user type ID of the data type of the column. ����0xffff, ��û�к������ */
#else
    USHORT UserType;
#endif
    USHORT Flags;
    struct __TYPE_INFO TYPE_INFO; /* ֮����token�����token���������� */
#if __TDS_7_2
    /* The TableName element is specified only if text, ntext, or image(��ǰһ����TYPE_INFOָ��)
       columns are included in the result set. */
    struct __COLMETADATA_TableName TableName;
#endif
#if __TDS_7_4
    struct __COLMETADATA_CryptoMetaData CryptoMetaData;
#endif
    struct __B_VARCHAR ColName; /* The column name, Unicode���� */
};

/* Describes the result set for interpretation of following ROW data streams.
   This token is used to tell the client the data type and length of the column data. It describes the
   format of the data found in a ROW data stream */
struct __COLMETADATA {
    BYTE TokenType; /* COLMETADATA_TOKEN */
    USHORT Count; /* The count of columns (number of aggregate operators) in the token stream */
#if __TDS_7_4
    struct __COLMETADATA_CekTable CekTable; /* A table of various encryption keys that are used to secure the plaintext data. */
#endif
    /* ��ǰ2���ֽ���0xffff,��ò��־���һ�ֽڡ������ָ����ColumnData�ṹ*/
    struct __COLMETADATA_ColumnData ColumnData[50];
};

/* 'token'ָ��token�鿪ͷ��
   'tlen'Ϊ�ÿ�������󳤶ȣ����������ظ�token�Ĵ�С
   'res'�������Ȥ�Ľ�������
   �ɹ�����0��ʧ�ܷ���-1 */
int COLMETADATA_token_parse(char *token, int *tlen, struct __COLMETADATA *res, int isRPC) {
    char *pos = token;
    int leftlen, retval, i, max;

    STEP(pos, *tlen, 1, UCHAR, res->TokenType);
    if (COLMETADATA_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Count);
    /* In the event that the client requested no metadata to be returned (see section 2.2.6.6 for
       information about the OptionFlags parameter in the RPCRequest token), the value of Count will be
       0xFFFF. This has the same effect on Count as a zero value (for example, no ColumnData is sent). */
    if (0xffff == res->Count) res->Count = 0;

#if __TDS_7_4
    STEP(pos, *tlen-(pos-token), 2, USHORT, res->CekTable.EkValueCount);

    leftlen = *tlen - (pos - token);
    retval = EK_INFO_parse(pos, &leftlen, &(res->CekTable.EK_INFO));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);
#endif

    if (0xff == *pos && 0xff == *(pos+1)) { /* ����NoMetaData */
        *tlen = pos-token+2;
        return 0;
    }

    max = (res->Count > 50) ? 50 : res->Count;
    for (i=0; i<max; i++) {
#if __TDS_7_2
        STEP(pos, *tlen-(pos-token), 4, ULONG, res->ColumnData[i].UserType);
#else
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ColumnData[i].UserType);
#endif
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ColumnData[i].Flags);

        leftlen = *tlen - (pos - token);
        retval = TYPE_INFO_parse(pos, &leftlen, &(res->ColumnData[i].TYPE_INFO), isRPC);
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);

#if __TDS_7_2
        if (TEXTTYPE == res->ColumnData[i].TYPE_INFO.LENTYPE
            || NTEXTTYPE == res->ColumnData[i].TYPE_INFO.LENTYPE
            || IMAGETYPE == res->ColumnData[i].TYPE_INFO.LENTYPE) {
            STEP(pos, *tlen-(pos-token), 1, BYTE, res->ColumnData[i].TableName.NumParts);
            while (res->ColumnData[i].TableName.NumParts-- > 0) {
                leftlen = *tlen - (pos - token);
                retval = US_VARCHAR_parse(pos, &leftlen, &(res->ColumnData[i].TableName.PartName));
                if (retval < 0) return -1;
                STEP_N(pos, *tlen-(pos-token), leftlen);
            }
        }
#endif

#if __TDS_7_4
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->ColumnData[i].CryptoMetaData.Ordinal);
        STEP(pos, *tlen-(pos-token), 4, ULONG, res->ColumnData[i].CryptoMetaData.UserType);

        leftlen = *tlen - (pos - token);
        retval = TYPE_INFO_parse(pos, &leftlen, &(res->ColumnData[i].CryptoMetaData.BaseTypeInfo), isRPC);
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);

        STEP(pos, *tlen-(pos-token), 1, BYTE, res->ColumnData[i].CryptoMetaData.EncryptionAlgo);

        leftlen = *tlen - (pos - token);
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->ColumnData[i].CryptoMetaData.AlgoName));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);

        STEP(pos, *tlen-(pos-token), 1, BYTE, res->ColumnData[i].CryptoMetaData.EncryptionAlgoType);
        STEP(pos, *tlen-(pos-token), 1, BYTE, res->ColumnData[i].CryptoMetaData.NormVersion);
#endif
        leftlen = *tlen - (pos - token);
        retval = B_VARCHAR_parse(pos, &leftlen, &(res->ColumnData[i].ColName));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);
    }

    *tlen = pos - token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.5��
   Indicates the completion status of a SQL statement. */
#define DONE_FINAL 0x00     /* This DONE is the final DONE in the request */
#define DONE_MORE 0x01      /*  This DONE message is not the final DONE message in the response */
#define DONE_ERROR 0x02     /* An error occurred on the current SQL statement. */
#define DONE_INXACT 0x04    /* A transaction is in progress */
#define DONE_COUNT 0x10     /* The DoneRowCount value is valid */
#define DONE_ATTN 0x20      /* The DONE message is a server acknowledgement of a client ATTENTION message */
#define DONE_RPCINBATCH 0x80
#define DONE_SRVERROR 0x100 /* Used in place of DONE_ERROR when an error occurred on the current SQL statement */

struct __DONE {
    BYTE TokenType; /* =DONE_TOKEN */
    USHORT Status; /* ����ֵ��������м�����λ�� */
    USHORT CurCmd; /* The token of the current SQL statement */
    /* The count of rows that were affected by the SQL statement.  */
#if __TDS_7_2
    ULONGLONG DoneRowCount;
#else
    LONG DoneRowCount;
#endif
};

/* 'token'ָ��token�鿪ͷ��
   'tlen'Ϊ�ÿ�������󳤶ȣ����������ظ�token�Ĵ�С
   'res'�������Ȥ�Ľ�������
   �ɹ�����0��ʧ�ܷ���-1 */
int DONE_token_parse(char *token, int *tlen, struct __DONE *res) {
    char *pos = token;

    res->TokenType = *pos;
    if (DONE_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    if (*tlen >= sizeof(struct __DONE)) {
        *res = *(struct __DONE *)pos;
    } else {
        PRINT_ERR_MSG("short of length"); return -1;
    }
    /* The value of DoneRowCount is valid if the value of Status includes DONE_COUNT */
    if (!(res->Status & DONE_COUNT)) res->DoneRowCount = 0;

    *tlen = pos - token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.6��
   Indicates the completion status of a SQL statement within a stored procedure. */
struct __DONEINPROC {
    BYTE TokenType; /* =DONEINPROC_TOKEN */
    USHORT Status;   /* ��DONE.Status��ȡֵ��Χһ�� */
    USHORT CurCmd;   /* The token of the current SQL statement */
    /* The count of rows that were affected by the SQL statement.  */
#if __TDS_7_2
    ULONGLONG DoneRowCount;
#else
    LONG DoneRowCount;
#endif
};

/* 'token'ָ��token�鿪ͷ��
   'tlen'Ϊ�ÿ�������󳤶ȣ����������ظ�token�Ĵ�С
   'res'�������Ȥ�Ľ�������
   �ɹ�����0��ʧ�ܷ���-1 */
int DONEINPROC_token_parse(char *token, int *tlen, struct __DONEINPROC *res) {
    char *pos = token;

    res->TokenType = *pos;
    if (DONEINPROC_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    if (*tlen >= sizeof(struct __DONEINPROC)) {
        *res = *(struct __DONEINPROC *)pos;
    } else {
        PRINT_ERR_MSG("short of length"); return -1;
    }

    /* The value of DoneRowCount is valid if the value of Status includes DONE_COUNT */
    if (!(res->Status & DONE_COUNT)) res->DoneRowCount = 0;

    *tlen = pos - token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.7��
   Indicates the completion status of a SQL statement within a stored procedure. */
struct __DONEPROC {
    BYTE TokenType; /* =DONEPROC_TOKEN */
    USHORT Status; /* ��DONE.Status��ȡֵ��Χһ�� */
    USHORT CurCmd; /* The token of the current SQL statement */
    /* The count of rows that were affected by the SQL statement.  */
#if __TDS_7_2
    ULONGLONG DoneRowCount;
#else
    LONG DoneRowCount;
#endif
};

/* 'token'ָ��token�鿪ͷ��
   'tlen'Ϊ�ÿ�������󳤶ȣ����������ظ�token�Ĵ�С
   'res'�������Ȥ�Ľ�������
   �ɹ�����0��ʧ�ܷ���-1 */
int DONEPROC_token_parse(char *token, int *tlen, struct __DONEPROC *res) {
    char *pos = token;

    res->TokenType = *pos;
    if (DONEPROC_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    if (*tlen >= sizeof(struct __DONEPROC)) {
        *res = *(struct __DONEPROC *)pos;
    } else {
        PRINT_ERR_MSG("short of length"); return -1;
    }

    /* The value of DoneRowCount is valid if the value of Status includes DONE_COUNT */
    if (!(res->Status & DONE_COUNT)) res->DoneRowCount = 0;

    *tlen = pos - token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.8�ڣ�ENVCHANGE_TOKEN */
/* A notification of an environment change (for example, database, language, and so on). */

/* 'struct __EnvValueData.Type'��ȡֵ��Χ */
#define Database 1
#define Language 2
#define Character_set 3
#define Packet_size 4
#define Unicode_data_sorting_local_id 5
#define Unicode_data_sorting_comparison_flags 6
#define SQL_Collation 7

#if __TDS_7_2
#define Begin_Transaction 8
#define Commit_Transaction 9
#define Rollback_Transaction 10
#define Enlist_DTC_Transaction 11
#define Defect_Transaction 12
#define Real_Time_Log_Shipping 13
#define Promote_Transaction 15 /* ע�⣬û14 */
#define Transaction_Manager_Address 16
#define Transaction_ended 17
#define RESETCONNECTION_RESETCONNECTIONSKIPTRAN_Completion_Acknowledgement 18
#define Sends_back_name_of_user_instance_started_per_login_request 19
#endif

#if __TDS_7_4
#define Sends_routing_information_to_client 20
#endif

/* ����'Type'�Ĳ�ͬ��'NewValue'��'OldValue'�ֱ�ָ��ͬ�����ݽṹ(��ʱ���Ժ���) */
struct __EnvValueData {
    BYTE Type; /* The type of environment change */
    BYTE *NewValue;
    BYTE *OldValue;
};

struct __ENVCHANGE {
    BYTE TokenType; /* =ENVCHANGE_TOKEN */
    USHORT Length; /* The total length of the ENVCHANGE data stream (EnvValueData). */
    struct __EnvValueData EnvValueData;
};

int ENVCHANGE_token_parse(char *token, int *tlen, struct __ENVCHANGE *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (ENVCHANGE_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);
    STEP_N(pos, *tlen-(pos-token), res->Length);

    *tlen = pos - token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.9�ڣ�ERROR_TOKEN */
struct __ERROR {
    BYTE TokenType; /* =ERROR_TOKEN */
    USHORT Length; /* The total length of the ERROR data stream, in bytes */
    LONG Number; /* The error number */
    BYTE State; /* The error state, used as a modifier to the error number */
    BYTE Class; /* The class (severity) of the error */
    struct __US_VARCHAR MsgText; /* The message text length and message text */
    struct __B_VARCHAR ServerName; /* The server name length and server name */
    struct __B_VARCHAR ProcName; /* The stored procedure name length and the stored procedure name  */
#if __TDS_7_2
    LONG LineNumber; /* The line number in the SQL batch or stored procedure that caused the error. TDS 7.2֮ǰ��unsigned short */
#else
    USHORT LineNumber; /* The line number in the SQL batch or stored procedure that caused the error. TDS 7.2֮ǰ��unsigned short */
#endif
};

int ERROR_token_parse(char *token, int *tlen, struct __ERROR *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (ERROR_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    res->Length = *(unsigned short *)pos;

    *tlen = res->Length;
    return 0;
}


/*===============================================================================*/
/* 2.2.7.10�ڣ�FEATUREEXTACK_TOKEN */

#if __TDS_7_4 /* ��2.2.5.8�ڵ�FEATUREEXTACK_TOKEN���崦�����ģ�����2.2.7.10��û��˵ */
struct __FeatureAckOpt {
    BYTE FeatureId; /* The unique identifier number of a feature. ��0xff,��û�к�������� */
    DWORD FeatureAckDataLen; /* The length of FeatureAckData, in bytes. */
    BYTE *FeatureAckData; /* Ack data of specific feature. */
};

struct __FEATUREEXTACK {
    BYTE TokenType; /* =FEATUREEXTACK_TOKEN */
    struct __FeatureAckOpt FeatureAckOpt; /* ���'FeatureAckOpt'����0xFF��β���˴�ֻ������ */
};

int FEATUREEXTACK_token_parse(char *token, int *tlen, struct __FEATUREEXTACK *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (FEATUREEXTACK_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    while (*pos != 0xff) {
        res->FeatureAckOpt.FeatureId = *pos++;
        STEP(pos, *tlen-(pos-token), 4, DWORD, res->FeatureAckOpt.FeatureAckDataLen);
        STEP_PL(pos, *tlen-(pos-token), res->FeatureAckOpt.FeatureAckData, res->FeatureAckOpt.FeatureAckDataLen);
    }
    pos++;

    *tlen = pos-token;
    return 0;
}
#endif

/*===============================================================================*/
/* 2.2.7.11�ڣ�FEDAUTHINFO_TOKEN */
/* The federated authentication<39> information returned to the client to be used
   for generating a Federated Authentication Token during the login process. This
   token MUST be the only token in a Federated Authentication Information message
   and MUST NOT be included in any other message type. */
#if __TDS_7_4
/* 'FedAuthInfo'��ȡֵ��Χ */
#define Reserved 0x00 /* Reserved. */
#define STSURL 0x01 /* A Unicode string that represents the token endpoint URL from which to acquire a Federated Authentication Token. */
#define SPN 0x02 /* A Unicode string that represents the Service Principal Name (SPN) to use for acquiring a Federated Authentication Token. SPN is a string that represents the resource in a directory. */

struct __FedAuthInfoOpt {
    BYTE FedAuthInfoID; /* The unique identifier number for the type of information. */
    DWORD FedAuthInfoDataLen; /* The length of FedAuthInfoData, in bytes. */
    DWORD FedAuthInfoDataOffset; /* The offset at which the federated authentication information data for FedAuthInfoID is present, measured from the address of CountOfInfoIDs. */
};
struct __FEDAUTHINFO {
    BYTE TokenType; /* =FEDAUTHINFO_TOKEN */
    DWORD TokenLength; /* The length of the whole Federated Authentication Information token, not including the size occupied by TokenLength itself. */
    DWORD CountOfInfoIDs; /* The number of federated authentication information options that are sent in the token.  */
    struct __FedAuthInfoOpt FedAuthInfoOpt;
    BYTE *FedAuthInfoData; /* The actual information data as binary, with the length in bytes equal to FedAuthInfoDataLen.  */
};

int FEDAUTHINFO_token_parse(char *token, int *tlen, struct __FEDAUTHINFO *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (FEDAUTHINFO_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 4, DWORD, res->TokenLength);
    STEP_N(pos, *tlen-(pos-token), res->TokenLength);

    *tlen = pos-token;
    return 0;
}
#endif

/*===============================================================================*/
/* 2.2.7.12�ڣ�INFO_TOKEN */
struct __INFO {
    BYTE TokenType; /* =INFO_TOKEN */
    USHORT Length; /* The total length of the INFO data stream, in bytes. */
    LONG Number; /* The info number */
    BYTE State; /* The error state, used as a modifier to the info Number. */
    BYTE Class; /* The class (severity) of the error. A class of less than 10 indicates an informational message. */
    struct __US_VARCHAR MsgText;
    struct __B_VARCHAR ServerName;
    struct __B_VARCHAR ProcName;
#if __TDS_7_2
    ULONG LineNumber; /* The line number in the SQL batch or stored procedure that caused the error.  */
#else
    USHORT LineNumber;
#endif
};

int INFO_token_parse(char *token, int *tlen, struct __INFO *res) {
    char *pos = token;
    int leftlen, retval;

    res->TokenType = *pos++;
    if (INFO_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);
    STEP(pos, *tlen-(pos-token), 4, LONG, res->Number);
    STEP(pos, *tlen-(pos-token), 1, BYTE, res->State);
    STEP(pos, *tlen-(pos-token), 1, BYTE, res->Class);

    leftlen = *tlen - (pos - token);
    retval = US_VARCHAR_parse(pos, &leftlen, &(res->MsgText));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    leftlen = *tlen - (pos - token);
    retval = B_VARCHAR_parse(pos, &leftlen, &(res->ServerName));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    leftlen = *tlen - (pos - token);
    retval = B_VARCHAR_parse(pos, &leftlen, &(res->ProcName));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

#if __TDS_7_2
    STEP(pos, *tlen-(pos-token), 4, ULONG, res->LineNumber);
#else
    STEP(pos, *tlen-(pos-token), 2, USHORT, res->LineNumber);
#endif

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.13�ڣ�LOGINACK_TOKEN */

/* 'struct __LOGINACK.Interface'��ȡֵ��Χ */
#define SQL_DFLT 0
#define SQL_TSQL 1

struct __ProgVersion {
    BYTE MajorVer; /* The major version number (0-255) */
    BYTE MinorVer; /* The minor version number (0-255) */
    BYTE BuildNumHi; /* The high byte of the build number (0-255). */
    BYTE BuildNumLow; /* The low byte of the build number (0-255) */
};

struct __LOGINACK {
    BYTE TokenType; /* LOGINACK_TOKEN */
    USHORT Length; /* The total length, in bytes, of the following fields: Interface, TDSVersion, Progname, and ProgVersion. */
    BYTE Interface; /* The type of interface with which the server will accept client requests */
    DWORD TDSVersion; /* The TDS version being used by the server  */
    struct __B_VARCHAR ProgName; /* The name of the server */
    struct __ProgVersion ProgVersion;
};

int LOGINACK_token_parse(char *token, int *tlen, struct __LOGINACK *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (LOGINACK_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);
    STEP_N(pos, *tlen-(pos-token), res->Length);

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.14�ڣ�NBCROW_TOKEN */
#if __TDS_7_3

struct __ColumnData {
    /* ע�� - 'TextPointer'��'Timestamp'ֻ�е�text/ntext/imageʱ���С� */
    struct __B_VARBYTE TextPointer; /* ��ѡ��text pointer for Data */
    BYTE Timestamp[8]; /* ��ѡ��The timestamp of a text/image column. */
    struct __TYPE_VARBYTE Data; /* The actual data for the column. The TYPE_INFO information describing the data type of this data is given in the preceding COLMETADATA_TOKEN */
};

struct __NBCROW {
    BYTE TokenType; /* =NBCROW_TOKEN */
    BYTE NullBitmap; /* ����ֽڣ��ܰ�����һ����ΪCOLMETADATA��token������'Count'��λ���ֽ�������Count/8����ȡ�� */
    struct __ColumnData AllColumnData; /* ���'struct __ColumnData'���˴����������� */
};

int NBCROW_token_parse(char *token, int *tlen, struct __NBCROW *res, struct __TYPE_INFO *TYPE_INFO, int Count) {
    char *pos = token;
    int NullBitmapByteCount, leftlen, retval;

    res->TokenType = *pos++;
    if (NBCROW_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    NullBitmapByteCount = (Count%8==0) ? Count/8 : Count/8+1;
    STEP_N(pos, *tlen-(pos-token), NullBitmapByteCount); /* ����'struct __NBCROW.NullBitmap' */

    if (TEXTTYPE == TYPE_INFO->LENTYPE || NTEXTTYPE == TYPE_INFO->LENTYPE
        || IMAGETYPE == TYPE_INFO->LENTYPE) {

        leftlen = *tlen - (pos - token);
        retval = B_VARBYTE_parse(pos, &leftlen, &(res->AllColumnData.TextPointer));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);

        if ((*tlen - (pos - token)) >= 8) {
            memcpy(res->AllColumnData.Timestamp, pos, 8);
        } else {
            PRINT_ERR_MSG("short of length"); return -1;
        }
    }

    leftlen = *tlen - (pos - token);
    retval = TYPE_VARBYTE_parse(pos, &leftlen, TYPE_INFO, &(res->AllColumnData.Data));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    *tlen = pos-token;
    return 0;
}
#endif

/*===============================================================================*/
/* 2.2.7.15�ڣ�OFFSET_TOKEN */
/* Used to inform the client where in the client's SQL text buffer a particular keyword occurs. */
#if !__TDS_7_2
struct __OFFSET {
    BYTE TokenType;   /* OFFSET_TOKEN */
    USHORT Identifier; /* The keyword to which OffSetLen refers. */
    USHORT OffSetLen;  /* The offset in the SQL text buffer received by the server of the identifier. */
};

int OFFSET_token_parse(char *token, int *tlen, struct __OFFSET *res) {
    char *pos = token;

    res->TokenType = *pos;
    if (OFFSET_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    if (*tlen >= sizeof(struct __OFFSET)) {
        *res = *(struct __OFFSET *)pos;
        STEP_N(pos, *tlen-(pos-token), sizeof(struct __OFFSET));
    } else {
        PRINT_ERR_MSG("short of length"); return -1;
    }

    *tlen = pos-token;
    return 0;
}
#endif

/*===============================================================================*/
/* 2.2.7.16�ڣ�ORDER_TOKEN */
/* Used to inform the client by which columns the data is ordered. */

struct __ORDER {
    BYTE TokenType; /* ORDER_TOKEN */
    USHORT Length; /* The total length of the ORDER data stream. */
    USHORT ColNum; /* The column number in the result set. ���ColNum���˴�ֻ�������� */
};

int ORDER_token_parse(char *token, int *tlen, struct __ORDER *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (ORDER_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);
    STEP_N(pos, *tlen-(pos-token), res->Length);

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.17�ڣ�RETURNSTATUS_TOKEN */
/* Used to send the status value of an RPC to the client. The server also uses this
   token to send the result status value of a T-SQL EXEC query. */

struct __RETURNSTATUS {
    BYTE TokenType; /* RETURNSTATUS_TOKEN */
    LONG Value;     /* The return status value determined by the remote procedure. Return status MUST NOT be NULL. */
};

int RETURNSTATUS_token_parse(char *token, int *tlen, struct __RETURNSTATUS *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (RETURNSTATUS_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 4, LONG, res->Value);

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* 2.2.7.18�ڣ�RETURNVALUE_TOKEN */
/* Used to send the return value of an RPC to the client. When an RPC is executed,
   the associated parameters might be defined as input or output (or "return")
   parameters. This token is used to send a description of the return parameter
   to the client. This token is also used to describe the value returned by a UDF
   when executed as an RPC. */

/* 'struct __RETURNVALUE.Status'��ȡֵ��Χ */
#define STORED_PROCEDURE_INVOCATION 0x01 /* If ReturnValue corresponds to OUTPUT parameter of a stored procedure invocation. */
#define USER_DEFINED_FUNTION 0x02 /* If ReturnValue corresponds to return value of User Defined Function. */

#if __TDS_7_4
struct __CryptoMetadata {
    ULONG UserType; /* The user-defined data type of the column. */
    struct __TYPE_INFO BaseTypeInfo; /* TYPE_INFO for the unencrypted type. */
    BYTE EncryptionAlgo; /* A byte that describes the encryption algorithm that is used. */
    struct __B_VARCHAR AlgoName; /* Algorithm name literal that is used to encrypt the plaintext value. */
    BYTE EncryptionAlgoType; /* A field that describes the encryption algorithm type. */
    BYTE NormVersion; /* The normalization version to which plaintext data MUST be normalized. */
};
#endif

struct __RETURNVALUE {
    BYTE TokenType; /* RETURNVALUE_TOKEN */
    USHORT ParamOrdinal; /* Indicates the ordinal position of the output parameter in the original RPC call. */
    struct __B_VARCHAR ParamName; /*  */
    BYTE Status; /*  */
#if __TDS_7_2
    ULONG UserType; /* The user-defined data type of the column. */
#else
    USHORT UserType;
#endif
    USHORT Flags; /* All of these bit flags SHOULD be set to zero */
    struct __TYPE_INFO TypeInfo; /* The TYPE_INFO for the message */
#if __TDS_7_4
    struct __CryptoMetadata CryptoMetadata; /* This describes the encryption metadata for a column. */
#endif
    struct __TYPE_VARBYTE Value; /* The type-dependent data for the parameter (within TYPE_VARBYTE). */
};

int RETURNVALUE_token_parse(char *token, int *tlen, struct __RETURNVALUE *res, int isRPC) {
    char *pos = token;
    int leftlen, retval;

    res->TokenType = *pos++;
    if (RETURNVALUE_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->ParamOrdinal);

    leftlen = *tlen - (pos-token);
    retval = B_VARCHAR_parse(pos, &leftlen, &(res->ParamName));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    STEP(pos, *tlen-(pos-token), 1, BYTE, res->Status);

#if __TDS_7_2
        STEP(pos, *tlen-(pos-token), 4, ULONG, res->UserType);
#else
        STEP(pos, *tlen-(pos-token), 2, USHORT, res->UserType);
#endif

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Flags);

    leftlen = *tlen - (pos-token);
    retval = TYPE_INFO_parse(pos, &leftlen, &(res->TypeInfo), isRPC);
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

#if __TDS_7_4
    STEP(pos, *tlen-(pos-token), 4, ULONG, res->CryptoMetadata.UserType);

    leftlen = *tlen - (pos-token);
    retval = TYPE_INFO_parse(pos, &leftlen, &(res->CryptoMetadata.BaseTypeInfo), isRPC);
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    STEP(pos, *tlen-(pos-token), 1, BYTE, res->CryptoMetadata.EncryptionAlgo);

    leftlen = *tlen - (pos-token);
    retval = B_VARCHAR_parse(pos, &leftlen, &(res->CryptoMetadata.AlgoName));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    STEP(pos, *tlen-(pos-token), 1, BYTE, res->CryptoMetadata.EncryptionAlgoType);
    STEP(pos, *tlen-(pos-token), 1, BYTE, res->CryptoMetadata.NormVersion);
#endif

    leftlen = *tlen - (pos-token);
    retval = TYPE_VARBYTE_parse(pos, &leftlen, &(res->TypeInfo), &(res->Value));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.19�ڣ�ROW_TOKEN */
struct __ROW_ColumnData {
    struct __B_VARBYTE TextPointer; /* The length of the text pointer and the text pointer for data */
    BYTE Timestamp[8];              /* The timestamp of a text/image column. */
    struct __TYPE_VARBYTE Data;     /* The actual data for the column. ע��:�������͸�����һ��token��TYPE_INFO��ֵȷ�� */
};

/* <1>The ColumnData element is repeated once for each column of data.
   <2>TextPointer and Timestamp MUST NOT be specified if the instance of type text/ntext/image is a NULL instance (GEN_NULL). */
struct __ROW {
    BYTE TokenType; /* ROW_TOKEN */
    struct __ROW_ColumnData AllColumnData[50];
};

/* 'token'ָ��token�鿪ͷ��
   'tlen'Ϊ�ÿ�������󳤶ȣ����������ظ�token�Ĵ�С
   'res'�������Ȥ�Ľ�������
   'TYPE_INFO'�ǵ�ǰtoken���������ͣ�ROW��һ��COLMETADATA_TOKEN, ALTMETDATA_TOKEN �� OFFSET_TOKEN��token�и�����
   'Count'�ǵ�ǰtoken��������ROW�ϸ�COLMETADATA_TOKEN, ALTMETDATA_TOKEN �� OFFSET_TOKEN������
   �ɹ�����0��ʧ�ܷ���-1 */
int ROW_token_parse(char *token, int *tlen, struct __ROW *res, struct __COLMETADATA *colmetadata) {
    char *pos = token;
    int leftlen, retval, i, max;

    res->TokenType = *pos++;
    if (ROW_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    max = (colmetadata->Count > 50) ? 50 : colmetadata->Count;
    for (i=0; i<max; i++) {
        if (TEXTTYPE==colmetadata->ColumnData[i].TYPE_INFO.LENTYPE
            || NTEXTTYPE==colmetadata->ColumnData[i].TYPE_INFO.LENTYPE
            || IMAGETYPE==colmetadata->ColumnData[i].TYPE_INFO.LENTYPE) {
            leftlen = *tlen - (pos - token);
            retval = B_VARBYTE_parse(pos, &leftlen, &(res->AllColumnData[i].TextPointer));
            if (retval < 0) return -1;
            STEP_N(pos, *tlen-(pos-token), leftlen);/* ����TextPointer */
            STEP_N(pos, *tlen-(pos-token), 8); /* ����Timestamp */
        }

        leftlen = *tlen - (pos - token);
        retval = TYPE_VARBYTE_parse(pos, &leftlen, &(colmetadata->ColumnData[i].TYPE_INFO), &(res->AllColumnData[i].Data));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);
    }

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.20�ڣ�SESSIONSTATE_TOKEN */
/* Used to send session state data to the client. The data format defined here
   can also be used to send session state data for session recovery during login
   and login response. */

#if __TDS_7_4 /* �ڱ�����û��˵�汾���⣬��SESSIONSTATE_TOKEN����2.2.5.8�ڴ������� */
struct __SessionStateData {
    BYTE StateId; /* The identification number of the session state. 0xFF is reserved. */
    /* The length, in bytes, of the corresponding StateValue.
       ��'StateLen'��0x00-0xfe֮�䣬û'StateLen2'.��'StateLen'=0xff,��'StateLen2' */
    BYTE StateLen;
    DWORD StateLen2;
    BYTE *StateValue; /* The value of the session state */
};

struct __SESSIONSTATE {
    BYTE TokenType; /* =SESSIONSTATE_TOKEN */
    DWORD Length;   /* The length, in bytes, of the token stream (excluding TokenType and Length). */
    DWORD SeqNo;    /* The sequence number of the SESSIONSTATE token in the connection. */
    BYTE Status;    /* Status of the session StateId in this token. */
    struct __SessionStateData SessionStateDataSet; /* �Ƕ��struct __SessionStateData���˴��������� */
};

int SESSIONSTATE_token_parse(char *token, int *tlen, struct __SESSIONSTATE *res) {
    char *pos = token;

    res->TokenType = *pos++;
    if (SESSIONSTATE_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 4, DWORD, res->Length);
    STEP_N(pos, *tlen-(pos-token), res->Length);

    *tlen = pos-token;
    return 0;
}
#endif

/*===============================================================================*/
/* ����2.2.7.21�ڣ�SSPI_TOKEN */
struct __SSPI {
    BYTE TokenType; /* SSPI_TOKEN */
    struct __US_VARBYTE SSPIBuffer;
};

int SSPI_token_parse(char *token, int *tlen, struct __SSPI *res) {
    char *pos = token;
    int leftlen, retval;

    res->TokenType = *pos++;
    if (SSPI_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    leftlen = *tlen - (pos - token);
    retval = US_VARBYTE_parse(pos, &leftlen, &(res->SSPIBuffer));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);

    *tlen = pos-token;
    return 0;
}


/*===============================================================================*/
/* ����2.2.7.22�ڣ�TABNAME_TOKEN */
/* Used to send the table name to the client only when in browser mode or from sp_cursoropen. */

struct __TABNAME_TableName {
#if __TDS_7_1
    BYTE NumParts;
    struct __US_VARCHAR PartName; /* ���PartName���˴��������� */
#else
    struct __US_VARCHAR tablename;
#endif
};

struct __TABNAME {
    BYTE TokenType; /* TABNAME_TOKEN */
    USHORT Length; /* The actual data length, in bytes, of the TABNAME token stream. The length does not include token type and length field. */
    struct __TABNAME_TableName AllTableNames; /* The name of the base table referenced in the query statement. */
};

int TABNAME_token_parse(char *token, int *tlen, struct __TABNAME *res) {
    char *pos = token;
    int leftlen, retval;

    res->TokenType = *pos++;
    if (TABNAME_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    STEP(pos, *tlen-(pos-token), 2, USHORT, res->Length);

#if __TDS_7_1
    STEP(pos, *tlen-(pos-token), 1, BYTE, res->AllTableNames.NumParts);

    leftlen = *tlen - (pos - token);
    retval = US_VARCHAR_parse(pos, &leftlen, &(res->AllTableNames.PartName));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);
#else
    leftlen = *tlen - (pos - token);
    retval = US_VARCHAR_parse(pos, &leftlen, &(res->AllTableNames.tablename));
    if (retval < 0) return -1;
    STEP_N(pos, *tlen-(pos-token), leftlen);
#endif

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* ����2.2.7.23�ڣ�TVP_ROW_TOKEN */
/* Used to send a complete table valued parameter (TVP) row, as defined by the
   TVP_COLMETADATA token from client to server. */

struct __TVP_ROW {
    BYTE TokenType; /* =TVP_ROW_TOKEN */
    struct __TYPE_VARBYTE AllColumnData; /* ���struct __TYPE_VARBYTE������������. The actual data for the TVP column. */
};

int TVP_ROW_token_parse(char *token, int *tlen, int Count, struct __TVP_ROW *res, struct __COLMETADATA *colmetadata) {
    char *pos = token;
    int leftlen, retval, i;

    res->TokenType = *pos++;
    if (TVP_ROW_TOKEN != res->TokenType) {PRINT_ERR_MSG("incorrect funtion"); return -1;}

    for (i=0; i<colmetadata->Count; i++) {
        leftlen = *tlen - (pos - token);
        retval = TYPE_VARBYTE_parse(pos, &leftlen, &(colmetadata->ColumnData[i].TYPE_INFO), &(res->AllColumnData));
        if (retval < 0) return -1;
        STEP_N(pos, *tlen-(pos-token), leftlen);
    }

    *tlen = pos-token;
    return 0;
}

/*===============================================================================*/
/* 2.2.6.1�� */
/* <1>Describes the format of bulk-loaded data through the "INSERT BULK" T-SQL statement. The format
   is a COLMETADATA token describing the data being sent, followed by multiple ROW tokens, ending
   with a DONE token. The stream is equivalent to that produced by the server if it were sending the
   same rowset on output.
   <2>Packet header type is 0x07
   <3>This message sent to the server contains bulk data to be inserted. The client MUST have
   previously notified the server where this data is to be inserted. */
struct __BulkLoadBCP {
    struct __COLMETADATA BulkLoad_METADATA;
    struct __ROW BulkLoad_ROW; /* �ж��'struct __ROW'���˴������� */
    struct __DONE BulkLoad_DONE;
};

/* 2.2.6.1�� + 2.2.6.2��
   Describes the format of bulk-loaded data through the "INSERT BULK" T-SQL statement. The format
   is a COLMETADATA token describing the data being sent, followed by multiple ROW tokens, ending
   with a DONE token. The stream is equivalent to that produced by the server if it were sending the
   same rowset on output.*/
/* 'data'��TDS����8�ֽڰ�ͷ������ݲ���, 'len'�Ǹò��ֵ��ֽڳ���
   �ɹ�����0��ʧ�ܷ���-1
   �ο�2.2.6.1�� */
int BulkLoadBCP_parse(char *data, int len, char *result_str, int maxsize) {
    char *pos;
    int retval, leftlen = len;
    struct __COLMETADATA COLMETADATA_info;
    struct __ROW ROW_info;
    struct __DONE DONE_info;

    pos = data;
    if (COLMETADATA_TOKEN == *pos) {
        leftlen = len;
        retval = COLMETADATA_token_parse(data, &leftlen, &COLMETADATA_info, 0);
        if (retval < 0) return -1;
        STEP_N(pos, len-(pos-data), leftlen);
    } else {
        /*  2.2.6.2��*/
        return 0;
    }

    while (ROW_TOKEN == *pos) {
        leftlen = len - (pos - data);
        retval = ROW_token_parse(pos, &leftlen, &ROW_info, &COLMETADATA_info);
        if (retval < 0) return -1;
        STEP_N(pos, len-(pos-data), leftlen);
    }

    if (DONE_TOKEN == *pos) {
        leftlen = len - (pos - data);
        retval = DONE_token_parse(pos, &leftlen, &DONE_info);
        STEP_N(pos, len-(pos-data), leftlen);
    }

    return 0;
}

/*==================================================================================*/
/* ����2.2.6.3�� */
struct __FEDAUTH {
    DWORD DataLen; /* The total length of the data in the Federated Authentication Token message that follows this field. */
    struct __L_VARBYTE FedAuthToken;    /*  the federated authentication token data */
    BYTE Nonce[32];
};

int FEDAUTH_parse(char *data, int len, char *result_str, int maxsize) {
    struct __FEDAUTH FEDAUTH_info;
    char *pos = data;
    int leftlen, retval;

    STEP(pos, len-(pos-data), 4, DWORD, FEDAUTH_info.DataLen);

    leftlen = len-(pos-data);
    retval = L_VARBYTE_parse(pos, &leftlen, &(FEDAUTH_info.FedAuthToken));
    if (retval < 0) return -1;
    STEP_N(pos, len-(pos-data), leftlen);

    leftlen = len-(pos-data);
    if (leftlen >= 32) {
        memcpy(FEDAUTH_info.Nonce, pos, 32);
    }
    if (leftlen != 32) {
        PRINT_ERR_MSG("encounter unexcepted bytes"); return -1;
    }
    return 0;
}

/*==================================================================================*/
/* ����2.2.6.4��
   the authentication rules for use between client and server
   ib..��offset����λ��1�ֽڣ������LOGIN7����ͷ����struct __LOGIN7.Data���ֵ�ǰ���
   �ֽ�����������TDSͷ��
   cch...��Length����λ��2�ֽ�
   ������4.2�ڵķ������ */
struct __OffsetLength {
    USHORT ibHostName;
    USHORT cchHostName;/* IbHostname & cchHostName: The client machine name */
    USHORT ibUserName;
    USHORT cchUserName; /* IbUserName & cchUserName: The client user ID */
    USHORT ibPassword;
    USHORT cchPassword; /* IbPassword & cchPassword: The password supplied by the client. */
    USHORT ibAppName;
    USHORT cchAppName; /* IbAppName & cchAppName: The client application name. */
    USHORT ibServerName;
    USHORT cchServerName; /* IbServerName & cchServerName: The server name. */
#if __TDS_7_4
    USHORT ibExtension;
    USHORT cbExtension; /* ibExtension & cbExtension: This points to an extension block. */
#else
    USHORT ibUnused;
    USHORT cchUnused; /* ibUnused & cbUnused: These parameters were reserved until TDS 7.4. */
#endif
    USHORT ibCltIntName;
    USHORT cchCltIntName; /* ibCltIntName & cchCltIntName: The interface library name (ODBC or OLEDB) */
    USHORT ibLanguage;
    USHORT cchLanguage; /* ibLanguage & cchLanguage: The initial language (overrides the user ID's default language). */
    USHORT ibDatabase;
    USHORT cchDatabase; /* ibDatabase & cchDatabase: The initial database (overrides the user ID's default database). */
    BYTE ClientID[6]; /* The unique client ID (created used NIC address). */
    USHORT ibSSPI;
    USHORT cbSSPI; /* ibSSPI & cbSSPI: SSPI data. */
    USHORT ibAtchDBFile;
    USHORT cchAtchDBFile; /* ibAtchDBFile & cchAtchDBFile: The file name for a database that is to be attached during the connection process. */
#if __TDS_7_2
    USHORT ibChangePassword;
    USHORT cchChangePassword; /* ibChangePassword & cchChangePassword: New password for the specified login. Introduced in TDS 7.2. */
    DWORD cbSSPILong; /* Used for large SSPI data when cbSSPI==USHRT_MAX. Introduced in TDS7.2. */
#endif
};

struct __FeatureOpt {
    BYTE FeatureId;      /* The unique identifier number of a feature. */
    DWORD FeatureDataLen;/* The length, in bytes, of FeatureData for the corresponding FeatureID. */
    BYTE *FeatureData;   /* Data of the feature. */
};

struct __LOGIN7{
    DWORD Length;        /* The total length of the LOGIN7 structure. */
    DWORD TDSVersion;    /* The highest TDS version being used by the client */
    DWORD PacketSize;    /* The packet size being requested by the client. */
    DWORD ClientProgVer; /* The version of the interface library (for example, ODBC or OLEDB) being used by the client */
    DWORD ClientPID;     /* The process ID of the client application. */
    DWORD ConnectionID;  /* The connection ID of the primary Server. */
    BYTE OptionFlags1;   /*  */
    BYTE OptionFlags2;   /*  */
    BYTE TypeFlags;      /*  */
    BYTE OptionFlags3;   /*  */
    LONG ClientTimZone;  /* The time zone of the client machine */
    ULONG ClientLCID;    /* The language code identifier (LCID) value for the client collation. */
    struct __OffsetLength OffsetLength; /* The variable portion of this message. */
    BYTE *Data;         /* The actual variable-length data portion referred to by OffsetLength. */
#if __TDS_7_4
    struct __FeatureOpt FeatureExt; /* The data block that can be used to inform and/or negotiate features between client and server. �ж������0xff��β���˴�������*/
#endif
};

int LOGIN7_parse(char *data, int len, char *result_str, int maxsize) {
    char *pos = data;
    struct __LOGIN7 LOGIN7_info;
    char *cur;
    int maxleftlen, tmpbuflen;
    char tmpbuf[1024], HostName[256], UserName[256], AppName[256], ServerName[256],
         CltIntName[256], curLanguage[256], curDatabase[256];

    if (sizeof(struct __LOGIN7) > len) {PRINT_ERR_MSG("sizeof(struct __LOGIN7) > len"); return -1;}

    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.Length);
    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.TDSVersion);
    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.PacketSize);
    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.ClientProgVer);
    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.ClientPID);
    STEP(pos, len-(pos-data), 4, DWORD, LOGIN7_info.ConnectionID);
    STEP(pos, len-(pos-data), 1, BYTE, LOGIN7_info.OptionFlags1);
    STEP(pos, len-(pos-data), 1, BYTE, LOGIN7_info.OptionFlags2);
    STEP(pos, len-(pos-data), 1, BYTE, LOGIN7_info.TypeFlags);
    STEP(pos, len-(pos-data), 1, BYTE, LOGIN7_info.OptionFlags3);
    STEP(pos, len-(pos-data), 4, LONG, LOGIN7_info.ClientTimZone);
    STEP(pos, len-(pos-data), 4, ULONG, LOGIN7_info.ClientLCID);
    if (len-(pos-data) >= sizeof(struct __OffsetLength)) {
        LOGIN7_info.OffsetLength = *(struct __OffsetLength *)pos;
        STEP_N(pos, len-(pos-data), sizeof(struct __OffsetLength));
    } else {PRINT_ERR_MSG("short of length"); return -1;}
    LOGIN7_info.Data = (BYTE *)pos;

    cur = result_str;
    maxleftlen = maxsize;
    sprintf(tmpbuf,
        "TDSVersion=%u;<br>ClientProgVer=%u;<br>ClientPID==%u;<br>ClientLCID=%u;<br>",
        LOGIN7_info.TDSVersion, LOGIN7_info.ClientProgVer, LOGIN7_info.ClientPID, LOGIN7_info.ClientLCID);
    tmpbuflen = strlen(tmpbuf);
    COPY_STR(cur, maxleftlen, tmpbuf, tmpbuflen);
    cur += tmpbuflen;
    maxleftlen -= tmpbuflen;

    memcpy(HostName, data+LOGIN7_info.OffsetLength.ibHostName, LOGIN7_info.OffsetLength.cchHostName*2);
    memcpy(UserName, data+LOGIN7_info.OffsetLength.ibUserName, LOGIN7_info.OffsetLength.cchUserName*2);
    memcpy(AppName, data+LOGIN7_info.OffsetLength.ibAppName, LOGIN7_info.OffsetLength.cchAppName*2);
    memcpy(ServerName, data+LOGIN7_info.OffsetLength.ibServerName, LOGIN7_info.OffsetLength.cchServerName*2);
    memcpy(CltIntName, data+LOGIN7_info.OffsetLength.ibCltIntName, LOGIN7_info.OffsetLength.cchCltIntName*2);
    memcpy(curLanguage, data+LOGIN7_info.OffsetLength.ibLanguage, LOGIN7_info.OffsetLength.cchLanguage*2);
    memcpy(curDatabase, data+LOGIN7_info.OffsetLength.ibDatabase, LOGIN7_info.OffsetLength.cchDatabase*2);
    CLR_ZERO_CHARS(HostName, LOGIN7_info.OffsetLength.cchHostName*2);
    CLR_ZERO_CHARS(UserName, LOGIN7_info.OffsetLength.cchUserName*2);
    CLR_ZERO_CHARS(AppName, LOGIN7_info.OffsetLength.cchAppName*2);
    CLR_ZERO_CHARS(ServerName, LOGIN7_info.OffsetLength.cchServerName*2);
    CLR_ZERO_CHARS(CltIntName, LOGIN7_info.OffsetLength.cchCltIntName*2);
    CLR_ZERO_CHARS(curLanguage, LOGIN7_info.OffsetLength.cchLanguage*2);
    CLR_ZERO_CHARS(curDatabase, LOGIN7_info.OffsetLength.cchDatabase*2);
    sprintf(tmpbuf,
            "HostName=%s;<br>UserName=%s;<br>AppName=%s;<br>ServerName=%s;<br>"
            "CltIntName=%s;<br>Language=%s;<br>Database=%s;<br>",
            HostName, UserName, AppName, ServerName, CltIntName, curLanguage, curDatabase);
    tmpbuflen = strlen(tmpbuf);
    COPY_STR(cur, maxleftlen, tmpbuf, tmpbuflen);
    cur += tmpbuflen;
    maxleftlen -= tmpbuflen;

#if __TDS_7_4
    //FeatureExt����
#endif
    return 0;
}

/*==================================================================================*/
/* ����2.2.6.5�� */
/* struct __PRELOGIN_OPTION.PL_OPTION_TOKEN��ȡֵ��Χ */
#define PL_OT_VERSION 0x00
#define PL_OT_ENCRYPTION 0x01
#define PL_OT_INSTOPT 0x02
#define PL_OT_THREADID 0x03
#define PL_OT_MARS 0x04
#define PL_OT_TRACEID 0x05
#define PL_OT_FEDAUTHREQUIRED 0x06
#define PL_OT_NONCEOPT 0x07
#define PL_OT_TERMINATOR 0xff

/* ��struct __PRELOGIN_OPTION.PL_OPTION_TOKENȡ����ļ���ֵʱ��
   struct __PRELOGIN.PL_OPTION_DATA����Ӧ��ָ�������Ӧ�Ľṹ */
struct __PL_OT_DATA_VERSION {
    ULONG UL_VERSION; /* version of the sender */
    USHORT US_SUBBUILD; /* sub-build number of the sender */
};

struct __PL_OT_DATA_ENCRYPTION {
    BYTE B_FENCRYPTION; /*  */
};

struct __PL_OT_DATA_INSTOPT {
    BYTE *B_INSTVALIDITY; /* name of the instance of the database server that supports SQL or just 0x00 */
};

struct __PL_OT_DATA_THREADID {
    ULONG UL_THREADID; /* client application thread id used for debugging purposes */
};

struct __PL_OT_DATA_MARS {
    BYTE B_MARS; /* sender requests MARS support */
};

struct __PL_OT_DATA_TRACEID {
    BYTE GUID_CONNID[16]; /* client application trace id used for debugging purposes */
    BYTE ACTIVITYID[20]; /* client application activity id */
};

struct __PL_OT_DATA_FEDAUTHREQUIRED {
    BYTE B_FEDAUTHREQUIRED; /* authentication library requirement of the sender when using Integrated Authentication identity */
};

struct __PL_OT_DATA_NONCEOPT {
    BYTE NONCE[32]; /* nonce to be encrypted by using session key from federated authentication handshake */
};

struct __PRELOGIN_OPTION {
    BYTE PL_OPTION_TOKEN;    /* token value representing the option */
    USHORT PL_OFFSET;        /* ע�� - �Ǵ���ֽ��� */
    USHORT PL_OPTION_LENGTH; /* ע�� - �Ǵ���ֽ��� */
};

/* N��PRELOGIN_OPTION��1��PL_OT_TERMINATOR��β��Ȼ����Data
   ���е�PRELOGIN_OPTION.PL_OPTION_LENGTH��ӣ�����Data���ֽ���*/
struct __PRELOGIN {
    struct __PRELOGIN_OPTION PRELOGIN_OPTION; /* ���'struct __PRELOGIN_OPTION'����0xff��β */
    BYTE *PL_OPTION_DATA; /* actual data for the option */
    BYTE *SSL_PAYLOAD;    /* SSL handshake raw payload */
};

int PRELOGIN_parse(char *data, int len, char *result_str, int maxsize) {
    struct __PRELOGIN PRELOGIN_info;
    char *pos = data;
    char *curprs = result_str;
    char bufstr[1024] = {0}, tmpdata[1024]={0};
    struct __PL_OT_DATA_VERSION VERSIONtmp;
    struct __PL_OT_DATA_ENCRYPTION ENCRYPTIONtmp;
    struct __PL_OT_DATA_THREADID THREADIDtmp;
    struct __PL_OT_DATA_MARS MARStmp;
    struct __PL_OT_DATA_FEDAUTHREQUIRED FEDAUTHREQUIREDtmp;

    switch (*(unsigned char *)pos) {
        case PL_OT_VERSION :
        case PL_OT_ENCRYPTION :
        case PL_OT_INSTOPT :
        case PL_OT_THREADID :
        case PL_OT_MARS :
        case PL_OT_TRACEID :
        case PL_OT_FEDAUTHREQUIRED :
        case PL_OT_NONCEOPT :
        case PL_OT_TERMINATOR :
            break;
        default:
            PRELOGIN_info.SSL_PAYLOAD = (BYTE *)pos;
            return 0;
    }

    while (*pos != PL_OT_TERMINATOR) {
        if (len - (pos - data) > sizeof(struct __PRELOGIN_OPTION)) {
            PRELOGIN_info.PRELOGIN_OPTION = *(struct __PRELOGIN_OPTION *)pos;
            big_2_host(&(PRELOGIN_info.PRELOGIN_OPTION.PL_OFFSET), 2);
            big_2_host(&(PRELOGIN_info.PRELOGIN_OPTION.PL_OPTION_LENGTH), 2);

            if (PRELOGIN_info.PRELOGIN_OPTION.PL_OFFSET+PRELOGIN_info.PRELOGIN_OPTION.PL_OPTION_LENGTH > len) {
                PRINT_ERR_MSG("incomplete data");
                return -1;
            }
            /* ע���tmpdata�е�'\0'Ԥ����λ */
            COPY_STR(tmpdata, sizeof(tmpdata)-1, data+PRELOGIN_info.PRELOGIN_OPTION.PL_OFFSET, PRELOGIN_info.PRELOGIN_OPTION.PL_OPTION_LENGTH);
            switch (PRELOGIN_info.PRELOGIN_OPTION.PL_OPTION_TOKEN) {
                case PL_OT_VERSION:
                    VERSIONtmp = *(struct __PL_OT_DATA_VERSION *)tmpdata;
                    sprintf(bufstr, "VERSION=%u;<br>SUBBUILD=%u;<br>", VERSIONtmp.UL_VERSION, VERSIONtmp.US_SUBBUILD);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_ENCRYPTION :
                    ENCRYPTIONtmp = *(struct __PL_OT_DATA_ENCRYPTION *)tmpdata;
                    sprintf(bufstr, "FENCRYPTION=%u;<br>", ENCRYPTIONtmp.B_FENCRYPTION);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_INSTOPT :
                    tmpdata[PRELOGIN_info.PRELOGIN_OPTION.PL_OPTION_LENGTH] = '\0';
                    sprintf(bufstr, "INSTVALIDITY=%s;<br>", tmpdata);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_THREADID :
                    THREADIDtmp = *(struct __PL_OT_DATA_THREADID *)tmpdata;
                    sprintf(bufstr, "THREADID=%u;<br>", THREADIDtmp.UL_THREADID);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_MARS :
                    MARStmp = *(struct __PL_OT_DATA_MARS *)tmpdata;
                    sprintf(bufstr, "MARS=%u;<br>", MARStmp.B_MARS);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_TRACEID :
                    /* debug��;������ */
                    break;
                case PL_OT_FEDAUTHREQUIRED :
                    FEDAUTHREQUIREDtmp = *(struct __PL_OT_DATA_FEDAUTHREQUIRED *)tmpdata;
                    sprintf(bufstr, "FEDAUTHREQUIRED=%u;<br>", FEDAUTHREQUIREDtmp.B_FEDAUTHREQUIRED);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
                case PL_OT_NONCEOPT :
                    tmpdata[32] = '\0';
                    sprintf(bufstr, "NONCEOPT=%s;<br>", tmpdata);
                    COPY_STR(curprs, maxsize-(curprs-result_str), bufstr, strlen(bufstr));
                    curprs += strlen(bufstr);
                    break;
            }
        } else { PRINT_ERR_MSG("short of length"); return -1; }
        STEP_N(pos, len-(pos-data), sizeof(struct __PRELOGIN_OPTION));
    }
    *curprs = '\0';
    pos++; /* ����0xFF��������� */
    return 0;
}

/*==================================================================================*/
/* ����2.2.6.6�� */

/* ��ǰ�����ַ���0xff 0xffʱ�������'ProcID'������ýṹֻ��'ProcName'�� */
struct __NameLenProcID {
    /* ��ѡ1 */
    struct __US_VARCHAR ProcName;

    /* ��ѡ2 */
    UCHAR ProcIDSwitch[2]; /*  =0xffff*/
    USHORT ProcID; /* The number identifying the special stored procedure to be executed. */
};

struct __ParamMetaData {
    struct __B_VARCHAR B_VARCHAR;
    BYTE StatusFlags;
#if __TDS_7_3
    struct __TVP_TYPE_INFO TVP_TYPE_INFO;
#else
    struct __TYPE_INFO TYPE_INFO;
#endif
};

#if __TDS_7_4
struct __ParamCipherInfo {
    struct __TYPE_INFO TYPE_INFO;
    BYTE EncryptionAlgo;
    struct __B_VARCHAR AlgoName;
    BYTE EncryptionType;
    BYTE *CekHash; /* ??�ĵ���û�и���Ķ��� */
    BYTE NormVersion;
};
#endif

struct __ParameterData {
    struct __ParamMetaData ParamMetaData;
    struct __TYPE_VARBYTE ParamLenData; /* 2.2.5.2.3��ָ����TYPE_VARBYTE���� */
#if __TDS_7_4
    struct __ParamCipherInfo ParamCipherInfo;
#endif
};

struct __RPCReqBatch {
    struct __NameLenProcID NameLenProcID;
    USHORT OptionFlags;
    struct __ParameterData ParameterData; /* ���'struct __ParameterData'���˴������� */
};

struct __RPCRequest {
#if __TDS_7_2
    struct __ALL_HEADERS ALL_HEADERS;
#endif
    struct __RPCReqBatch RPCReqBatch;
    struct __RPCReqBatch *pRPCReqBatch;
};

/* Request to execute an RPC. */
int RPCRequest_parse(char *data, int len, char *result_str, int maxsize) {
    char *pos = data;
    struct __RPCRequest RPCRequest_info;
    int leftlen, retval;

#if __TDS_7_2
    leftlen = len;
    retval = ALL_HEADERS_parse(pos, &leftlen, &(RPCRequest_info.ALL_HEADERS));
    if (retval < 0) return -1;
    STEP_N(pos, len-(pos-data), leftlen);
#endif

    if (0xff==pos[0] && 0xff==pos[1]) {
        RPCRequest_info.RPCReqBatch.NameLenProcID.ProcIDSwitch[0] = 0xff;
        RPCRequest_info.RPCReqBatch.NameLenProcID.ProcIDSwitch[1] = 0xff;
        STEP_N(pos, len-(pos-data), 2);
        STEP(pos, len-(pos-data), 2, USHORT, RPCRequest_info.RPCReqBatch.NameLenProcID.ProcID);
    } else {
        leftlen = len - (pos - data);
        retval = US_VARCHAR_parse(pos, &leftlen, &RPCRequest_info.RPCReqBatch.NameLenProcID.ProcName);
        if (retval < 0) return -1;
        STEP_N(pos, len-(pos-data), leftlen);
    }

    STEP(pos, len-(pos-data), 2, USHORT, RPCRequest_info.RPCReqBatch.OptionFlags);



    return 0;
}

/*==================================================================================*/
/* ����2.2.6.7�� */
struct __SQLBatch {
#if __TDS_7_2
    struct __ALL_HEADERS ALL_HEADERS;
#endif
    BYTE *SQLText; /* Unicode����UCS-2����λ2�ֽ� */
};

int SQLBatch_parse(char *data, int len, char *result_str, int maxsize) {
    char *pos = data;
    struct __SQLBatch SQLBatch_info;
    int leftlen, retval, toCopyLen;
    char tmpbuf[1024*10];

#if __TDS_7_2
    leftlen = len;
    retval = ALL_HEADERS_parse(pos, &leftlen, &(SQLBatch_info.ALL_HEADERS));
    if (retval < 0) return -1;
    STEP_N(pos, len-(pos-data), leftlen);
#endif

    SQLBatch_info.SQLText = (BYTE *)pos;
    toCopyLen = (len-(pos-data)) > (sizeof(tmpbuf)-1) ? (sizeof(tmpbuf)-1) : (len-(pos-data));
    memcpy(tmpbuf, pos, toCopyLen);
    codeConv("UCS-2", "UTF-8", tmpbuf, toCopyLen, result_str, maxsize);
    //CLR_ZERO_CHARS(tmpbuf, toCopyLen);
    //snprintf((char *)result_str, maxsize, "SQLText=%s", tmpbuf);

    return 0;
}

/*==================================================================================*/
/* ����2.2.6.8�� */

struct __SSPI_PKT {
    BYTE *SSPIData;
};

int SSPI_parse(char *data, int len, char *result_str, int maxsize) {

    return 0;
}

/*==================================================================================*/
/* ����2.2.6.9�� */

/* struct __TransMgrReq.RequestType��ȡֵ��Χ*/
#define  TM_GET_DTC_ADDRESS 0 /* Returns DTC network address as a result set with a singlecolumn, single-row binary value. */
#define  TM_PROPAGATE_XACT 1 /* Imports DTC transaction into the server and returns a local transaction descriptor as a varbinary result set. */

#if __TDS_7_2
#define  TM_BEGIN_XACT 5 /* Begins a transaction and returns the descriptor in an ENVCHANGE type 8. */
#define  TM_PROMOTE_XACT 6 /* Converts an active local transaction into a distributed transaction and returns an opaque buffer in an ENVCHANGE type 15 */
#define  TM_COMMIT_XACT 7 /* Commits a transaction. Depending on the payload of the request, it can additionally request that another local transaction be started */
#define  TM_ROLLBACK_XACT 8 /*  Rolls back a transaction. Depending on the payload of the request, it can indicate that after the rollback, a local transaction is to be started*/
#define  TM_SAVE_XACT 9 /* Sets a savepoint within the active transaction. This request MUST specify a nonempty name for the savepoint. */
#endif

/* ���ڲ�ͬ��'RequestType'��'RequestPayload'ָ��ͬ�Ľṹ�������ﲻ������������ */
struct __TransMgrReq {
#if __TDS_7_2
    struct __ALL_HEADERS ALL_HEADERS;
#endif
    USHORT RequestType; /* The types of transaction manager operations that are requested by the client  */
    BYTE *RequestPayload;
};

int STransMgrReq_parse(char *data, int len, char *result_str, int maxsize) {
    struct __TransMgrReq TransMgrReq_info;
    char *pos = data;

#if __TDS_7_2
    TransMgrReq_info.ALL_HEADERS.TotalLength = *(unsigned long *)pos;
    STEP_N(pos, len-(pos-data), TransMgrReq_info.ALL_HEADERS.TotalLength); /* ����ALL_HEADERS */
#endif

    STEP(pos, len-(pos-data), 2, USHORT, TransMgrReq_info.RequestType);
    TransMgrReq_info.RequestPayload = (BYTE *)pos;
    return 0;
}

/* 'n'�ֽڵ��ַ����п��Ա�ʾ��������ø���
   ����{0x01,0x02,0x03,0x04,0x00,0x05}���Ի��0x050004030201
   �ú���������*******************/
unsigned long getNumFromStr(char *NumStr, int n) {
    int i;
    unsigned long num = 0, base=1;
    for (i=0; i<n; i++) {
        //fprintf(stderr, "base=%lu,num=%lu,i=%d,NumStr[i]=%x\n", base, num, i, (unsigned char)NumStr[i]);
        num += ((unsigned char)NumStr[i]  * base);
        base *= 256;
    }
    return num;
}

/*==================================================================================*/
/* ����2.2.3.1.1��
   ����2.2.3.1.1�ڵĵ�2���������Կ���server���͵�TDS���ݣ�ֻ��һ������ -
   TYPE_Tabular_result
   ���������ݽ������������1������Token���
   ע�� - ;:s��ʾ�ո�;:n��ʾ�س���;:r��ʾ���ֻ�����������ַ��İ�*/
int ServerMgr_parse(unsigned char *data, int len, char *result_str, int maxsize) {
    struct __COLMETADATA Datares;
    struct __ROW rowRes;
    int retval, leftlen, i, tocopy;
    unsigned char *pos=NULL;
    char ColNameUCS2[1024], ColName[1024];
    float moneyFltVal;
    int moneyIdx;
    int year, month, today, days, mins, hour, min, sec, msec, usec, timeSize;
    short timeOffset, hourOff, minOff;
    char flagOff;
    unsigned long ssecs;
    long n1,n2,n4,n8;

    leftlen = len;
    pos = data;
    if (*pos != COLMETADATA_TOKEN) {
        return 0;
        result_str[0] = '\0';
    }
    retval = COLMETADATA_token_parse(pos, &leftlen, &Datares, 0);
    if (retval < 0) return -1;
    STEP_N(pos, len, leftlen);

    for (i=0; i<Datares.Count; i++) {
        tocopy = (sizeof(ColNameUCS2)-1) > (Datares.ColumnData[i].ColName.wlen * 2) ?
                 (Datares.ColumnData[i].ColName.wlen * 2) : (sizeof(ColNameUCS2)-1);
        memcpy(ColNameUCS2, Datares.ColumnData[i].ColName.data, tocopy);
        memset(ColName, 0, sizeof(ColName));
        retval = codeConv("UCS-2", "UTF-8", ColNameUCS2, tocopy, ColName, sizeof(ColName)-1);
        if (retval < 0) return -1;
        if (0 != i) strcat(result_str, ";:s");
        strcat(result_str, ColName);
    }
    strcat(result_str, ";:n");

    while (ROW_TOKEN == *(unsigned char *)pos) {
        leftlen = len - (pos - data);
        retval = ROW_token_parse(pos, &leftlen, &rowRes, &Datares);
        if (retval < 0) return -1;
        STEP_N(pos, len, leftlen);

        for (i=0; i<Datares.Count; i++) {
            tocopy = (sizeof(ColValBefore)-1) > (rowRes.AllColumnData[i].Data.len.reallen) ?
                     (rowRes.AllColumnData[i].Data.len.reallen) : (sizeof(ColValBefore)-1);
            if (tocopy > 0) memcpy(ColValBefore, rowRes.AllColumnData[i].Data.data, tocopy);
            memset(ColValAfter, 0, sizeof(ColValAfter));

            //fprintf(stderr, "LENTYPE = %x, tocopy=%d\n", Datares.ColumnData[i].TYPE_INFO.LENTYPE, tocopy);

            if (0 == tocopy) {
                strcpy(ColValAfter, "NULL");
            } else {
                switch (Datares.ColumnData[i].TYPE_INFO.LENTYPE) {

                    /* FIXEDLENTYPE��Χ */
                    case NULLTYPE:
                        strcpy(ColValAfter, "NULL");
                        break;
                    case INT1TYPE:
                    case BITTYPE:
                        n1 = ColValBefore[0];
                        sprintf(ColValAfter, "%ld", n1);
                        break;
                    case INT2TYPE:
                        n2 = getNumFromStr(ColValBefore, 2);
                        sprintf(ColValAfter, "%ld", n2);
                        break;
                    case INT4TYPE:
                    case DATETIM4TYPE:
                    case FLT4TYPE:
                    case MONEY4TYPE:
                        n4 = getNumFromStr(ColValBefore, 4);
                        sprintf(ColValAfter, "%ld", n4);
                        break;
                    case MONEYTYPE:
                    case DATETIMETYPE:
                    case FLT8TYPE:
                    case INT8TYPE:
                        n8 = getNumFromStr(ColValBefore, 8);
                        sprintf(ColValAfter, "%ld", n8);
                        break;

                    /* VARLENTYPE��Χ */
                    case GUIDTYPE:
                    case BIGBINARYTYPE:
                        binaryToHexVisible(ColValBefore, tocopy, ColValAfter, sizeof(ColValAfter)-1);
                        break;
                    case INTNTYPE:
                        sprintf(ColValAfter, "%lu", getNumFromStr(ColValBefore, tocopy));
                        break;
                    case DECIMALTYPE:
                    case NUMERICTYPE:
                    case DECIMALNTYPE:
                    case NUMERICNTYPE:
                        if (0 == ColValBefore[0]) {
                            ColValAfter[0] = '-'; /* ��һ���ַ�����������־ */
                            sprintf(ColValAfter+1, "%lu", getNumFromStr(ColValBefore+1, tocopy-1));
                        } else {
                            sprintf(ColValAfter, "%lu", getNumFromStr(ColValBefore+1, tocopy-1));
                        }
                        break;
                     case BITNTYPE:
                        if (0x1 == ColValBefore[0]) {
                            strcpy(ColValAfter, "TURE");
                        } else {
                            strcpy(ColValAfter, "FALSE");
                        }
                        break;
                    case FLTNTYPE:
                        //not complete
                        binaryToHexVisible(ColValBefore, tocopy, ColValAfter, sizeof(ColValAfter)-1);
                        break;
                    case MONEYNTYPE:
                        moneyFltVal = (float)getNumFromStr(ColValBefore+4, tocopy-4);
                        for (moneyIdx = 0; moneyIdx<Datares.ColumnData[i].TYPE_INFO.__SCALE; moneyIdx++) {
                            moneyFltVal *= 0.1;
                        }
                        sprintf(ColValAfter, "%04f", moneyFltVal);
                        break;
                    case DATETIMNTYPE:
                        if (4 == tocopy) {
                            days = (int)getNumFromStr(ColValBefore, 2);
                            mins = (int)getNumFromStr(ColValBefore+2, 2);
                        } else if(8 == tocopy) {
                            days = (int)getNumFromStr(ColValBefore, 4);
                            mins = (int)getNumFromStr(ColValBefore+4, 4);
                        } else {
                            PRINT_ERR_MSG ("Some error happens");
                        }
                        getDateFromDaysSince19000101(days, &year, &month, &today);
                        getTimeFromMinsSince12AM(mins, &hour, &min, &sec);
                        sprintf(ColValAfter, "%04d-%02d-%02d %02d:%02d:%02d",
                                year, month, today, hour, min, sec);
                        break;

#if __TDS_7_3
                    case DATENTYPE:
                        days = (int)getNumFromStr(ColValBefore, 3);
                        getDateFromDaysSince00010101(days, &year, &month, &today);
                        sprintf(ColValAfter, "%04d-%02d-%02d", year, month, today);
                        break;
                    case TIMENTYPE:
                        ssecs = getNumFromStr(ColValBefore, tocopy);
                        getTimeFromScaleSecsSince12AM(ssecs, Datares.ColumnData[i].TYPE_INFO.__SCALE, &hour, &min, &sec, &msec, &usec);
                        sprintf(ColValAfter, "%02d:%02d:%02d", hour, min, sec);
                        break;
                    case DATETIME2NTYPE:
                        if (Datares.ColumnData[i].TYPE_INFO.__SCALE >=0 &&
                            Datares.ColumnData[i].TYPE_INFO.__SCALE <= 2) {
                            timeSize = 3;
                        } else if (Datares.ColumnData[i].TYPE_INFO.__SCALE >=3 &&
                            Datares.ColumnData[i].TYPE_INFO.__SCALE <= 4) {
                            timeSize = 4;
                        } else {
                            timeSize = 5;
                        }
                        if (timeSize + 3 != tocopy) {
                            strcpy(ColValAfter, "NULL");
                            break;
                        }
                        ssecs = getNumFromStr(ColValBefore, timeSize);
                        days = (int)getNumFromStr(ColValBefore + timeSize, 3);
                        getDateFromDaysSince00010101(days, &year, &month, &today);
                        getTimeFromScaleSecsSince12AM(ssecs, Datares.ColumnData[i].TYPE_INFO.__SCALE, &hour, &min, &sec, &msec, &usec);
                        sprintf(ColValAfter, "%04d-%02d-%02d %02d:%02d:%02d.%04d%04d",
                                year, month, today, hour, min, sec, msec, usec);
                        break;
                    case DATETIMEOFFSETNTYPE:
                        if (Datares.ColumnData[i].TYPE_INFO.__SCALE >=0 &&
                            Datares.ColumnData[i].TYPE_INFO.__SCALE <= 2) {
                            timeSize = 3;
                        } else if (Datares.ColumnData[i].TYPE_INFO.__SCALE >=3 &&
                            Datares.ColumnData[i].TYPE_INFO.__SCALE <= 4) {
                            timeSize = 4;
                        } else {
                            timeSize = 5;
                        }
                        if (timeSize + 3 + 2 != tocopy) {
                            strcpy(ColValAfter, "NULL");
                            break;
                        }
                        ssecs = getNumFromStr(ColValBefore, timeSize);
                        days = (int)getNumFromStr(ColValBefore + timeSize, 3);
                        getDateFromDaysSince00010101(days, &year, &month, &today);
                        getTimeFromScaleSecsSince12AM(ssecs, Datares.ColumnData[i].TYPE_INFO.__SCALE, &hour, &min, &sec, &msec, &usec);
                        timeOffset = (short)getNumFromStr(ColValBefore + timeSize + 3, 2);
                        flagOff = (timeOffset >= 0) ? '+' : '-';
                        if (timeOffset < 0) timeOffset= -timeOffset;
                        hourOff = timeOffset / 60;
                        minOff = timeOffset % 60;
                        sprintf(ColValAfter, "%04d-%02d-%02d %02d:%02d:%02d.%04d%04d %c%02d:%02d",
                                year, month, today, hour, min, sec, msec, usec, flagOff, hourOff, minOff);
                        break;
#endif
                    case NVARCHARTYPE:
                    case NCHARTYPE:
                    case NTEXTTYPE:
                         codeConv("UCS-2", "UTF-8", ColValBefore, tocopy, ColValAfter, sizeof(ColValAfter)-1);
                         break;
                    case VARCHARTYPE:
                    case CHARTYPE:
                    case BINARYTYPE:
                    case VARBINARYTYPE:
                    case BIGVARBINTYPE:
                    case BIGVARCHRTYPE:
                    case BIGCHARTYPE:
                    case TEXTTYPE:
                    case IMAGETYPE:
#if __TDS_7_2
                    case XMLTYPE:
                    case SSVARIANTTYPE:
                    case UDTTYPE:
#endif
                        unprintable_to_space_tds(ColValBefore, tocopy, ColValAfter, sizeof(ColValAfter)-1);
                        break;
                }
            }

            if (0 != i) strcat(result_str, ";:s");
            strcat(result_str, ColValAfter);
        }
        strcat(result_str, ";:n");
    }

    //fprintf(stderr, "%s\n", result_str);
    return 0;
}

/*==================================================================================*/
/* ����2.2.3�� */
/* �����������
   �ɹ������������͵�appidֵ, ʧ�ܷ���-1
   ע�� - һ��request/reponse����������request��ȷ����reponse��һ�㶼��TYPE_Tabular_result
   ���ͣ�����������reponse����appid������30(����appid��Χ֮���һ����).*/
int TDS_parser(unsigned char *data, int len, char *result_str, int maxsize) {
    struct TDS_header tdsh;
    unsigned char *pos, *start;
    char actionWord[32];
    int leftlen, retval;
    result_str[0] = '\0';

    if (len <= 8) return other_flag;

    tdsh = *(struct TDS_header *)data;
    big_2_host(&(tdsh.Length), 2);
    pos = data + 8;
    leftlen = len - 8;

    switch (tdsh.Type) {
        case TYPE_Pre_Login:
            //PRELOGIN_parse(pos, leftlen, result_str, maxsize-1);
            return Pre_Login_flag;

        case TYPE_Pre_TDS7_Login:
        case TYPE_TDS7_Login:
            return TDS7_Login_flag;

        case TYPE_Federated_Authentication_Token:
            return Federated_Authentication_Token_flag;

        case TYPE_Bulk_load_data:
            //BulkLoadBCP_parse(pos, leftlen, result_str, maxsize-1);
            return Bulk_load_data_flag;

        case TYPE_RPC:
            //RPCRequest_parse(pos, leftlen, result_str, maxsize-1);
            return RPC_flag;

        case TYPE_Attention_signal:
            return Attention_signal_flag;

        case TYPE_Transaction_manager_request:
            //STransMgrReq_parse(pos, leftlen, result_str, maxsize-1);
            return Transaction_manager_request_flag;

        case TYPE_SSPI:
            return SSPI_flag;

        case TYPE_SQL_batch:
            retval = SQLBatch_parse(pos, leftlen, result_str, maxsize-1);
            if (retval < 0) { return error_flag; }
            pos = result_str;
            while (isspace((int)*pos) && *pos!='\0') {
                pos++;
            }
            start = pos;

            pos = strchr(start, ' ');
            if (NULL == pos) {
                return other_sql_flag; /* ����������� */
            }
            if (pos - start > (sizeof(actionWord)-1)) {
                return other_sql_flag; /* ����������� */
            }
            memset(actionWord, 0, sizeof(actionWord));
            memcpy(actionWord, start, pos-start);
            if (strncasecmp(actionWord, "select", strlen("select")) == 0) return select_flag;
            if (strncasecmp(actionWord, "update", strlen("update")) == 0) return update_flag;
            if (strncasecmp(actionWord, "delete", strlen("delete")) == 0) return delete_flag;
            if (strncasecmp(actionWord, "insert", strlen("insert")) == 0) return insert_flag;
            if (strncasecmp(actionWord, "creat", strlen("creat")) == 0) return creat_flag;
            if (strncasecmp(actionWord, "drop", strlen("drop")) == 0) return drop_flag;
            return other_sql_flag; /* ����������� */
        case TYPE_Tabular_result:
            ServerMgr_parse(pos, leftlen, result_str, maxsize-1); /* ��2.2.3.1.1������ */
            return other_flag;
        default:
            return other_flag;
    }
    return error_flag;
}

#if 0
char peer0_0[] = {
    0x12, 0x01, 0x00, 0x89, 0x00, 0x00, 0x00, 0x00,
    0x16, 0x03, 0x01, 0x00, 0x7C, 0x01, 0x00, 0x00,
    0x78, 0x03, 0x01, 0x55, 0xB5, 0x75, 0x48, 0xE4, 0xE2, 0x70, 0x82, 0x11, 0x9F, 0x42, 0xE5, 0x29,
    0x9F, 0xD6, 0x60, 0xA5, 0x40, 0x1E, 0xD6, 0x87, 0x35, 0xE7, 0x11, 0xEA, 0xBD, 0x0C, 0xC4, 0x48,
    0xCB, 0x75, 0xE2, 0x20, 0xFB, 0x20, 0x00, 0x00, 0xB2, 0xE8, 0xC0, 0x16, 0x32, 0xC4, 0xCA, 0x3A,
    0xD2, 0x2A, 0xB1, 0xEC, 0x3D, 0xA2, 0x68, 0xB0, 0x43, 0xF3, 0x50, 0x1B, 0x86, 0xE0, 0x3E, 0x43,
    0x32, 0x6E, 0x93, 0xF3, 0x00, 0x18, 0xC0, 0x14, 0xC0, 0x13, 0x00, 0x35, 0x00, 0x2F, 0xC0, 0x0A,
    0xC0, 0x09, 0x00, 0x38, 0x00, 0x32, 0x00, 0x0A, 0x00, 0x13, 0x00, 0x05, 0x00, 0x04, 0x01, 0x00,
    0x00, 0x17, 0x00, 0x0A, 0x00, 0x08, 0x00, 0x06, 0x00, 0x17, 0x00, 0x18, 0x00, 0x19, 0x00, 0x0B,
    0x00, 0x02, 0x01, 0x00, 0xFF, 0x01, 0x00, 0x01, 0x00
};

char ThreeRow5Column[] = {
0x04, 0x01, 0x01, 0xa2, 0x00, 0x35, 0x01, 0x00,
0x81, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0xef, 0x14, 0x00, 0x04, 0x08, 0xd0, 0x00,
0x00, 0x02, 0x61, 0x00, 0x31, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x63, 0xfe, 0xff, 0xff,
0x7f, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x02, 0x03,
0x00, 0x64, 0x00, 0x62, 0x00, 0x6f, 0x00, 0x0a,
0x00, 0x74, 0x00, 0x61, 0x00, 0x62, 0x00, 0x6c,
0x00, 0x65, 0x00, 0x54, 0x00, 0x65, 0x00, 0x73,
0x00, 0x74, 0x00, 0x41, 0x00, 0x02, 0x61, 0x00,
0x32, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0x6c, 0x11, 0x12, 0x00, 0x02, 0x61, 0x00, 0x33,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xe7,
0x64, 0x00, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x02,
0x61, 0x00, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0xe7, 0xff, 0xff, 0x04, 0x08, 0xd0,
0x00, 0x00, 0x02, 0x61, 0x00, 0x35, 0x00, 0xd1,
0x14, 0x00, 0x61, 0x00, 0x31, 0x00, 0x31, 0x00,
0x31, 0x00, 0x20, 0x00, 0x20, 0x00, 0x20, 0x00,
0x20, 0x00, 0x20, 0x00, 0x20, 0x00, 0x10, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x20, 0x74, 0x65, 0x78,
0x74, 0x70, 0x74, 0x72, 0x00, 0x00, 0x00, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x54, 0x53, 0x00, 0x08,
0x00, 0x00, 0x00, 0x61, 0x00, 0x32, 0x00, 0x32,
0x00, 0x32, 0x00, 0x05, 0x01, 0x03, 0x00, 0x00,
0x00, 0x02, 0x00, 0x34, 0x00, 0x02, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00,
0x00, 0x35, 0x00, 0x00, 0x00, 0x00, 0x00, 0xd1,
0x14, 0x00, 0x31, 0x00, 0x30, 0x00, 0x20, 0x00,
0x20, 0x00, 0x20, 0x00, 0x20, 0x00, 0x20, 0x00,
0x20, 0x00, 0x20, 0x00, 0x20, 0x00, 0x10, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x20, 0x74, 0x65, 0x78,
0x74, 0x70, 0x74, 0x72, 0x00, 0x00, 0x00, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x54, 0x53, 0x00, 0x04,
0x00, 0x00, 0x00, 0x32, 0x00, 0x30, 0x00, 0x05,
0x01, 0x1e, 0x00, 0x00, 0x00, 0x04, 0x00, 0x34,
0x00, 0x30, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x35,
0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0xd1,
0x14, 0x00, 0x31, 0x00, 0x30, 0x00, 0x30, 0x00,
0x20, 0x00, 0x20, 0x00, 0x20, 0x00, 0x20, 0x00,
0x20, 0x00, 0x20, 0x00, 0x20, 0x00, 0x10, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x20, 0x74, 0x65, 0x78,
0x74, 0x70, 0x74, 0x72, 0x00, 0x00, 0x00, 0x64,
0x75, 0x6d, 0x6d, 0x79, 0x54, 0x53, 0x00, 0x06,
0x00, 0x00, 0x00, 0x32, 0x00, 0x30, 0x00, 0x30,
0x00, 0x05, 0x01, 0x2c, 0x01, 0x00, 0x00, 0x06,
0x00, 0x34, 0x00, 0x30, 0x00, 0x30, 0x00, 0x06,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06,
0x00, 0x00, 0x00, 0x35, 0x00, 0x30, 0x00, 0x30,
0x00, 0x00, 0x00, 0x00, 0x00, 0xfd, 0x10, 0x00,
0xc1, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00 };

char OneRow28ColumnNoData[] = {
0x04, 0x01, 0x02, 0x43, 0x00, 0x36, 0x01, 0x00,
0x81, 0x1c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x26, 0x08, 0x02, 0x62, 0x00, 0x31, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xad, 0x32,
0x00, 0x02, 0x62, 0x00, 0x32, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x68, 0x01, 0x02, 0x62,
0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0xaf, 0x0a, 0x00, 0x04, 0x08, 0xd0, 0x00,
0x00, 0x02, 0x62, 0x00, 0x34, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x28, 0x02, 0x62, 0x00,
0x35, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0x6f, 0x08, 0x02, 0x62, 0x00, 0x36, 0x00, 0x00,
0x00, 0x00, 0x00, 0x08, 0x00, 0x2a, 0x07, 0x02,
0x62, 0x00, 0x37, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0x2b, 0x07, 0x02, 0x62, 0x00, 0x38,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6a,
0x11, 0x12, 0x00, 0x02, 0x62, 0x00, 0x39, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6d, 0x08,
0x03, 0x62, 0x00, 0x31, 0x00, 0x30, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0x22, 0xff, 0xff,
0xff, 0x7f, 0x02, 0x03, 0x00, 0x64, 0x00, 0x62,
0x00, 0x6f, 0x00, 0x0a, 0x00, 0x74, 0x00, 0x61,
0x00, 0x62, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x54,
0x00, 0x65, 0x00, 0x73, 0x00, 0x74, 0x00, 0x42,
0x00, 0x03, 0x62, 0x00, 0x31, 0x00, 0x31, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x26, 0x04,
0x03, 0x62, 0x00, 0x31, 0x00, 0x32, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0x6e, 0x08, 0x03,
0x62, 0x00, 0x31, 0x00, 0x33, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0xef, 0x14, 0x00, 0x04,
0x08, 0xd0, 0x00, 0x00, 0x03, 0x62, 0x00, 0x31,
0x00, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x63, 0xfe, 0xff, 0xff, 0x7f, 0x04, 0x08,
0xd0, 0x00, 0x00, 0x02, 0x03, 0x00, 0x64, 0x00,
0x62, 0x00, 0x6f, 0x00, 0x0a, 0x00, 0x74, 0x00,
0x61, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x65, 0x00,
0x54, 0x00, 0x65, 0x00, 0x73, 0x00, 0x74, 0x00,
0x42, 0x00, 0x03, 0x62, 0x00, 0x31, 0x00, 0x35,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6c,
0x11, 0x12, 0x00, 0x03, 0x62, 0x00, 0x31, 0x00,
0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0xe7, 0x64, 0x00, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x03, 0x62, 0x00, 0x31, 0x00, 0x37, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0xe7, 0xff, 0xff,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x03, 0x62, 0x00,
0x31, 0x00, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0x6d, 0x04, 0x03, 0x62, 0x00, 0x31,
0x00, 0x39, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x6f, 0x04, 0x03, 0x62, 0x00, 0x32, 0x00,
0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0x26, 0x02, 0x03, 0x62, 0x00, 0x32, 0x00, 0x31,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6e,
0x04, 0x03, 0x62, 0x00, 0x32, 0x00, 0x32, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x23, 0xff,
0xff, 0xff, 0x7f, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x02, 0x03, 0x00, 0x64, 0x00, 0x62, 0x00, 0x6f,
0x00, 0x0a, 0x00, 0x74, 0x00, 0x61, 0x00, 0x62,
0x00, 0x6c, 0x00, 0x65, 0x00, 0x54, 0x00, 0x65,
0x00, 0x73, 0x00, 0x74, 0x00, 0x42, 0x00, 0x03,
0x62, 0x00, 0x32, 0x00, 0x33, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x29, 0x07, 0x03, 0x62,
0x00, 0x32, 0x00, 0x34, 0x00, 0x50, 0x00, 0x00,
0x00, 0x01, 0x00, 0xad, 0x08, 0x00, 0x03, 0x62,
0x00, 0x32, 0x00, 0x35, 0x00, 0x00, 0x00, 0x00,
0x00, 0x09, 0x00, 0x26, 0x01, 0x03, 0x62, 0x00,
0x32, 0x00, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0xa7, 0x32, 0x00, 0x04, 0x08, 0xd0,
0x00, 0x00, 0x03, 0x62, 0x00, 0x32, 0x00, 0x37,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xa7,
0xff, 0xff, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x03,
0x62, 0x00, 0x32, 0x00, 0x38, 0x00, 0xfd, 0x10,
0x00, 0xc1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00 };

char OneRow28ColumnWithData[] = {
0x04, 0x01, 0x04, 0x11, 0x00, 0x36, 0x01, 0x00,
0x81, 0x1c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x26, 0x08, 0x02, 0x62, 0x00, 0x31, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xad, 0x32,
0x00, 0x02, 0x62, 0x00, 0x32, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x68, 0x01, 0x02, 0x62,
0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0xaf, 0x0a, 0x00, 0x04, 0x08, 0xd0, 0x00,
0x00, 0x02, 0x62, 0x00, 0x34, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x28, 0x02, 0x62, 0x00,
0x35, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0x6f, 0x08, 0x02, 0x62, 0x00, 0x36, 0x00, 0x00,
0x00, 0x00, 0x00, 0x08, 0x00, 0x2a, 0x07, 0x02,
0x62, 0x00, 0x37, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0x2b, 0x07, 0x02, 0x62, 0x00, 0x38,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6a,
0x11, 0x12, 0x00, 0x02, 0x62, 0x00, 0x39, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6d, 0x08,
0x03, 0x62, 0x00, 0x31, 0x00, 0x30, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0x22, 0xff, 0xff,
0xff, 0x7f, 0x02, 0x03, 0x00, 0x64, 0x00, 0x62,
0x00, 0x6f, 0x00, 0x0a, 0x00, 0x74, 0x00, 0x61,
0x00, 0x62, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x54,
0x00, 0x65, 0x00, 0x73, 0x00, 0x74, 0x00, 0x42,
0x00, 0x03, 0x62, 0x00, 0x31, 0x00, 0x31, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x26, 0x04,
0x03, 0x62, 0x00, 0x31, 0x00, 0x32, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0x6e, 0x08, 0x03,
0x62, 0x00, 0x31, 0x00, 0x33, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0xef, 0x14, 0x00, 0x04,
0x08, 0xd0, 0x00, 0x00, 0x03, 0x62, 0x00, 0x31,
0x00, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x63, 0xfe, 0xff, 0xff, 0x7f, 0x04, 0x08,
0xd0, 0x00, 0x00, 0x02, 0x03, 0x00, 0x64, 0x00,
0x62, 0x00, 0x6f, 0x00, 0x0a, 0x00, 0x74, 0x00,
0x61, 0x00, 0x62, 0x00, 0x6c, 0x00, 0x65, 0x00,
0x54, 0x00, 0x65, 0x00, 0x73, 0x00, 0x74, 0x00,
0x42, 0x00, 0x03, 0x62, 0x00, 0x31, 0x00, 0x35,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6c,
0x11, 0x12, 0x00, 0x03, 0x62, 0x00, 0x31, 0x00,
0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0xe7, 0x64, 0x00, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x03, 0x62, 0x00, 0x31, 0x00, 0x37, 0x00, 0x00,
0x00, 0x00, 0x00, 0x09, 0x00, 0xe7, 0xff, 0xff,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x03, 0x62, 0x00,
0x31, 0x00, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0x6d, 0x04, 0x03, 0x62, 0x00, 0x31,
0x00, 0x39, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x6f, 0x04, 0x03, 0x62, 0x00, 0x32, 0x00,
0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00,
0x26, 0x02, 0x03, 0x62, 0x00, 0x32, 0x00, 0x31,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x6e,
0x04, 0x03, 0x62, 0x00, 0x32, 0x00, 0x32, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x23, 0xff,
0xff, 0xff, 0x7f, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x02, 0x03, 0x00, 0x64, 0x00, 0x62, 0x00, 0x6f,
0x00, 0x0a, 0x00, 0x74, 0x00, 0x61, 0x00, 0x62,
0x00, 0x6c, 0x00, 0x65, 0x00, 0x54, 0x00, 0x65,
0x00, 0x73, 0x00, 0x74, 0x00, 0x42, 0x00, 0x03,
0x62, 0x00, 0x32, 0x00, 0x33, 0x00, 0x00, 0x00,
0x00, 0x00, 0x09, 0x00, 0x29, 0x07, 0x03, 0x62,
0x00, 0x32, 0x00, 0x34, 0x00, 0x50, 0x00, 0x00,
0x00, 0x01, 0x00, 0xad, 0x08, 0x00, 0x03, 0x62,
0x00, 0x32, 0x00, 0x35, 0x00, 0x00, 0x00, 0x00,
0x00, 0x09, 0x00, 0x26, 0x01, 0x03, 0x62, 0x00,
0x32, 0x00, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00,
0x09, 0x00, 0xa7, 0x32, 0x00, 0x04, 0x08, 0xd0,
0x00, 0x00, 0x03, 0x62, 0x00, 0x32, 0x00, 0x37,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xa7,
0xff, 0xff, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x03,
0x62, 0x00, 0x32, 0x00, 0x38, 0x00, 0xd1, 0x08,
0xe8, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x32, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x0a, 0x00,
0x34, 0x63, 0x68, 0x61, 0x72, 0x34, 0x34, 0x20,
0x20, 0x20, 0x03, 0x35, 0x34, 0x0b, 0x08, 0x6b,
0x96, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08,
0x00, 0x00, 0x00, 0x00, 0x00, 0x52, 0x2d, 0x0b,
0x0a, 0x00, 0x40, 0x23, 0x0e, 0x43, 0x5b, 0x95,
0x0a, 0x00, 0x00, 0x05, 0x01, 0x64, 0x00, 0x00,
0x00, 0x08, 0xc1, 0xca, 0xa1, 0x45, 0xb6, 0x33,
0x24, 0x40, 0x10, 0x64, 0x75, 0x6d, 0x6d, 0x79,
0x20, 0x74, 0x65, 0x78, 0x74, 0x70, 0x74, 0x72,
0x00, 0x00, 0x00, 0x64, 0x75, 0x6d, 0x6d, 0x79,
0x54, 0x53, 0x00, 0x09, 0x00, 0x00, 0x00, 0x31,
0x31, 0x69, 0x6d, 0x61, 0x67, 0x65, 0x31, 0x31,
0x04, 0xbc, 0x04, 0x00, 0x00, 0x08, 0x00, 0x00,
0x00, 0x00, 0x24, 0x5e, 0xc8, 0x00, 0x14, 0x00,
0x31, 0x00, 0x34, 0x00, 0x6e, 0x00, 0x63, 0x00,
0x68, 0x00, 0x61, 0x00, 0x72, 0x00, 0x20, 0x00,
0x20, 0x00, 0x20, 0x00, 0x10, 0x64, 0x75, 0x6d,
0x6d, 0x79, 0x20, 0x74, 0x65, 0x78, 0x74, 0x70,
0x74, 0x72, 0x00, 0x00, 0x00, 0x64, 0x75, 0x6d,
0x6d, 0x79, 0x54, 0x53, 0x00, 0x16, 0x00, 0x00,
0x00, 0x31, 0x00, 0x35, 0x00, 0x6e, 0x00, 0x74,
0x00, 0x65, 0x00, 0x78, 0x00, 0x74, 0x00, 0x31,
0x00, 0x35, 0x00, 0x31, 0x00, 0x35, 0x00, 0x00,
0x24, 0x00, 0x31, 0x00, 0x37, 0x00, 0x6e, 0x00,
0x76, 0x00, 0x61, 0x00, 0x72, 0x00, 0x63, 0x00,
0x68, 0x00, 0x61, 0x00, 0x72, 0x00, 0x28, 0x00,
0x35, 0x00, 0x30, 0x00, 0x29, 0x00, 0x31, 0x00,
0x37, 0x00, 0x31, 0x00, 0x37, 0x00, 0x26, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x26, 0x00,
0x00, 0x00, 0x31, 0x00, 0x38, 0x00, 0x6e, 0x00,
0x76, 0x00, 0x61, 0x00, 0x72, 0x00, 0x63, 0x00,
0x68, 0x00, 0x61, 0x00, 0x72, 0x00, 0x28, 0x00,
0x6d, 0x00, 0x61, 0x00, 0x78, 0x00, 0x29, 0x00,
0x31, 0x00, 0x38, 0x00, 0x31, 0x00, 0x38, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x8a, 0x97,
0xab, 0x02, 0x02, 0x49, 0x08, 0x04, 0xf8, 0x63,
0x03, 0x00, 0x10, 0x64, 0x75, 0x6d, 0x6d, 0x79,
0x20, 0x74, 0x65, 0x78, 0x74, 0x70, 0x74, 0x72,
0x00, 0x00, 0x00, 0x64, 0x75, 0x6d, 0x6d, 0x79,
0x54, 0x53, 0x00, 0x0a, 0x00, 0x00, 0x00, 0x32,
0x33, 0x74, 0x65, 0x78, 0x74, 0x32, 0x33, 0x32,
0x33, 0x05, 0x00, 0x08, 0xbf, 0x8d, 0x5f, 0x08,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0f,
0xa2, 0x01, 0x1a, 0x0f, 0x00, 0x32, 0x37, 0x76,
0x61, 0x72, 0x63, 0x68, 0x61, 0x72, 0x28, 0x35,
0x30, 0x29, 0x32, 0x37, 0x10, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00,
0x32, 0x38, 0x76, 0x61, 0x72, 0x63, 0x68, 0x61,
0x72, 0x28, 0x6d, 0x61, 0x78, 0x29, 0x32, 0x38,
0x00, 0x00, 0x00, 0x00, 0xfd, 0x10, 0x00, 0xc1,
0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00 };

char UnkownSelect[] = {
0x04, 0x01, 0x06, 0x68, 0x00, 0x34, 0x01, 0x00,
0x81, 0x24, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21,
0x00, 0xe7, 0xa6, 0x0a, 0x04, 0x08, 0xd0, 0x00,
0x00, 0x03, 0x55, 0x00, 0x72, 0x00, 0x6e, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0xe7, 0x00,
0x01, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x04, 0x4e,
0x00, 0x61, 0x00, 0x6d, 0x00, 0x65, 0x00, 0x00,
0x00, 0x00, 0x00, 0x08, 0x00, 0x38, 0x02, 0x49,
0x00, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09,
0x00, 0x68, 0x01, 0x08, 0x4e, 0x00, 0x75, 0x00,
0x6c, 0x00, 0x6c, 0x00, 0x61, 0x00, 0x62, 0x00,
0x6c, 0x00, 0x65, 0x00, 0x00, 0x00, 0x00, 0x00,
0x08, 0x00, 0x32, 0x08, 0x43, 0x00, 0x6f, 0x00,
0x6d, 0x00, 0x70, 0x00, 0x75, 0x00, 0x74, 0x00,
0x65, 0x00, 0x64, 0x00, 0x00, 0x00, 0x00, 0x00,
0x21, 0x00, 0x68, 0x01, 0x0c, 0x49, 0x00, 0x6e,
0x00, 0x50, 0x00, 0x72, 0x00, 0x69, 0x00, 0x6d,
0x00, 0x61, 0x00, 0x72, 0x00, 0x79, 0x00, 0x4b,
0x00, 0x65, 0x00, 0x79, 0x00, 0x00, 0x00, 0x00,
0x00, 0x08, 0x00, 0x32, 0x11, 0x41, 0x00, 0x6e,
0x00, 0x73, 0x00, 0x69, 0x00, 0x50, 0x00, 0x61,
0x00, 0x64, 0x00, 0x64, 0x00, 0x69, 0x00, 0x6e,
0x00, 0x67, 0x00, 0x53, 0x00, 0x74, 0x00, 0x61,
0x00, 0x74, 0x00, 0x75, 0x00, 0x73, 0x00, 0x00,
0x00, 0x00, 0x00, 0x21, 0x00, 0x68, 0x01, 0x0a,
0x52, 0x00, 0x6f, 0x00, 0x77, 0x00, 0x47, 0x00,
0x75, 0x00, 0x69, 0x00, 0x64, 0x00, 0x43, 0x00,
0x6f, 0x00, 0x6c, 0x00, 0x00, 0x00, 0x00, 0x00,
0x21, 0x00, 0x68, 0x01, 0x0f, 0x49, 0x00, 0x73,
0x00, 0x44, 0x00, 0x65, 0x00, 0x74, 0x00, 0x65,
0x00, 0x72, 0x00, 0x6d, 0x00, 0x69, 0x00, 0x6e,
0x00, 0x69, 0x00, 0x73, 0x00, 0x74, 0x00, 0x69,
0x00, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21,
0x00, 0x68, 0x01, 0x09, 0x49, 0x00, 0x73, 0x00,
0x50, 0x00, 0x72, 0x00, 0x65, 0x00, 0x63, 0x00,
0x69, 0x00, 0x73, 0x00, 0x65, 0x00, 0x00, 0x00,
0x00, 0x00, 0x20, 0x00, 0xe7, 0xff, 0xff, 0x04,
0x08, 0xd0, 0x00, 0x00, 0x0c, 0x43, 0x00, 0x6f,
0x00, 0x6d, 0x00, 0x70, 0x00, 0x75, 0x00, 0x74,
0x00, 0x65, 0x00, 0x64, 0x00, 0x54, 0x00, 0x65,
0x00, 0x78, 0x00, 0x74, 0x00, 0x00, 0x00, 0x00,
0x00, 0x21, 0x00, 0x68, 0x01, 0x0b, 0x49, 0x00,
0x73, 0x00, 0x50, 0x00, 0x65, 0x00, 0x72, 0x00,
0x73, 0x00, 0x69, 0x00, 0x73, 0x00, 0x74, 0x00,
0x65, 0x00, 0x64, 0x00, 0x00, 0x01, 0x00, 0x00,
0x20, 0x00, 0xe7, 0x00, 0x01, 0x04, 0x08, 0xd0,
0x00, 0x00, 0x09, 0x43, 0x00, 0x6f, 0x00, 0x6c,
0x00, 0x6c, 0x00, 0x61, 0x00, 0x74, 0x00, 0x69,
0x00, 0x6f, 0x00, 0x6e, 0x00, 0x00, 0x00, 0x00,
0x00, 0x21, 0x00, 0x68, 0x01, 0x0c, 0x49, 0x00,
0x73, 0x00, 0x46, 0x00, 0x6f, 0x00, 0x72, 0x00,
0x65, 0x00, 0x69, 0x00, 0x67, 0x00, 0x6e, 0x00,
0x4b, 0x00, 0x65, 0x00, 0x79, 0x00, 0x00, 0x00,
0x00, 0x00, 0x08, 0x00, 0x32, 0x08, 0x49, 0x00,
0x64, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x74, 0x00,
0x69, 0x00, 0x74, 0x00, 0x79, 0x00, 0x00, 0x00,
0x00, 0x00, 0x21, 0x00, 0x26, 0x08, 0x0c, 0x49,
0x00, 0x64, 0x00, 0x65, 0x00, 0x6e, 0x00, 0x74,
0x00, 0x69, 0x00, 0x74, 0x00, 0x79, 0x00, 0x53,
0x00, 0x65, 0x00, 0x65, 0x00, 0x64, 0x00, 0x00,
0x00, 0x00, 0x00, 0x21, 0x00, 0x26, 0x08, 0x11,
0x49, 0x00, 0x64, 0x00, 0x65, 0x00, 0x6e, 0x00,
0x74, 0x00, 0x69, 0x00, 0x74, 0x00, 0x79, 0x00,
0x49, 0x00, 0x6e, 0x00, 0x63, 0x00, 0x72, 0x00,
0x65, 0x00, 0x6d, 0x00, 0x65, 0x00, 0x6e, 0x00,
0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21, 0x00,
0xe7, 0x00, 0x01, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x07, 0x44, 0x00, 0x65, 0x00, 0x66, 0x00, 0x61,
0x00, 0x75, 0x00, 0x6c, 0x00, 0x74, 0x00, 0x00,
0x00, 0x00, 0x00, 0x21, 0x00, 0xe7, 0x00, 0x01,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x0d, 0x44, 0x00,
0x65, 0x00, 0x66, 0x00, 0x61, 0x00, 0x75, 0x00,
0x6c, 0x00, 0x74, 0x00, 0x53, 0x00, 0x63, 0x00,
0x68, 0x00, 0x65, 0x00, 0x6d, 0x00, 0x61, 0x00,
0x00, 0x00, 0x00, 0x00, 0x21, 0x00, 0xe7, 0x00,
0x01, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x04, 0x52,
0x00, 0x75, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x00,
0x00, 0x00, 0x00, 0x21, 0x00, 0xe7, 0x00, 0x01,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x0a, 0x52, 0x00,
0x75, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x53, 0x00,
0x63, 0x00, 0x68, 0x00, 0x65, 0x00, 0x6d, 0x00,
0x61, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00,
0x32, 0x11, 0x4e, 0x00, 0x6f, 0x00, 0x74, 0x00,
0x46, 0x00, 0x6f, 0x00, 0x72, 0x00, 0x52, 0x00,
0x65, 0x00, 0x70, 0x00, 0x6c, 0x00, 0x69, 0x00,
0x63, 0x00, 0x61, 0x00, 0x74, 0x00, 0x69, 0x00,
0x6f, 0x00, 0x6e, 0x00, 0x00, 0x00, 0x00, 0x00,
0x21, 0x00, 0x68, 0x01, 0x11, 0x49, 0x00, 0x73,
0x00, 0x46, 0x00, 0x75, 0x00, 0x6c, 0x00, 0x6c,
0x00, 0x54, 0x00, 0x65, 0x00, 0x78, 0x00, 0x74,
0x00, 0x49, 0x00, 0x6e, 0x00, 0x64, 0x00, 0x65,
0x00, 0x78, 0x00, 0x65, 0x00, 0x64, 0x00, 0x00,
0x00, 0x00, 0x00, 0x21, 0x00, 0x68, 0x01, 0x0c,
0x49, 0x00, 0x73, 0x00, 0x46, 0x00, 0x69, 0x00,
0x6c, 0x00, 0x65, 0x00, 0x53, 0x00, 0x74, 0x00,
0x72, 0x00, 0x65, 0x00, 0x61, 0x00, 0x6d, 0x00,
0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x68, 0x01,
0x08, 0x49, 0x00, 0x73, 0x00, 0x53, 0x00, 0x70,
0x00, 0x61, 0x00, 0x72, 0x00, 0x73, 0x00, 0x65,
0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x68,
0x01, 0x0b, 0x49, 0x00, 0x73, 0x00, 0x43, 0x00,
0x6f, 0x00, 0x6c, 0x00, 0x75, 0x00, 0x6d, 0x00,
0x6e, 0x00, 0x53, 0x00, 0x65, 0x00, 0x74, 0x00,
0x00, 0x01, 0x00, 0x00, 0x09, 0x00, 0xe7, 0x00,
0x01, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x08, 0x44,
0x00, 0x61, 0x00, 0x74, 0x00, 0x61, 0x00, 0x54,
0x00, 0x79, 0x00, 0x70, 0x00, 0x65, 0x00, 0x00,
0x01, 0x00, 0x00, 0x09, 0x00, 0xe7, 0x00, 0x01,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x0e, 0x44, 0x00,
0x61, 0x00, 0x74, 0x00, 0x61, 0x00, 0x54, 0x00,
0x79, 0x00, 0x70, 0x00, 0x65, 0x00, 0x53, 0x00,
0x63, 0x00, 0x68, 0x00, 0x65, 0x00, 0x6d, 0x00,
0x61, 0x00, 0x00, 0x01, 0x00, 0x00, 0x20, 0x00,
0xe7, 0x00, 0x01, 0x04, 0x08, 0xd0, 0x00, 0x00,
0x0a, 0x53, 0x00, 0x79, 0x00, 0x73, 0x00, 0x74,
0x00, 0x65, 0x00, 0x6d, 0x00, 0x54, 0x00, 0x79,
0x00, 0x70, 0x00, 0x65, 0x00, 0x00, 0x00, 0x00,
0x00, 0x21, 0x00, 0x26, 0x04, 0x06, 0x4c, 0x00,
0x65, 0x00, 0x6e, 0x00, 0x67, 0x00, 0x74, 0x00,
0x68, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21, 0x00,
0x26, 0x04, 0x10, 0x4e, 0x00, 0x75, 0x00, 0x6d,
0x00, 0x65, 0x00, 0x72, 0x00, 0x69, 0x00, 0x63,
0x00, 0x50, 0x00, 0x72, 0x00, 0x65, 0x00, 0x63,
0x00, 0x69, 0x00, 0x73, 0x00, 0x69, 0x00, 0x6f,
0x00, 0x6e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21,
0x00, 0x26, 0x04, 0x0c, 0x4e, 0x00, 0x75, 0x00,
0x6d, 0x00, 0x65, 0x00, 0x72, 0x00, 0x69, 0x00,
0x63, 0x00, 0x53, 0x00, 0x63, 0x00, 0x61, 0x00,
0x6c, 0x00, 0x65, 0x00, 0x00, 0x01, 0x00, 0x00,
0x20, 0x00, 0xe7, 0x00, 0x01, 0x04, 0x08, 0xd0,
0x00, 0x00, 0x12, 0x58, 0x00, 0x6d, 0x00, 0x6c,
0x00, 0x53, 0x00, 0x63, 0x00, 0x68, 0x00, 0x65,
0x00, 0x6d, 0x00, 0x61, 0x00, 0x4e, 0x00, 0x61,
0x00, 0x6d, 0x00, 0x65, 0x00, 0x73, 0x00, 0x70,
0x00, 0x61, 0x00, 0x63, 0x00, 0x65, 0x00, 0x00,
0x01, 0x00, 0x00, 0x20, 0x00, 0xe7, 0x00, 0x01,
0x04, 0x08, 0xd0, 0x00, 0x00, 0x18, 0x58, 0x00,
0x6d, 0x00, 0x6c, 0x00, 0x53, 0x00, 0x63, 0x00,
0x68, 0x00, 0x65, 0x00, 0x6d, 0x00, 0x61, 0x00,
0x4e, 0x00, 0x61, 0x00, 0x6d, 0x00, 0x65, 0x00,
0x73, 0x00, 0x70, 0x00, 0x61, 0x00, 0x63, 0x00,
0x65, 0x00, 0x53, 0x00, 0x63, 0x00, 0x68, 0x00,
0x65, 0x00, 0x6d, 0x00, 0x61, 0x00, 0x00, 0x00,
0x00, 0x00, 0x20, 0x00, 0x38, 0x15, 0x58, 0x00,
0x6d, 0x00, 0x6c, 0x00, 0x44, 0x00, 0x6f, 0x00,
0x63, 0x00, 0x75, 0x00, 0x6d, 0x00, 0x65, 0x00,
0x6e, 0x00, 0x74, 0x00, 0x43, 0x00, 0x6f, 0x00,
0x6e, 0x00, 0x73, 0x00, 0x74, 0x00, 0x72, 0x00,
0x61, 0x00, 0x69, 0x00, 0x6e, 0x00, 0x74, 0x00,
0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0xe7, 0x14,
0x00, 0x04, 0x08, 0xd0, 0x00, 0x00, 0x08, 0x55,
0x00, 0x73, 0x00, 0x65, 0x00, 0x72, 0x00, 0x54,
0x00, 0x79, 0x00, 0x70, 0x00, 0x65, 0x00, 0xd1,
0xf6, 0x00, 0x53, 0x00, 0x65, 0x00, 0x72, 0x00,
0x76, 0x00, 0x65, 0x00, 0x72, 0x00, 0x5b, 0x00,
0x40, 0x00, 0x4e, 0x00, 0x61, 0x00, 0x6d, 0x00,
0x65, 0x00, 0x3d, 0x00, 0x27, 0x00, 0x58, 0x00,
0x50, 0x00, 0x2d, 0x00, 0x32, 0x00, 0x30, 0x00,
0x31, 0x00, 0x33, 0x00, 0x31, 0x00, 0x30, 0x00,
0x33, 0x00, 0x31, 0x00, 0x31, 0x00, 0x38, 0x00,
0x33, 0x00, 0x35, 0x00, 0x27, 0x00, 0x5d, 0x00,
0x2f, 0x00, 0x44, 0x00, 0x61, 0x00, 0x74, 0x00,
0x61, 0x00, 0x62, 0x00, 0x61, 0x00, 0x73, 0x00,
0x65, 0x00, 0x5b, 0x00, 0x40, 0x00, 0x4e, 0x00,
0x61, 0x00, 0x6d, 0x00, 0x65, 0x00, 0x3d, 0x00,
0x27, 0x00, 0x61, 0x00, 0x75, 0x00, 0x64, 0x00,
0x69, 0x00, 0x74, 0x00, 0x5f, 0x00, 0x74, 0x00,
0x65, 0x00, 0x73, 0x00, 0x74, 0x00, 0x27, 0x00,
0x5d, 0x00, 0x2f, 0x00, 0x54, 0x00, 0x61, 0x00,
0x62, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x5b, 0x00,
0x40, 0x00, 0x4e, 0x00, 0x61, 0x00,
0x6d, 0x00, 0x65, 0x00, 0x3d, 0x00, 0x27, 0x00,
0x74, 0x00, 0x61, 0x00, 0x62, 0x00, 0x6c, 0x00,
0x65, 0x00, 0x54, 0x00, 0x65, 0x00, 0x73, 0x00,
0x74, 0x00, 0x42, 0x00, 0x27, 0x00, 0x20, 0x00,
0x61, 0x00, 0x6e, 0x00, 0x64, 0x00, 0x20, 0x00,
0x40, 0x00, 0x53, 0x00, 0x63, 0x00, 0x68, 0x00,
0x65, 0x00, 0x6d, 0x00, 0x61, 0x00, 0x3d, 0x00,
0x27, 0x00, 0x64, 0x00, 0x62, 0x00, 0x6f, 0x00,
0x27, 0x00, 0x5d, 0x00, 0x2f, 0x00, 0x43, 0x00,
0x6f, 0x00, 0x6c, 0x00, 0x75, 0x00, 0x6d, 0x00,
0x6e, 0x00, 0x5b, 0x00, 0x40, 0x00, 0x4e, 0x00,
0x61, 0x00, 0x6d, 0x00, 0x65, 0x00, 0x3d, 0x00,
0x27, 0x00, 0x62, 0x00, 0x31, 0x00, 0x27, 0x00,
0x5d, 0x00, 0x04, 0x00, 0x62, 0x00, 0x31, 0x00,
0x01, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01,
0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
0x01, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00,
0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x0c, 0x00,
0x62, 0x00, 0x69, 0x00, 0x67, 0x00, 0x69, 0x00,
0x6e, 0x00, 0x74, 0x00, 0x06, 0x00, 0x73, 0x00,
0x79, 0x00, 0x73, 0x00, 0x0c, 0x00, 0x62, 0x00,
0x69, 0x00, 0x67, 0x00, 0x69, 0x00, 0x6e, 0x00,
0x74, 0x00, 0x04, 0x08, 0x00, 0x00, 0x00, 0x04,
0x13, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
0x00, 0x00, 0x00, 0xff, 0x11, 0x00, 0xc1, 0x00,
0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x79, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x00, 0x00,
0xe0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00 };

char select_from_tableTestB[] = {
0x01, 0x01, 0x00, 0x58, 0x00, 0x00, 0x01, 0x00,
0x16, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00,
0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x73, 0x00,
0x65, 0x00, 0x6c, 0x00, 0x65, 0x00, 0x63, 0x00,
0x74, 0x00, 0x20, 0x00, 0x2a, 0x00, 0x20, 0x00,
0x66, 0x00, 0x72, 0x00, 0x6f, 0x00, 0x6d, 0x00,
0x20, 0x00, 0x64, 0x00, 0x62, 0x00, 0x6f, 0x00,
0x2e, 0x00, 0x74, 0x00, 0x61, 0x00, 0x62, 0x00,
0x6c, 0x00, 0x65, 0x00, 0x54, 0x00, 0x65, 0x00,
0x73, 0x00, 0x74, 0x00, 0x42, 0x00, 0x3b, 0x00 };


int main(int argc, char **argv) {
    int retval;
    char buf[1024*10] = {0};

    retval = TDS_parser(OneRow28ColumnWithData, sizeof(OneRow28ColumnWithData), buf, sizeof(buf));
    fprintf(stderr, "retval=%d\n"
                    "result = %s\n", retval, buf);

    retval = TDS_parser(select_from_tableTestB, sizeof(select_from_tableTestB), buf, sizeof(buf));
    fprintf(stderr, "retval=%d\n"
                    "result = %s\n", retval, buf);

    return 0;
}
#endif


