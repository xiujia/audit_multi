#ifndef HBASE_PUBULIC_H
#define HBASE_PUBULIC_H

#define HBASE_TABLE_NAME		"cache_monitor_data_"
#define HBASE_TABLE_PORTAL_TELNET	"cache_portal_telnet_data_"
#define HBASE_FILE_PATH			"/data/audit/sql/"

#endif
