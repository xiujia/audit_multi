#ifndef AUDIT_RELEASE_H
#define AUDIT_RELEASE_H

#define AUDIT_DEBUG 	0	
#define DEBUG_AUDITP 	0
#define AUDITLOG_DEBUG	0
#define AUDIT_TEST   0 /*�������汾*/
#define CSP_DEBUG	0	
#define CSP_RELEASE_DEBUG		0	
#define CSP_RM_FILE				1
#define CSP_SQL_RM_FILE			1
#define NOLOOP					0
#define REL_HBASE			1
#define RUN_FLAG	0	
#endif
