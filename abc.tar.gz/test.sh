echo "ipNetToMediaPhysAddress.31.10.10.$1.$2 = Hex-STRING: 3C E5 A6 E1 1A 4B " >> /media/data/tmp/1.tmp
