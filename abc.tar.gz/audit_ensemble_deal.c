

#include <iconv.h>
#include "csp_policy.h"
#include "audit_ensemble.h"
#include "audit_release.h"
#include "redis_new_api.h"
#include <time.h>

#define SQL_BACKUP "/home/zuo/"
#define SQL_DEBUG  "/home/debug/"


AUDIT_ENSEMBLE_REL   ensembleRel;
#define SQLKEYWORDLEN  6
#define OPTKEYWORDLEN	7

#define SQL_SEARCH_OPT	  0x4451
#define SQL_SEARCH_OPT_RP 0X5051
#define SQL_MODIFY_OPT	  0X4455
#define SQL_MODIFY_OPT_RP 0X5055
#define STUDIO_SAVEFILE_OPT 0X4249
#define STUDIO_OPT		  0X4237

#define SEP_FLAG 	";:s"
#define ENTER_FLAG	";:n"


char * file_request;
char * file_response;

char request_cmd_debug[500];
char response_cmd_debug[500];

unsigned char fileContent[REQ_RES_LEN];
unsigned char from_segment[REQ_RES_LEN];
unsigned char to_segment[REQ_RES_LEN];
unsigned char segment_str[REQ_RES_LEN];

unsigned char ensemble_payload[REQ_RES_LEN];
unsigned char cmd1[AUDIT_COMMAND_LEN];
unsigned char cmd2[AUDIT_COMMAND_LEN];
unsigned char datamonth[AUDIT_TIME_LEN];
unsigned long first_len;
int  runFlag;


char *sqlKeyWord[SQLKEYWORDLEN]={
	"Select", //6
	"Update",//7
	"Delete",//8
	"Insert",//9
	"Create",//10
	"Drop"//11
};

OPTKEYS optKeyWord[OPTKEYWORDLEN]={
	{"%Studio.ClassMgr","SaveDefinition"}, //save cls
	{"%Studio.ClassMgr","GetDefinition"},//open cls
	{"%Library.qccServer","DeleteClassDefinition"},//delete cls
	{"%Library.RoutineMgr","Delete"},//delete file
	{"%Library.RoutineMgr","CompileClass"}, //compile
	{"New",""},
	{"Code",""}//open or save
	};

void SigFun(int sig){

	switch(sig){
		case SIGINT:
			exit(0);
		case SIGTERM:
			exit(0);
		case SIGSEGV:
			#if RUN_FLAG
			system(response_cmd_debug);
			system(request_cmd_debug);
			#else
			system(cmd2);
			system(cmd1);
			#endif
			printf("ensemble SIGSEGV signale .\n");
			exit(0);
			break;
		case SIGBUS:
			#if RUN_FLAG
			system(response_cmd_debug);
			system(request_cmd_debug);
			#else
			system(cmd2);
			system(cmd1);
			#endif

			printf("ensemble SIGBUS signale .\n");
			exit(0);
			break;
		default:
			exit(0);
			break;
	}
}

int medtrakTest(unsigned char *data,unsigned int size){

	unsigned int  pLen;
	unsigned char *start;
	unsigned long readLen = 0;



	start = data;
	pLen = *((unsigned int *)start);
	if(pLen == 0) return -1;

	do{
		start = data+readLen;
		pLen = *((unsigned int *)start);
		if(pLen == 0){
			return -1;
		}
		if(pLen > size){
			return 0;
		}

		readLen += pLen;
	}while(readLen < size);

	if(readLen == size ) return 1;

	return 0;
}

/* �ַ���ת�����ɹ��򷵻ؽ�������ȣ�ʧ�ܷ���-1
   ע�� - GBK/GB2312�ȣ�����һ�֣���������֮��ת������iconv()�ϳ��� */
int codeConv(char* srcCharSet, char *dstCharSet, char *src, size_t srcLen, char *dst, size_t dstMaxSize) {
    iconv_t cd;
    size_t tmpLen = dstMaxSize;
    char *tmppos = dst;

    if (NULL==srcCharSet || NULL==dstCharSet || NULL==src || NULL==dst || srcLen<0 || dstMaxSize<0 ) {
        perror("Incorrect parameter\n");
        return -1;
    }

    /* �����߶���GBK��һ��ʱ������Ҫת�� */
    if ((('G'==srcCharSet[0] || 'g'==srcCharSet[0]) && ('B'==srcCharSet[1] || 'b'==srcCharSet[1]))
        && (('G'==dstCharSet[0] || 'g'==dstCharSet[0]) && ('B'==dstCharSet[1] || 'b'==dstCharSet[1]))) {
        memcpy(dst, src, srcLen);
        return srcLen;
    }

    cd = iconv_open(dstCharSet, srcCharSet);
    if((iconv_t)-1 == cd ){ perror("iconv_open() failed\n"); return -1; }

    memset(dst, 0, dstMaxSize);
    if(iconv(cd, &src, &srcLen, &tmppos, &tmpLen) < 0){
        iconv_close(cd);
        perror("iconv() failed\n");
        return -1;
    }
    iconv_close(cd);

    dst[dstMaxSize - tmpLen] = '\0';
    return (dstMaxSize - tmpLen);
}

//#define DEBUG_PRINT(s) fprintf(stderr, "<%s> : %d : %s\n", __FILE__, __LINE__, (s))
#define DEBUG_PRINT(s)
#if 0
int medtrakParser(char *data, int len, char *res, long *reslen) {
    char *pos = data + 56;
    int parseLen = 0, totalLen;
    unsigned short thisPartLen, flag;
    if (!data || len<0 || !res || !reslen) {
        DEBUG_PRINT("!data || len<0 || !res || !reslen");
        return -1;
    }
    totalLen = *(unsigned int *)data;
    if (totalLen != len) {
        DEBUG_PRINT("totalLen != len");
        return -1;
    }
    while (pos+2 <= data+len) {
        thisPartLen = *(unsigned short *)pos;
        pos += 2;
        if (pos + thisPartLen > data+len) {
            DEBUG_PRINT("pos + thisPartLen > data+len");
            return -1;
        }

        flag = *(unsigned short *)pos;
        pos += 2;
        thisPartLen -= 2;

        if (0x08 == flag) {
            int convLen = codeConv("UCS-2", "gbk", pos, thisPartLen, res+parseLen, *reslen-parseLen);
            if (convLen < 0) {
                DEBUG_PRINT("codeConv() failed");
                return -1;
            }
            parseLen += convLen;
            res[parseLen++] = ' ';
        } else if (0x0e == flag){
            memcpy(res+parseLen, pos, thisPartLen);
            parseLen += thisPartLen;
            res[parseLen++] = ' ';
        } else {
            DEBUG_PRINT("flag!=0x08 or 0x0e");
            return -1;
        }
        pos += thisPartLen;
    }
    *(res+parseLen) = '\0';
    *reslen = parseLen;
    return 0;
}
#endif
int medtrakParser(char *data, int len, char *res, long *reslen) {
    char *pos, tmpIdxStr[64];
    int parseLen, i, count;
    unsigned short thisPartLen, flag;
    if (*(unsigned int *)data != len) {
        DEBUG_PRINT("*(unsigned int *)data != len");
        strcpy(res, "NULL");
        *reslen = 4;
        return -1;
    }
    pos = data + 56;
    parseLen = count = 0;
    while (pos+2 <= data+len) {
        thisPartLen = *(unsigned short *)pos;
        pos += 2;
        if (pos + thisPartLen > data+len) { DEBUG_PRINT("pos + thisPartLen > data+len"); *(res+parseLen) = '\0', *reslen = parseLen; return -1; }

        flag = *(unsigned short *)pos;
        pos += 2;
        thisPartLen -= 2;

        #if 0
        sprintf(tmpIdxStr, " <%02d>", count++);
        strcpy(res+parseLen, tmpIdxStr);
        parseLen += strlen(tmpIdxStr);
        #else
        res[parseLen++] = ' ';
        #endif

        if (thisPartLen > 0) {
            if (0x08 == flag) {
                if (0x0 == pos[0]) {
                    strcpy(res+parseLen, "08NULL");
                    parseLen += 6;
                } else {
                    int convLen = codeConv("unicode", "gbk", pos, thisPartLen, res+parseLen, 10*1024*1024-parseLen);
                    if (convLen < 0) {
                        DEBUG_PRINT("codeConv() failed");
                        strcpy(res+parseLen, "codeCovNULL");
                        parseLen += 11;
                        return -1;
                    }
                    parseLen += convLen;
                }
            } else if (0x0e == flag){
                for (i=0; i<thisPartLen; i++) {
                    if (pos[i]<0x20 || pos[i]>0x7e) {
                        sprintf(res+parseLen, "0x%02x ", pos[i]);
                        parseLen += 5;
                    } else {
                        res[parseLen++] = pos[i];
                    }
                }
            } else {
                DEBUG_PRINT("flag!=0x08 or 0x0e");
                sprintf(res+parseLen, "flag=0x%04x:", flag);
                parseLen += 12;
                for (i=0; i<thisPartLen; i++) {
                    sprintf(res+parseLen, "0x%02x ", pos[i]);
                    parseLen += 5;
                }
            }
            pos += thisPartLen;
        } else {
            strcpy(res+parseLen, "NULL");
            parseLen += 4;
        }
    }
    *(res+parseLen) = '\0';
    *reslen = parseLen;
    return 0;
}


static int GetOperationType(char * resault){
	int i;
	for(i=0; i<=6; i++){
		if(i==5&&strcasestr(resault,optKeyWord[i].key1)){
			return 7;
		}
		if(i==6&&strcasestr(resault,optKeyWord[i].key1)){
			return 1;
		}
		if(strcasestr(resault,optKeyWord[i].key1)&&strcasestr(resault,optKeyWord[i].key2)){
			return (i+2);
		}
	}
	return 0;
}
static int GetAppType(char * resault){
	  int i=0;

	  for(i=0;i<6;i++){
		if(strcasestr(resault,sqlKeyWord[i])){
			return i+6;
/*
			switch(i){
				case 0:
					return 6;
				case 1:
					return 7;
				case 2:
					return 8;
				case 3:
					return 9;
				case 4:
					return 10;
				case 5:
					return 11;
				case 6:
					return 12;

			}*/
		}
	  }

	  return -1;
}
static int GetPolicyTime(unsigned long time){
	int  time_sec=0;
	int  time_min=0;
	const int time_zone = 8*60;
	const int week_min = 7*24*60;
	const int day_min = 24*60;
	const int monday_start = 4*24*60;
	int res;
	time_sec = time/1000000;
	time_min = time_sec/60;

	res = (time_min + time_zone - monday_start)%week_min;

	return res;
}
static void SetMac(char *dest,char *src){
	int i,j;
	j=0;
	for(i=0;i<strlen(src);i++){
		dest[j]=src[i];

		j++;
		if(j%3==2){
			dest[j]='-';
			j++;
		}

	}
	dest[j-1]='\0';
}
static int IsOld(char *filePath, int secs) {
    time_t t;
	int retval;
    struct stat ft;

    retval = time(&t);
    if (retval < 0) return 0;

    retval = stat(filePath, &ft);
    if (retval < 0) return 0;

    if (t - ft.st_mtime > secs) return 1;
    return 0;
}

int AuditWrite(int Fd,char *psData,int Len){
	int writtenSuccsesBytes = 0;
	int writtenBytes = 0;
 	while(1){
		writtenSuccsesBytes = write(Fd,psData + writtenBytes,Len - writtenBytes );
		if (writtenSuccsesBytes == -1) {
			return -1;
			perror("write:");
		}
		writtenBytes += writtenSuccsesBytes;
		if (writtenBytes < Len) {
			continue;
		} else if (writtenBytes == Len) {
			break;
		}
	}
	return writtenBytes;
}
static unsigned long GetFileSize(char *filename)
{
    struct stat buf;
    if(stat(filename, &buf)<0)
        {
        return 0;
    }
    return (unsigned long)buf.st_size;
}

time_t GetFileTime(char * filename){
	struct stat buf;
    if(stat(filename, &buf)<0)
        {
        return 0;
    }
	 return buf.st_mtime;
}

void GetValues(AUDIT_ENSEMBLE_REL *rel,char *filename){
	// /dev/shm/1/10_2887326051_000fe25c06a0_60100_168466306_80c16ef872cd_1433_0_2_1440906275885842_request
	unsigned short sport;
	unsigned short dport;
	unsigned short app_id;
	unsigned short user_id;
	unsigned int sip;
	unsigned int dip;
	unsigned int reqsize;
	unsigned int respsize;
	unsigned int seq;
	unsigned long time;
	int policy_time;
	char smac[20]={0},dmac[20]={0};

	int relval;
	relval = sscanf(filename, "%hu_%u_%[^_]_%hu_%u_%[^_]_%hu_%hu_%u_%lu_request",
                    &app_id, &sip, smac,&sport, &dip, dmac,&dport, &user_id,&seq , &time);

//	printf("%hu,%u,%s,%hu,%u,%s,%hu,%hu,%u,%lu\n", app_id, sip, smac,sport, dip, dmac,dport, user_id,seq , time);

	if(app_id == 100) rel->type=1;
	if(app_id == 110) rel->type=30;
	if(app_id == 40) rel->type=4;
	if(app_id>19 && app_id<30) rel->type=2;
	sip = htonl(sip);
	dip = htonl(dip);
	sprintf(rel->id,"%u",app_id);
	sprintf(rel->serport,"%u",dport);
	sprintf(rel->cliport,"%u",sport);
	sprintf(rel->userid,"%u",user_id);
	sprintf(rel->times,"%lu",time);
	sprintf(rel->table,"%s",datamonth);
	inet_ntop(AF_INET,(void*)(&sip),rel->userip,sizeof(rel->userip));
	inet_ntop(AF_INET,(void*)(&dip),rel->desip,sizeof(rel->desip));
	SetMac(rel->srcmac,smac);
	get_mac_str(rel->userip,rel->srcmac);
	SetMac(rel->desmac,dmac);
	policy_time = GetPolicyTime(time);
	sprintf(rel->policytime,"%d",policy_time);
//	printf("policytime:%s\n",rel->policytime);
//	sprintf(rel->srcmac,"00-00-00-00-00-00");
//	sprintf(rel->desmac,"11-11-11-11-11-11");
	rel->saveflag = -1;
}
int getfilename(char * fullpath,char *filename,char *filepath,char *dir,int len){
	int i=0,position=0,lastposition=0;
	int flen,j=0;
	for(i=len-1;i>0;i--){
		if(fullpath[i]=='/'){
			j++;
			if(j==1){
				position=i;
				flen = len-position;
				if(flen < 0) return 0;
				strncpy(filename,&fullpath[position+1],flen-1);
				strncpy(filepath,fullpath,len-flen+1);
				lastposition = position;
			}
			if(j==2){
				position = i;
				flen = lastposition - position;
				if(flen < 0) return 0;
				strncpy(dir,&fullpath[position+1],flen-1);
				lastposition = position;
			}
		}

	}
	return 0;
}

int FileInit(char * filename,AUDIT_ENSEMBLE_REL *rel){
//	char *data ;

	FILE * Fp = NULL;
	unsigned int fsize =0;
	unsigned int readsize = 0;
	memset(fileContent,0,CSP_FILE_MAX_LEN*sizeof(char));

	fsize = GetFileSize(filename);
	if(fsize <=0){
		return -1;
	}

	if(fsize > CSP_FILE_MAX_LEN*sizeof(char)){
		return -1;
	}



	Fp = fopen(filename,"r+");
	if(!Fp){
		#if CSP_DEBUG
		printf("open %s file failed. \n",filename);
		#endif
		return  -1;
	}

	readsize = fread(fileContent,1,fsize,Fp);

	if(readsize != fsize){
		#if CSP_DEBUG
		printf("fread error.\n");
		#endif
		fclose(Fp);
		return -1;
	}

	rel->data = fileContent;
	rel->size = readsize;

	fclose(Fp);
	Fp = NULL;

	return 0;


}




long GetEnsemblePayload(char *data,unsigned int  size,char *ensemble_payload,unsigned short * request_type,int flag){
		long readLen=0;
		long len=0;
		long dataLen=0;
		AUDIT_ENSEMBLE_HEAD *head;
		int i=0;

		do{

			head = (AUDIT_ENSEMBLE_HEAD*)(data+readLen);
			len = head->plen;
			if(i==0&&flag ==1){
				*request_type=ntohs(head->opt_flg);

			}
			if(i == 0){
				first_len = len;
			}

			if(len < 0 ||len > size){
				return -1;
			}
			memcpy(ensemble_payload+dataLen,(char *)head+14,len);
			dataLen += head->plen;
			readLen += (len +14);
			i++;
		}while(readLen < size);

		return dataLen;
}


unsigned int Change_encode_2(char *from,unsigned int fromLen,char *to){

	char * head;
	int i,j;
	unsigned int toLen;
	head = from;
	i = 0;
	j = 0;

		while(j < fromLen){
			if(from[j]==0x00){
				j++;
				continue;
			}
			to[i] = from[j];
			j++;
			i++;
		}
		toLen = i;

}


int code_convert(char *from_charset,char *to_charset,char  * from_str, size_t  from_len,char  * to_str, size_t to_len){
	 iconv_t   cd;

	 cd = iconv_open(to_charset,from_charset);
	  if   (cd==(iconv_t)-1)   return   -1;


	  if(iconv(cd,&from_str,&from_len,&to_str,&to_len)==-1) {
		perror("iconv");
		iconv_close(cd);
		return -1;
	  }
	  iconv_close(cd);
	  return strlen(to_str);

}

unsigned int Change_encode_3(char *from,unsigned int fromLen,char *to, unsigned int toLen){

	 char fromset[]="unicode";
	 char toset[]="gbk";

	if(code_convert(fromset,toset,from,fromLen,to,toLen)==-1){

		return 0;
	}


	return 1;
}
unsigned int Change_encode(int type,unsigned char *from_segment,int from_len,unsigned char *to_segment,int to_len){
	unsigned rel = 0;
	switch(type){
		case 0x01:
			memcpy(to_segment,from_segment,from_len);
			return from_len;
		case 0x02:
			rel = Change_encode_3(from_segment,from_len,to_segment,to_len);
			break;
		default:
			return Change_encode_2(from_segment, from_len,to_segment);
			break;
	}
	if(rel == 1)
		return strlen(to_segment);

	return 0;
}

void GetSegmentValues(unsigned char *from,unsigned int fromLen,char * to,unsigned int * toLen){
	char type;
	unsigned int len;
	char zero[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	*toLen = fromLen;
	len = *toLen;
	memcpy(to,from,len);
	memcpy(to+len,zero,8);
}

void DataReleaseSearchOptRequest(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL *rel){
	AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;

	unsigned char *start = NULL;
	unsigned short parmNum = 0;//��������
	unsigned short loopNum = 0;//ѭ������
	int segCount = 0;//�ֶμ���
	int segLen = 0;//�ֶγ���
	int fromLen = 0;//�ֶ����ݳ���
	int toLen  = 0;
	int count;
	long readLen = 0;
	long dataLen = 0;
	char segType;

	start = ensemblePayload;

	do{
		if(*start != 0x00){
			data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;
			segLen = data_st->len;
			if(segLen == 1){
				fromLen = 0;
				readLen += segLen;
				start = ensemblePayload+readLen;
				continue;
			}
			else if(segLen > payloadLen){
				return -1;
			}
			else if( segLen > 1	){
			//	data_type = data_st->type;
			}
			segType = data_st->type;
			readLen += segLen;
			fromLen = segLen -2;
			memcpy(from_segment,data_st->data,fromLen);
		}
		else{
                        start++;
			data2_st = (AUDIT_ENSEMBLE_DATA2_ST *)start;
			segLen = data2_st->len;
                        if(segLen > rel->size){
				return -1;
			}
			segType = data2_st->type;
			readLen += (segLen +3);
			fromLen = segLen-1;

			memcpy(from_segment,data2_st->data,fromLen);

		}
		memset(to_segment,0,sizeof(to_segment));

		if(segCount == 1){ //sql query

			toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
			memcpy(rel->operation+dataLen,to_segment,toLen);
			dataLen+=toLen;
			rel->operation[dataLen]=' ';
			dataLen+=1;
			rel->operation_len = dataLen;
		}
		else if(segCount == 2){
			if(fromLen == 0){
				break;
			}
			else if(fromLen==1){
				parmNum = from_segment[0];
				loopNum = parmNum*2+3;
				count = segCount+loopNum;
				segCount++;
				start = ensemblePayload+readLen;
				continue;
			}
		}
		else if(segCount >= count){
			if(parmNum > 0){
				toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
				memcpy(rel->operation+dataLen,to_segment,toLen);
				dataLen+=toLen;
				rel->operation[dataLen]=' ';
				dataLen+=1;
				rel->operation_len= dataLen;
				parmNum--;
			}
		}
		if(loopNum > 0){
			loopNum--;
		}
		segCount++;
		start = ensemblePayload+readLen;
	}while(readLen < payloadLen);
	rel->sub_app_id = GetAppType(rel->operation);
	rel->saveflag = rel->sub_app_id+200;
}

void DataReleaseModifyOptRequest(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL *rel){
		AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
		AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;

		unsigned char *start = NULL;
		unsigned short parmNum = 0;//��������
		unsigned short loopNum = 0;//ѭ������
		int segCount = 0;//�ֶμ���
		int segLen = 0;//�ֶγ���
		int fromLen = 0;//�ֶ����ݳ���
		int toLen  = 0;
		int count;
		long readLen = 0;
		long dataLen = 0;
		char segType;
		start = ensemblePayload;

		do{
			if(*start != 0x00){
				data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;
				segLen = data_st->len;
				if(segLen == 1){
					fromLen = 0;
					readLen += segLen;
					start = ensemblePayload+readLen;
					continue;
				}
				else if(segLen > payloadLen){
					return -1;
				}
				else if( segLen > 1 ){
				//	data_type = data_st->type;
				}
				segType = data_st->type;
				readLen += segLen;
				fromLen = segLen -2;
				memcpy(from_segment,data_st->data,fromLen);
			}
			else{
				data2_st = (AUDIT_ENSEMBLE_DATA2_ST *)(start+1);
				segLen = data2_st->len;
				if(segLen > rel->size){
					return -1;
				}
				segType = data2_st->type;
				readLen += (segLen +3);
				fromLen = segLen-1;

				memcpy(from_segment,data2_st->data,fromLen);

			}
				memset(to_segment,0,sizeof(to_segment));
			if(segCount == 1){ //sql query
				toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
				memcpy(rel->operation+dataLen,to_segment,toLen);
				dataLen+=toLen;
				rel->operation[dataLen]=' ';
				dataLen+=1;
				rel->operation_len = dataLen;
			}
			else if(segCount == 2){
				if(fromLen == 0){
					break;
				}
				else if(fromLen==1){
					parmNum = from_segment[0];
					loopNum = parmNum*2+4;
					count = segCount+loopNum;
					segCount++;
					start = ensemblePayload+readLen;
					continue;
				}
			}
			else if(segCount > count){
				if(parmNum > 0){
					toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
					memcpy(rel->operation+dataLen,to_segment,toLen);
					dataLen+=toLen;
					rel->operation[dataLen]=' ';
					dataLen+=1;
					rel->operation_len= dataLen;
					parmNum--;
				}
			}
			if(loopNum > 0){
				loopNum--;
			}
			segCount++;
			start = ensemblePayload+readLen;
		}while(readLen < payloadLen);
			rel->sub_app_id = GetAppType(rel->operation);
			rel->saveflag = rel->sub_app_id+200;

}
void DataReleaseSearchOptRequestRp(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL *rel){

}
unsigned char * SearchSegmentStructRelease(unsigned char * segment,int count,long contentLen,unsigned char * segment_str,unsigned int *len){
	int i=0;
	AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;
	unsigned char * start = NULL;
	unsigned int segLen = 0;
	unsigned int readLen = 0;
	unsigned int fromLen = 0;
	unsigned int toLen = 0;
	unsigned int dataLen=0;
	char segType;
	start = segment;
	do{
		if((*start)!=0x00){
			data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;
			segLen = data_st->len;
			if(segLen == 1){
				fromLen = 0;
				readLen += segLen;
				start = segment+readLen;
				continue;
			}
			segType = data_st->type;
			fromLen = segLen -2;
			readLen += segLen;
			memcpy(from_segment,data_st->data,fromLen);
		}
		else{
			data2_st = (AUDIT_ENSEMBLE_DATA2_ST *)(start+1);
			segLen = data2_st->len;
			segType = data2_st->type;

			fromLen = segLen - 1;
			readLen += (segLen+3);
			memcpy(from_segment,data2_st->data,fromLen);
		}
		memset(to_segment,0,sizeof(to_segment));
		switch(i%10){

			case 5:
				toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
				memcpy(segment_str+dataLen,to_segment,toLen);
				dataLen += toLen;
				segment_str[dataLen]='.';
				dataLen+=1;
				break;
			case 6:
				toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
				memcpy(segment_str+dataLen,to_segment,toLen);
				dataLen += toLen;
				segment_str[dataLen]='.';
				dataLen+=1;
				break;
			case 7:
				toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
				memcpy(segment_str+dataLen,to_segment,toLen);
				dataLen += toLen;
				strncpy(&segment_str[dataLen],SEP_FLAG,strlen(SEP_FLAG));
				dataLen+=strlen(SEP_FLAG);
				break;
			default:
				break;

		}

		start = segment + readLen;
		if(i/10 == count){
			readLen < first_len;
			start = segment+first_len;
			break;
		}
		i++;

	}while(readLen < contentLen);

	*len = dataLen;
	return start;
}

unsigned char * SearchSegmentContentRelease(unsigned char * segment,unsigned int count,long contentLen,unsigned char * segment_str,unsigned int *len){
	int i=1;
	AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;
	unsigned char * start = NULL;
	unsigned int segLen = 0;
	unsigned int readLen = 0;
	unsigned int fromLen = 0;
	unsigned int toLen = 0;
	unsigned int dataLen=0;
	char type;
	void * dataType;
	char tmp[1000]={0};
	unsigned int tmpLen=0;
	start = segment;

	do{

		if((*start)!=0x00){
			data_st = (AUDIT_ENSEMBLE_DATA_ST*)start;
			segLen = data_st->len;
			if(segLen == 1){
				readLen += segLen;
				start = segment+readLen;
				i++;
				continue;
			}
			readLen += segLen;
			fromLen = segLen -2;
			memcpy(from_segment,data_st->data,fromLen);
			type = data_st->type;
		}
		else{
			data2_st = (AUDIT_ENSEMBLE_DATA2_ST*)(start+1);
			segLen = data2_st->len;
			fromLen = segLen -1;
			readLen += (segLen+3);
			memcpy(from_segment,data2_st->data,fromLen);
			type = data2_st->type;
		}
		GetSegmentValues(from_segment,fromLen,to_segment,&toLen);
		dataType = (void *)to_segment;
		memset(tmp,0,sizeof(tmp));
		switch(type){
			case 0x01:
				//�ַ���
				if(fromLen > 0){
					if(fromLen == 1 && to_segment[0] == 0x00){
						sprintf(tmp,"NULL%s",SEP_FLAG);
					}
					else{
					sprintf(tmp,"%s%s",(char *)dataType,SEP_FLAG);
					}
				}
				else{
					sprintf(tmp,"NULL%s",SEP_FLAG);
				}
				break;
			case 0x02:
				memset(to_segment,0,sizeof(to_segment));
				Change_encode_3(from_segment,fromLen,to_segment,sizeof(to_segment));
				toLen = strlen(to_segment);
				sprintf(tmp,"%s%s",(char *)dataType,SEP_FLAG);

				break;
			case 0x04:
				if(toLen > 4){

					sprintf(tmp,"%llu%s",*((unsigned long * )dataType),SEP_FLAG);
				}
				else {

					sprintf(tmp,"%lu%s",*((unsigned int * )dataType),SEP_FLAG);
				}

				break;
			case 0x08:
				sprintf(tmp,"%f%s",*((double *)dataType),SEP_FLAG);
				break;
			default:
				break;
		}

		tmpLen = strlen(tmp);

		memcpy(segment_str+(*len),tmp,tmpLen);
		*len += tmpLen;
		if(i%count==0){
			//����
			ensembleRel.line_num++;
			strncpy(segment_str+(*len),ENTER_FLAG,strlen(ENTER_FLAG));
			*len += strlen(ENTER_FLAG);
		}
		i++;
		start = segment+readLen;
	}while(readLen < contentLen);

	return start;
}
void DataReleaseSearchOptResponse(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL * rel){
	AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;

	unsigned char *start = NULL;
	unsigned short parmNum = 0;//��������
	unsigned short loopNum = 0;//ѭ������
	int segCount = 0;//�ֶμ���
	unsigned int segNum = 0;//���ֶθ���
	int segLen = 0;//�ֶγ���
	int segSegCount = 0;
	int fromLen = 0;//�ֶ����ݳ���
	int toLen  = 0;
	int count;
	long readLen = 0;
	long dataLen = 0;
	unsigned int len = 0;

	const int segments_num = 10;

	unsigned int segment_str_len=0;
	start = ensemblePayload;

	data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;
	segLen = data_st->len;
	first_len -= segLen;
	if(segLen == 3){
		segNum = start[2];
	}
	else{
		return ;
	}
	readLen += segLen;
	start += readLen;

	segCount++;

	start = SearchSegmentStructRelease(start,segNum,payloadLen-readLen,segment_str,&len);

	memcpy(&segment_str[len],ENTER_FLAG,strlen(ENTER_FLAG));
	len += strlen(ENTER_FLAG);
	memcpy(rel->response+rel->response_len,segment_str,len);
	rel->response_len += len;
	len =0;
	if(start!=NULL && (start - ensemblePayload >= payloadLen)){

		return ;
	}

	readLen = (start - ensemblePayload);
//	data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;

//	start+=data_st->len;
//	readLen += data_st->len;
	start = SearchSegmentContentRelease(start,segNum,payloadLen-readLen,segment_str,&len);

	memcpy(rel->response+rel->response_len,segment_str,len);
 	rel->response_len += len;

}
void DataReleaseSearchOptResponseRp(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL * rel){
	rel->response[0]=0x0a;
	rel->response_len = 1;
}

void DataReleaseModifyOptResponse(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL * rel){
	rel->response[0]=0x0a;
	rel->response_len = 1;
}

void DataReleaseStudioOptRquest(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL * rel){
	AUDIT_ENSEMBLE_DATA_ST * data_st=NULL;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st=NULL;

	unsigned char *start = NULL;
	unsigned short parmNum = 0;//��������
	unsigned short loopNum = 0;//ѭ������
	int segCount = 0;//�ֶμ���
	int segLen = 0;//�ֶγ���
	int fromLen = 0;//�ֶ����ݳ���
	int toLen  = 0;
	int count;
	long readLen = 0;
	long dataLen = 0;
	char segType;

	rel->operation_len = 0;
	start = ensemblePayload;

	do{
		if(*start != 0x00){
			data_st = (AUDIT_ENSEMBLE_DATA_ST *)start;
			segLen = data_st->len;

			if(segLen == 1){
				fromLen = 0;
				readLen += segLen;
				start = ensemblePayload+readLen;
				continue;
			}
			else if(segLen > payloadLen){
				return -1;
			}
			else if( segLen > 1 ){
			//	data_type = data_st->type;
			}
			segType = data_st->type;
			readLen += segLen;
			fromLen = segLen -2;
			if(segType > 2){
				start = ensemblePayload+readLen;
				continue;
			}
			memcpy(from_segment,data_st->data,fromLen);

		}
		else{
			data2_st = (AUDIT_ENSEMBLE_DATA2_ST *)(start+1);
			segLen = data2_st->len;

			if(segLen > rel->size){
				return -1;
			}
			segType = data2_st->type;
			readLen += (segLen +3);
			fromLen = segLen-1;
			if(segType > 2){
				start = ensemblePayload+readLen;
				continue;
			}
			memcpy(from_segment,data2_st->data,fromLen);

		}
		memset(to_segment,0,sizeof(to_segment));


		if(fromLen > 1){
			toLen = Change_encode(segType,from_segment,fromLen,to_segment,sizeof(to_segment));
			memcpy(rel->operation+rel->operation_len,to_segment,toLen);
			dataLen += toLen;
			rel->operation[dataLen] = ' ';
			dataLen += 1;
			rel->operation_len = dataLen;
		}

		start = ensemblePayload+readLen;
		continue;

	}while(readLen < payloadLen);

	rel->sub_app_id = GetOperationType(rel->operation);
	rel->saveflag = rel->sub_app_id;
}

void DataReleaseStudioOptResponse(unsigned char * ensemblePayload,long payloadLen,AUDIT_ENSEMBLE_REL * rel){
	DataReleaseStudioOptRquest(ensemblePayload,payloadLen,rel);
	rel->response_len = rel->operation_len;
	memcpy(rel->response,rel->operation,rel->response_len);
}

long FileRelease(AUDIT_ENSEMBLE_REL *rel,int flag){
	long toLen = 0;
	long content_len = 0;
	long readLen = 0;
	long segLen = 0;
	long fromLen = 0;
	long dataLen = 0;
	unsigned short * slen;
	int len;
	unsigned short request_type;

	char type;
	int apptype;
	char *data=NULL, *start=NULL;
	unsigned char *head=NULL;
	data = rel->data;

	void * data_ptr;
	unsigned int data_type=0;
	int response_num=0;
	AUDIT_ENSEMBLE_DATA_ST * data_st;
	AUDIT_ENSEMBLE_DATA2_ST * data2_st;




	content_len = GetEnsemblePayload(data,rel->size,ensemble_payload,&request_type,flag);

	if(content_len == 0) return -1;

	start = ensemble_payload;
	if(flag == 1){//request
		rel->request_type = request_type;
		switch(rel->request_type){
			case SQL_SEARCH_OPT:
				DataReleaseSearchOptRequest(ensemble_payload,content_len,rel);
				break;
			case SQL_SEARCH_OPT_RP:
				return -1;
				DataReleaseSearchOptRequestRp(ensemble_payload,content_len,rel);
				break;
			case SQL_MODIFY_OPT:
				DataReleaseModifyOptRequest(ensemble_payload,content_len,rel);
				break;
			case SQL_MODIFY_OPT_RP:
				return -1;
				break;
			case STUDIO_OPT:
			case STUDIO_SAVEFILE_OPT:
				DataReleaseStudioOptRquest(ensemble_payload,content_len,rel);
				break;
			default:
				return -1;
		}
	}

	if(flag == 2){//response
		switch(rel->request_type){
			case SQL_SEARCH_OPT:
				DataReleaseSearchOptResponse(ensemble_payload,content_len,rel);
				break;
			case SQL_SEARCH_OPT_RP:
				DataReleaseSearchOptResponseRp(ensemble_payload,content_len,rel);
				break;
			case SQL_MODIFY_OPT:
				DataReleaseModifyOptResponse(ensemble_payload,content_len,rel);
				break;
			case SQL_MODIFY_OPT_RP:
				return -1;
				break;
			case STUDIO_OPT:
			case STUDIO_SAVEFILE_OPT:
				DataReleaseStudioOptResponse(ensemble_payload,content_len,rel);
				break;
			default:
				return -1;
				break;
		}

	}
/*
	if(rel->request_type == 1){
		if(flag ==1 ){
				do{
				head = start;
				if(*head != 0x00){
					segLen = *head;

					if(segLen > content_len) return -1;
					readLen += segLen;
					fromLen = segLen -1;
					if(fromLen > 1 )
						memcpy(from_segment,head+1,fromLen);

				}
				else{
					slen = (unsigned short *)(head+1);
					segLen = *slen;
					if(segLen > rel->size) return -1;
					readLen += (segLen +3);
					fromLen = segLen;
					memcpy(from_segment,head+3,fromLen);
				}
				if(fromLen > 1){
					toLen = Change_encode_2(from_segment,fromLen,to_segment);
					if(toLen > 2){
						if(flag == 1){
							memcpy(rel->operation+dataLen,to_segment,toLen);
							dataLen += toLen;
							rel->operation[dataLen]='&';
							rel->operation[dataLen+1]='&';
							dataLen += 2;
						}
						else if(flag == 2){
							memcpy(rel->response+dataLen,to_segment,toLen);
							dataLen += toLen;
							rel->response[dataLen]='\n';
					//		rel->response[dataLen+1]='';
							dataLen += 1;
						}
					}


				}
				start = ensemble_payload + readLen;

			}while(readLen < content_len);
		}
		else if(flag == 2){
				do{

					head = start;
					if(*head != 0x00){

						data_st = (AUDIT_ENSEMBLE_DATA_ST *)head;
						segLen = data_st->len;
						if(segLen == 1){
							readLen += segLen;
							fromLen = 0;
							start = ensemble_payload + readLen;
							continue;
						}
						else if(segLen > 1){
							data_type = data_st->type;
						}
						else if(segLen > content_len){
							return -1;
						}
						readLen += segLen;
						fromLen = segLen -1;
						memcpy(from_segment,data_st->data,fromLen);

						toLen = Change_encode_2(from_segment,fromLen,to_segment)
					}

					i++;
					start = ensemble_payload + readLen;
				}while(readLen < content_len);
		}
	}
	else{
		do{
			head = start;
			if(*head != 0x00){
				segLen = *head;
				if(segLen > content_len) return -1;
				readLen += segLen;
				fromLen = segLen -1;
				if(fromLen > 1 )
					memcpy(from_segment,head+1,fromLen);

			}
			else{
				slen = (unsigned short *)(head+1);
				segLen = *slen;
				if(segLen > rel->size) return -1;
				readLen += (segLen +3);
				fromLen = segLen;
				memcpy(from_segment,head+3,fromLen);
			}
			if(fromLen > 1){
				toLen = Change_encode_2(from_segment,fromLen,to_segment);
				if(toLen > 2){
					if(flag == 1){
						memcpy(rel->operation+dataLen,to_segment,toLen);
						dataLen += toLen;
						rel->operation[dataLen]='&';
						rel->operation[dataLen+1]='&';
						dataLen += 2;
					}
					else if(flag == 2){
						memcpy(rel->response+dataLen,to_segment,toLen);
						dataLen += toLen;
						rel->response[dataLen]='\n';
				//		rel->response[dataLen+1]='';
						dataLen += 1;
					}
				}


			}
			start = ensemble_payload + readLen;

		}while(readLen < content_len);
	}

	rel->sub_app_id= GetAppType(rel->operation);
	//rel->saveflag = GetOperationType(rel->operation);
	if(rel->sub_app_id == -1){
		rel->saveflag = GetOperationType(rel->operation);
	}
	else{
		rel->saveflag = rel->sub_app_id+200;
	}
	return dataLen;
	*/
}



int ensemble_sql(char *sql_file_path,char *sql_path,AUDIT_ENSEMBLE_REL *rel,int flag){
	int fd;
	int len = 0;
	int rr;
//	printf("sql_file_path:%s\n",sql_file_path);
//	printf("flag = %d\n",flag);
	if(rel->operation_len == 0){
		return -1;
	}

	if(flag == 1)
		fd = open(sql_file_path,O_RDWR | O_CREAT, 0666);
	if(flag == 2)
		fd = open(sql_file_path,O_RDWR|O_APPEND, 0666);
	if(fd < 0) {
		printf("fd < 2; %d\n",fd);
		perror("open");
		return -1;
	}
	memset(from_segment,0,sizeof(from_segment));
	if(flag == 1 ){
		sprintf(from_segment,MONGO_ENSEMBLE_REQUEST_VALUES,MONGO_ENSEMBLE_REQUEST_PARAMS);
		len = strlen(from_segment);
		memcpy(&from_segment[len],rel->operation,rel->operation_len);
		len += rel->operation_len;
		from_segment[len] = '\n';
		len += 1;
	}
	if(flag == 2 ){
		sprintf(from_segment,MONGO_ENSEMBLE_RESPONSE_VALUES,MONGO_ENSEMBLE_RESPONSE_PARAMS);
		len = strlen(from_segment);
		memcpy(&from_segment[len],rel->response,rel->response_len);
		len += rel->response_len;
		from_segment[len] = '\n';
		len += 1;
	}
	rr = AuditWrite(fd,from_segment,len);
	close(fd);
//	rename(sql_file_path,sql_path);
//	printf("written:%d\n",rr);
	return rr;
}

void ensemble_packet_parse(char * request_path,char *response_path,char *sql_file_path,char * sql_path,AUDIT_ENSEMBLE_REL *rel,int flag){
	char request_cmd[500]={0};
	char response_cmd[500]={0};
	int isMedTrak;

	memset(request_cmd_debug,0,500);
	memset(response_cmd_debug,0,500);

//	long rel_flag=0;
	sprintf(request_cmd,"mv %s %s",request_path,SQL_BACKUP);
	sprintf(response_cmd,"mv %s %s",response_path,SQL_BACKUP);

	sprintf(request_cmd_debug,"mv %s %s",request_path,SQL_DEBUG);
	sprintf(response_cmd_debug,"mv %s %s",response_path,SQL_DEBUG);


	if(FileInit(request_path,rel) == -1){
#if RUN_FLAG
		system(response_cmd);
		system(request_cmd);
#else
		unlink(response_path);
		unlink(request_path);
#endif
		return ;
	}

	rel->request_time = GetFileTime(request_path);
	rel->response_time = GetFileTime(response_path);
	if(rel->request_time == 0 || rel->response_time == 0){
		rel->interval_time=0;
	}
	else{
		rel->interval_time = rel->response_time - rel->request_time;
	}

		// test if med or others
		isMedTrak = medtrakTest(rel->data,rel->size);
	//	printf("isMedTrak : %d\n",isMedTrak);
		if(isMedTrak){
				rel->saveflag = 300;
				if(medtrakParser(rel->data, rel->size,rel->operation, &rel->operation_len) == -1){
					#if RUN_FLAG
							system(response_cmd);
							system(request_cmd);
					#else
							unlink(response_path);
							unlink(request_path);
					#endif

					return ;
				}
				if(ensemble_sql(sql_file_path,sql_path,rel,1) == -1){
					#if RUN_FLAG
							system(response_cmd);
							system(request_cmd);
					#else
							unlink(response_path);
							unlink(request_path);
					#endif

					return ;
				}

				if(flag == 1){
					if(FileInit(response_path,rel) == -1){
#if RUN_FLAG
						system(response_cmd);
						system(request_cmd);
#else
						unlink(response_path);
						unlink(request_path);
#endif

						rename(sql_file_path,sql_path);
						return ;
					}
					if(medtrakParser(rel->data, rel->size,rel->response, &rel->response_len)==-1){
#if RUN_FLAG
						system(response_cmd);
						system(request_cmd);
#else
						unlink(response_path);
						unlink(request_path);
#endif

						rename(sql_file_path,sql_path);
						return ;
					}
					if(ensemble_sql(sql_file_path,sql_path,rel,2) == -1){
						#if RUN_FLAG
								system(response_cmd);
								system(request_cmd);
						#else
								unlink(response_path);
								unlink(request_path);
						#endif

								rename(sql_file_path,sql_path);
						return ;
					}

				}
		}
		else if(isMedTrak == 0){
						if( FileRelease(rel,1) == -1 ){
#if RUN_FLAG
							system(response_cmd);
							system(request_cmd);
#else
							unlink(response_path);
							unlink(request_path);
#endif

							return ;
						}
						if(ensemble_sql(sql_file_path,sql_path,rel,1) == -1){
	#if RUN_FLAG
									system(response_cmd);
									system(request_cmd);
	#else
									unlink(response_path);
									unlink(request_path);
	#endif

							return ;
						}

				if(flag == 1){
					if(FileInit(response_path,rel) == -1){
#if RUN_FLAG
								system(response_cmd);
								system(request_cmd);
#else
								unlink(response_path);
								unlink(request_path);
#endif

						rename(sql_file_path,sql_path);
						return ;
					}




					if(FileRelease(rel,2)==-1){
#if RUN_FLAG
								system(response_cmd);
								system(request_cmd);
#else
								unlink(response_path);
								unlink(request_path);
#endif

						rename(sql_file_path,sql_path);
						return ;
					}
					if(ensemble_sql(sql_file_path,sql_path,rel,2) == -1){
#if RUN_FLAG
								system(response_cmd);
								system(request_cmd);
#else
								unlink(response_path);
								unlink(request_path);
#endif

						rename(sql_file_path,sql_path);
						return ;
					}
				}
		}
		else{
			#if RUN_FLAG
			system(response_cmd);
			system(request_cmd);
#else
			unlink(response_path);
			unlink(request_path);
#endif
		}


	rename(sql_file_path,sql_path);
#if RUN_FLAG
			system(response_cmd);
			system(request_cmd);
#else
			unlink(response_path);
			unlink(request_path);
#endif

}





int main(int argc ,char ** argv){
//	if(argc ==2)
//		NC_daemon_audit();
//	if(argc == 3)
//		runFlag = atoi(argv[2]);



	DIR *ensembleDir;
	struct dirent *cspDp;

	char fullFileName[CSP_PATH_LEN]={0};
	char fullFileName1[CSP_PATH_LEN] = {0};
	char fullFileName2[CSP_PATH_LEN]={0};
	char fullFileName3[CSP_PATH_LEN]={0};
	char fullFileName4[CSP_PATH_LEN]={0};
	char fname[CSP_PATH_LEN]={0};
	char fpath[CSP_PATH_LEN]={0};
	char fullPath[CSP_PATH_LEN]={0};
	char strdname[CSP_FILENAME_LEN]={0};
	char yyyymm_time[CSP_TIMES_LEN]={0};
	char day_time[CSP_TIMES_LEN]={0};
	struct stat fbuf;
	int pathLen=0;
	unsigned long dname;
	int ret;



	char dir[2]={0};
	char *pos;
	int flag=0;
	unsigned int policyNum,j;
	unsigned long i =0;
	AUDIT_ENSEMBLE_HEAD *ensembleHead;

	CACHE_POLICY_CONF * policy=NULL;
	int  httpResponseFd;
	int  ismatch;
	file_request = fullFileName1;
	file_response = fullFileName2;


	policy = (CACHE_POLICY_CONF*)get_audit_cache_policy_shm();
	if(!policy){
		return 0;
	}

	sprintf(fullFileName,"%s",argv[1]);
	getfilename(fullFileName,fname,fpath,dir,strlen(fullFileName));
//	printf("fname:%s\nfpath:%s\n",fname,fpath);
//	memset(csp,0,sizeof(CSP_FILE_INFO));
//	memset(dirpath,0,sizeof(dirpath));
//	sprintf(dirpath,"%s",argv[1]);


	signal(SIGINT,SigFun);
	signal(SIGTERM,SigFun);
    signal(SIGSEGV,SigFun);

/*
	conn = redisConnect(REDISSERVERHOST,REDISSERVERPORT);

		if(conn->err){
			redisFree(conn);
			conn=NULL;
			conn = redisConnect(REDISSERVERHOST,REDISSERVERPORT);
			if(conn->err){
				redisFree(conn);
				conn = NULL;
				printf("can not connect  to redis server.\n");
				return -1;
			}
		}
		*/
		memset(datamonth,0,sizeof(datamonth));
		get_audit_time_3(datamonth);


		if(strcmp(fname,".") == 0 || strcmp(fname,"..") == 0){
			return 0;
		}
//		if(strncmp(fname,"22",2)!=0){
//			return 0;
//		}
		if(!strstr(fname,"_request")){
			memset(fullFileName2,0,sizeof(fullFileName2));
			sprintf(fullFileName2,"%s",fullFileName);
			pos = strstr(fullFileName2,"_response");
			*pos = '\0';
			memset(fullFileName1,0,sizeof(fullFileName1));
			sprintf(fullFileName1,"%s_request",fullFileName2);
			*pos = '_';

			memset(cmd1,0,sizeof(cmd1));
			sprintf(cmd1,"rm -rf %s",fullFileName1);
			memset(cmd2,0,sizeof(cmd2));
			sprintf(cmd2,"rm -rf %s",fullFileName2);

			int exist;
			/*
			if((exist=access(fullFileName1,0))!=0){
				if(IsOld(fullFileName2,120)==1){
					system(cmd2);
				}
			}
			*/
			return 0;
		}
/*
		memset(csp,0,sizeof(CSP_FILE_INFO));
		csp->conn = conn;
		*/
		memset(fullFileName1,0,sizeof(fullFileName1));
		sprintf(fullFileName1,"%s",fullFileName);
		memset(cmd1,0,sizeof(cmd1));
		sprintf(cmd1,"rm -rf %s",fullFileName1);
		pos = strstr(fullFileName1,"_request");
		*pos = '\0';
		memset(fullFileName2,0,sizeof(fullFileName2));
		sprintf(fullFileName2,"%s_response",fullFileName1);

		memset(cmd2,0,sizeof(cmd2));
		sprintf(cmd2,"rm -rf %s",fullFileName2);

		*pos = '_';

		int exist;
		if((exist=access(fullFileName2,0))!=0){
			flag = 0;
		}
		else{
			flag = 1;
		}

		memset(&ensembleRel,0,sizeof(AUDIT_ENSEMBLE_REL));
		GetValues(&ensembleRel,fname);
		memset(fullFileName3,0,sizeof(fullFileName3));
		memset(fullFileName4,0,sizeof(fullFileName4));

		sprintf(fullFileName3,"/data/audit/sql_tmp/Sql_studio_%s_%s",ensembleRel.times,dir);

		sprintf(fullFileName4,"/data/audit/sql/Sql_studio_%s_%s",ensembleRel.times,dir);
		//policy match
		if(policy_match_ensemble(&ensembleRel,policy) == 0){
			unlink(fullFileName2);
			unlink(fullFileName1);
			return 0;
		}


		//process files


		ensemble_packet_parse(fullFileName1,fullFileName2,fullFileName3,fullFileName4,&ensembleRel,flag);

		return 0;

}



