#include "csp_policy.h"
#include "csp_redis.h"
#include "csp_deal.h"
#include "audit_ensemble.h"
int CspMapMatch(unsigned key,unsigned char * map) {
    if(bit_test(key,map)) {
        return 1;
    }
    return 0;
}

int  csp_audit_policy_match(CSP_FILE_INFO *csp, CSP_AUDIT_POLICY *policy) {
	unsigned int time;
	unsigned char urlId[CSP_ID_LEN]={0};
	unsigned char userId[CSP_ID_LEN]={0};
	unsigned int url_id,user_id;
	int i =0;
	int isTime ,isUrl,isip,is_appid;

	if(policy->valid_flag == 0) return -1;

	/* ƥ��time */
	if(policy->obj_time_flag == 1){
		time = atoi(csp->cspHead.policytime);
		isTime = CspMapMatch(time, policy->time);
	} else{
		isTime = 1;
	}

	if(isTime == 0) return 0;

	/* ƥ��ip */
	if(policy->obj_user_flag == 1) {
		u_int32_t ip_map_addr, iip0, iip1, iip2, iip3;
		sscanf(csp->cspHead.userip, "%d.%d.%d.%d", &iip3, &iip2, &iip1, &iip0);
		ip_map_addr =iip2*256*256+ iip1*256 + iip0;
		isip = CspMapMatch(ip_map_addr, policy->ip);
		if(isip == 0) {
			return 0;
		}
	}

	/* ƥ��app_id */
	is_appid = CspMapMatch(csp->type, policy->app_id);
	if(is_appid == 0) {
		return 0;
	}
	return 1;
}

int policy_match(CSP_FILE_INFO *csp, CACHE_POLICY_CONF *policy_conf){
	int i;
	int flag;
	for(i=0;i<10;i++){
		flag = csp_audit_policy_match(csp,&policy_conf->csp_audit_policy[i]);
		if(flag == 1){
			return 1;
		}
	}
	return 0;
}
#if 1
int  ensemble_audit_policy_match(AUDIT_ENSEMBLE_REL*rel, CSP_AUDIT_POLICY *policy) {
	unsigned int time;
	unsigned char urlId[CSP_ID_LEN]={0};
	unsigned char userId[CSP_ID_LEN]={0};
	unsigned int url_id,user_id;
	int i =0;
	int isTime=0 ,isUrl=0,isip=0,is_appid=0;

	if(policy->valid_flag == 0) return -1;

	/* ƥ��time */

	time = atoi(rel->policytime);
	isTime = CspMapMatch(time, policy->time);


	if(isTime == 0) return 0;

	/* ƥ��ip */
	u_int32_t ip_map_addr, iip0, iip1, iip2, iip3;
	sscanf(rel->userip, "%d.%d.%d.%d", &iip3, &iip2, &iip1, &iip0);
	ip_map_addr =iip2*256*256+ iip1*256 + iip0;
	isip = CspMapMatch(ip_map_addr, policy->ip);
	if(isip == 0) {
		return 0;
	}
	

	/* ƥ��app_id */
	is_appid = CspMapMatch(rel->type, policy->app_id);
	if(is_appid == 0) {
		return 0;
	}
	return 1;
}



int policy_match_ensemble(AUDIT_ENSEMBLE_REL*rel, CACHE_POLICY_CONF *policy_conf){
	int i;
	int flag;
	for(i=0;i<10;i++){
		flag = ensemble_audit_policy_match(rel,&policy_conf->csp_audit_policy[i]);
		if(flag == 1){
			return 1;
		}
	}
	return 0;
}


#endif

