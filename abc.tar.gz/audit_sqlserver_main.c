/* gcc audit_sqlserver_main.c -o newTest -g -Wall */

#include<ctype.h>
#include<stdio.h>
#include<time.h>
#include<string.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>
#include<ctype.h>
#include<sys/types.h>
#include<dirent.h>
#include<time.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>

#include "csp_deal.h"
#include "csp_policy.h"
//#include"audit_database_sql.h"

#include "./TDS_parser.c"
#include "/usr/src/inp/audit_new/redis_new_api.h" /* 2015-11-16,����snmp */

#define DEBUG_OPEN 0
#if DEBUG_OPEN
#define DEBUG_LOG(s) fprintf(stderr, "DEBUG : <%s> : %d : %s\n", __FILE__, __LINE__, (s))
#else
#define DEBUG_LOG(s)
#endif
#define PRINT_ERR_MSG(s) fprintf(stderr, "ERROR : <%s> : %d : %s\n", __FILE__, __LINE__, (s))


#define ITEM_MAX 1 /* �����ݿ���ļ��������������ֵ */

typedef struct {
    unsigned short sport;
    unsigned short dport;
    unsigned short app_id;
    unsigned short user_id;
    unsigned int sip;
    unsigned int dip;
    char smac[64];
    char dmac[64];
    int reqsize;
    int respsize;
    unsigned int seq;
    unsigned long time;
    char *data;
    char * request;
    char * response;
    int processId;
    unsigned long interval_time;/* �������Ӧ���ʱ��������λ��s��2015-11-09�����ֶ� */
}TITLE_CONTNET_TYPE;

/* �����ļ����ĵ�һ���ֶε�ֵ������Ӧ�� */
#define SQLSERVER_TMP_ID_PREFIX "10_"
#define CACHE_STUDIO_TMP_ID_PREFIX "20_"
#define CACHE_HIS_PORTAL_TMP_ID_PREFIX "100_"

#define SQLSERVER_TMP_ID 10
#define CACHE_STUDIO_TMP_ID 20
#define CACHE_HIS_PORTAL_TMP_ID 100

static char cur_flie_name[256] = {0};/* ��ǰ�����ݿ���ļ�����ȫ·���� */
static char cur_dstflie_name[256] = {0};
static int item_cnt = 0;/* ÿ�������ݿ���ļ������������ֵ */
static int fname_suffix_n = 0;
static char resultBuf[1024*1024*5], tmpBuf[10*1024*1024] = {0};

/* ɾ��'str'��ͷ��ĩβ�����Ŀհ��ַ�. ԭַ����
   ���ؽ�����ĳ��� */
static int trim(char *str) {
    char *start = str,
         *end = str+strlen(str)-1;
    int num;

    if (NULL==str || '\0'==str[0]) return 0;

    while (start<=end && isspace(*start)) start++;
    while (end > start && isspace(*end)) end--;

    if (start > end) {
        str[0] = '\0';
        num = 0;
    } else {
        if (start != str) {
            memmove(str, start, end-start+1);
        }
        str[end-start+1] = '\0';
        num = end-start+1;
    }

    return num;
}

static long getFileTime(char *filename) {
    struct stat buf;
    if(stat(filename, &buf)<0) {
        PRINT_ERR_MSG("get file's stat failed");
        return -1;
    }
    return (long)buf.st_mtime;
}

/* ����'slen'�Ĵ�'s'��, 1���������Ķ�����ɴ�ӡ�ַ����һ���ո�, ��������浽'dst'��
 * ����'dst'�ַ����ĳ��� */
static int unprintable_to_space(char *src, int slen, char *dst, int dst_maxsize) {
    int i=0, j=0;

    memset(dst, 0, dst_maxsize);
    while (i<slen && j<(dst_maxsize-1)) {
        if ('\0' == src[i]) {
            i++;
        } else if (isprint(src[i]) && !isspace(src[i])) {
            dst[j++] = src[i++];
        } else if (isspace(src[i])) {
            dst[j++] = src[i++];
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        } else {
            dst[j++] = ' ';
            while(i<slen && !(isprint(src[i])&& !isspace(src[i]))) i++;
        }
    }
    dst[j] = '\0';

    return j;
}

/* ���ļ�'fname'д��'len'�ֽڵ�'content'.���ļ��������򴴽���
 * ���سɹ�д����ֽ���, ʧ�ܷ���-1 */
static int write_file(char *fname, char *content, int len) {
    int fd, nwr;

    if (NULL==fname || NULL==content || len<0) { PRINT_ERR_MSG("NULL==fname || NULL==content || len<=0"); return -1; }
    if (0 == len) { return 0; }
    fd = open(fname, O_CREAT|O_RDWR|O_APPEND, 0666);
    if (fd < 0) {
        PRINT_ERR_MSG("open file failed");
        return -1;
    }

    if ((nwr = write(fd, content, len)) < 0) {
        PRINT_ERR_MSG("write file failed");
        close(fd);
        return -1;
    }
    close(fd);

    return nwr;
}

/* ��ȡ'ip'�ĵ����ʽ, 'ipstr'������, 'len'��'ipstr'�Ĵ�С
   'ip'�������� */
static int getStrIp(u_int32_t ip, char *ipstr, size_t len) {
    struct in_addr addr;
    addr.s_addr = ip;
    inet_ntop(AF_INET, &addr, ipstr, len);
    return 0;
}

/* �ѻ����request/response���ݣ��͸�������Ϣ�����浽�����ݿ���ļ��С�
   �ɹ�����0, ʧ�ܷ���-1��
   ע�� -
   <1>response��request��2���ļ�����1���ַ�������ʶ������͵ģ�����д��
      ���ݿ�������
   <2>�ļ�����ʽ='SQLSERVER_PREFIX'����audit_time�����̵߳İ�������thread_id��
   <3>�����ݿ�Ļ����ļ��ĸ�ʽ -
      rowkey=[time1]|colfam1:table=[time2]|colfam1:app_id=[app_id]|colfam1:saveflag=[0/1]|colfam1:src_ip=x.x.x.x|colfam1:src_mac=[x:x:x:x:x:x]|colfam1:src_port=[src_port]|colfam1:dst_ip=x.x.x.x|colfam1:dst_mac=x:x:x:x:x:x|colfam1:dst_port=[dst_port]|colfam1:user_id=[user_id]|colfam1:operation_command=[request]|colfam\n
      \nrowkey=[time1]|colfam1:table=[time2]|colfam1:app_id=[app_id]|colfam1:saveflag=[0/1]|colfam1:src_ip=x.x.x.x|colfam1:src_mac=[x:x:x:x:x:x]|colfam1:src_port=[src_port]|colfam1:dst_ip=x.x.x.x|colfam1:dst_mac=x:x:x:x:x:x|colfam1:dst_port=[dst_port]|colfam1:user_id=[user_id]|colfam1:response_content=[response]|colfam\n
      ÿ2��rowkey֮�䣬��1�����С�
*/
#define SQLSERVER_SQL_TMP_DIR "/data/audit/sql_tmp/"
#define SQLSERVER_SQL_DIR "/data/audit/sql/"
#define SQLSERVER_PREFIX "Sql_sqlserver_"

const char days1[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

static struct tm *dhcc_localtime1(time_t time, long time_zone, struct tm *tm_time) {
    unsigned  int pass_4year, hour_per_year;

    time = time + time_zone*60*60;
    if(time < 0) {
       time = 0;
    }

    tm_time->tm_sec=(int)(time % 60);
    time /= 60;
    tm_time->tm_min=(int)(time % 60);
    time /= 60;
    pass_4year=((unsigned int)time / (1461 * 24));
    tm_time->tm_year=(pass_4year << 2) + 70;
    time %= 1461 * 24;

    for (;;)
    {
        hour_per_year = 365 * 24;

        if ((tm_time->tm_year & 3) == 0)
        {
            hour_per_year += 24;
        }
        if (time < hour_per_year)
        {
            break;
        }
        tm_time->tm_year++;
        time -= hour_per_year;
    }

    tm_time->tm_hour=(int)(time % 24);
    time /= 24;
    time++;
    if ((tm_time->tm_year & 3) == 0)
    {
        if (time > 60)
        {
            time--;
        }
        else
        {
            if (time == 60)
            {
                tm_time->tm_mon = 1;
                tm_time->tm_mday = 29;
            }
        }
    }
    for (tm_time->tm_mon = 0; days1[tm_time->tm_mon] < time; tm_time->tm_mon++)
    {
          time -= days1[tm_time->tm_mon];
    }
    tm_time->tm_mday = (int)(time);

        return tm_time;
}

static void log_time1(struct tm *t_time)
{
    if((t_time->tm_hour) >=24) {
        t_time->tm_mday += 1;
        t_time->tm_hour -= 24;
    }

    switch(t_time->tm_mon) {
        case 0 ... 10:
            if(t_time->tm_mday > days1[t_time->tm_mon]) {
                t_time->tm_mon += 1;
                t_time->tm_mday = 1;
            }

        case 11:
            {
                if(t_time->tm_mday > days1[t_time->tm_mon]) {
                    t_time->tm_mon = (t_time->tm_mon) - 11;
                    t_time->tm_mday = (t_time->tm_mday) - (days1[t_time->tm_mon]);
                    t_time->tm_year += 1;
                }
            }

        default:
            break;
    }
}

static void getTime3(char *times, size_t maxsize){
    time_t now;
    struct tm  timenow;

    time(&now);
    dhcc_localtime1(now, 8, &timenow);
    log_time1(&timenow);
    snprintf(times, maxsize, "%04d_%02d", timenow.tm_year+1900, timenow.tm_mon+1);
}

/* �ļ����ϴ��޸�ʱ�䵽��ǰʱ�䣬����'secs'�룬�򷵻�1�����򷵻�0 */
static int isOld(char *filePath, int secs) {
    time_t t;
    int retval;
    struct stat ft;

    retval = time(&t);
    if (retval < 0) return 1;

    retval = stat(filePath, &ft);
    if (retval < 0) return 1;

    if ((long)t - (long)(ft.st_mtime) > secs) return 1;
    return 0;
}


static int getPolicyTime(unsigned long time){
	int  time_sec=0;
	int  time_min=0;
	const int time_zone = 8*60;
	const int week_min = 7*24*60;
	//const int day_min = 24*60;
	const int monday_start = 4*24*60;
	int res;
	time_sec = time/1000000;
	time_min = time_sec/60;

	res = (time_min + time_zone - monday_start)%week_min;

	return res;
}

static CSP_FILE_INFO zinfo;
static int audit_sqlserver(TITLE_CONTNET_TYPE *data) {
    char buffer[1024]={0}, time_for_table_item[32]={0}, lrStr[16],
         srcipstr[32]={0}, dstipstr[32]={0}, srcmac[64]={0}, dstmac[64]={0};
    int pkt_type;
    int line_num;  /* 2015-11-17: select��䷵�ص����� */

    /* ��������sqlserver����� */
    if (data->app_id != SQLSERVER_TMP_ID) {
        fprintf(stderr, "ERROR : <%s> : %d : Wrong function.(app_id=%d)\n", __FILE__, __LINE__, data->app_id);
        return 0;
    }

    /* ��������Ҫ��requestȷ��������request�������� */
    if (data->reqsize <= 0) {
        fprintf(stderr, "ERROR : <%s> : %d : data->reqsize <= 0\n", __FILE__, __LINE__);
        return 0;
    }

    /* ȡ"2015-08"��ʽʱ�� */
    getTime3(time_for_table_item, sizeof(time_for_table_item)-1);

    /* ���������ݿ�Ļ����ļ�����ȫ·�� */
    if (0==item_cnt || '\0'==cur_flie_name[0] || '\0'==cur_dstflie_name[0]) {
        item_cnt = 0;
        sprintf(cur_flie_name,
            SQLSERVER_SQL_TMP_DIR
            SQLSERVER_PREFIX
            "%s_%d_%d", time_for_table_item, fname_suffix_n, data->processId);
        sprintf(cur_dstflie_name,
            SQLSERVER_SQL_DIR
            SQLSERVER_PREFIX
            "%s_%d_%d", time_for_table_item, fname_suffix_n, data->processId);
        fname_suffix_n++;
    }

    /* ���� */
    pkt_type = TDS_parser(data->request, data->reqsize, resultBuf, sizeof(resultBuf), &line_num);

    if (pkt_type != select_flag
        && pkt_type != update_flag
        && pkt_type != delete_flag
        && pkt_type != insert_flag
        && pkt_type != create_flag
        && pkt_type != drop_flag
        && pkt_type != other_sql_flag
        && pkt_type != alter_flag
        && pkt_type != use_flag
        && pkt_type != set_flag
        && pkt_type != grant_flag
        && pkt_type != deny_flag
        && pkt_type != revoke_flag
        && pkt_type != commit_flag
        && pkt_type != rollback_flag
        && pkt_type != other_sql_state_flag ) {
#if DEBUG_OPEN
        fprintf(stderr, "DEBUG : <%s> : %d : Not sql (pkt_type=%d)", __FILE__, __LINE__,pkt_type);
#endif
        return 0;
    }
    unprintable_to_space(data->request+8, data->reqsize-8, tmpBuf, sizeof(tmpBuf)-1);
    trim(tmpBuf);
    if ((strlen(tmpBuf)+strlen(resultBuf)) < 10) {
#if DEBUG_OPEN
        fprintf(stderr, "DEBUG : <%s> : %d : Too little data : resultBuf=%s, tmpBuf=%s, pkt_type=%d\n",
        __FILE__, __LINE__, resultBuf, tmpBuf, pkt_type);
#endif
        return 0;
    }

    /* ȷ��Ҫ������ļ����ٴ���ip/mac */
    /* ���ʽip (cli��Ӧ �������src    ser ��Ӧdes)*/
    getStrIp(ntohl(data->sip), srcipstr, 32);
    getStrIp(ntohl(data->dip), dstipstr, 32);

    /* mac */
    sprintf(srcmac, "%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",
                    data->smac[0], data->smac[1], data->smac[2], data->smac[3], data->smac[4], data->smac[5],
                    data->smac[6], data->smac[7], data->smac[8], data->smac[9], data->smac[10], data->smac[11]);
    sprintf(dstmac, "%c%c-%c%c-%c%c-%c%c-%c%c-%c%c",
                    data->dmac[0], data->dmac[1], data->dmac[2], data->dmac[3], data->dmac[4], data->dmac[5],
                    data->dmac[6], data->dmac[7], data->dmac[8], data->dmac[9], data->dmac[10], data->dmac[11]);

    //2015-11-16, ����snmp
    char tmpSrcmac[64]={0}, tmpDstmac[64]={0};
    get_mac_str(srcipstr, tmpSrcmac);
    get_mac_str(dstipstr, tmpDstmac);
    if (tmpSrcmac[0] != '\0' && tmpDstmac[0] != '\0') {
        strcpy(srcmac, tmpSrcmac);
        strcpy(dstmac, tmpDstmac);
    }


    if (select_flag == pkt_type) {
		strcpy(lrStr, ";:r\n");
    } else {
		strcpy(lrStr, "\n");
    }

    /* ����ƥ�� */
	CACHE_POLICY_CONF *policy = (CACHE_POLICY_CONF*)get_audit_cache_policy_shm();
	if(NULL == policy){
        PRINT_ERR_MSG("Fails to get CACHE_POLICY_CONF");
		return 0;
	}
    sprintf(zinfo.cspHead.policytime, "%d", getPolicyTime(data->time));
    strcpy(zinfo.cspHead.userip, srcipstr);
    zinfo.type = pkt_type;
    if (0 == policy_match(&zinfo, policy)) {
        return 0;
    }

    /* request����
       ע - 'operation_command'��ƫ����������ƫ�����ݺ��\n */
    sprintf(buffer,
        "rowkey=%lu"
        "|colfam1:table=%s"
        "|colfam1:app_id=%d"
        "|colfam1:src_ip=%s"
        "|colfam1:src_mac=%s"
        "|colfam1:src_port=%hu"
        "|colfam1:dst_ip=%s"
        "|colfam1:dst_mac=%s"
        "|colfam1:dst_port=%hu"
        "|colfam1:user_id=%hu"
        "|colfam1:charset=%s"
        "|colfam1:interval_time=%lu" /* 2015-11-09�����ֶ� */
        "|colfam1:operation_command=%d"
        "|colfam\n",
        data->time, time_for_table_item, pkt_type, srcipstr, srcmac, data->sport,
        dstipstr, dstmac, data->dport, data->user_id, "UTF-8", data->interval_time, strlen(resultBuf));
    DEBUG_LOG(buffer);

    write_file(cur_flie_name, buffer, strlen(buffer));
    write_file(cur_flie_name, resultBuf, strlen(resultBuf));
    write_file(cur_flie_name, "\n", 1);

    /*====================================================================*/
    /* response���� */

    if (data->respsize > 0) {
        memset(resultBuf, 0, sizeof(resultBuf));
        TDS_parser(data->response, data->respsize, resultBuf, sizeof(resultBuf), &line_num);

        /* ȥ�����ķǲ������ַ�����ַ��� */
        unprintable_to_space(data->response+8, data->respsize-8, tmpBuf, sizeof(tmpBuf)-1);
        trim(tmpBuf);
    } else {
        resultBuf[0] = '\0';
        tmpBuf[0] = '\0';
    }

    /* ע - 'response_content'��ƫ����������ƫ�����ݺ��\n */
    sprintf(buffer,
        "rowkey=%lu"
        "|colfam1:line_num=%d"
        "|colfam1:response_content=%d"
        "|colfam\n",
        data->time, line_num, (int)(strlen(resultBuf)+strlen(lrStr)+strlen(tmpBuf)));
    DEBUG_LOG(buffer);

    write_file(cur_flie_name, buffer, strlen(buffer));
    write_file(cur_flie_name, resultBuf, strlen(resultBuf));
    write_file(cur_flie_name, lrStr, strlen(lrStr));
    write_file(cur_flie_name, tmpBuf, strlen(tmpBuf));
    write_file(cur_flie_name, "\n", 1);

    /* �ƶ������ݿ���ļ� */
    item_cnt++;
    if (item_cnt >= ITEM_MAX || isOld(cur_flie_name, 60)) {
        DEBUG_LOG("Move file from sql_tmp to sql");
        rename(cur_flie_name, cur_dstflie_name);
        unlink(cur_flie_name);
        item_cnt = 0;
        cur_flie_name[0] = '\0';
        cur_dstflie_name[0] = '\0';
    }

    return 0;
}

/* ======================================================================================================== */
#define CMDLEN  10485760
static char requestFileName[1024];
static char responseFileName[1024];
static char fileContentRequest[CMDLEN];
static char fileContentResponse[CMDLEN];

/* ʹ��ǰ����תΪ��̨����
static int NC_daemon_audit(void) {
    pid_t pid;
    int ret;
    if ((pid = fork()) < 0) {
        return -1;
    } else if (pid != 0) {
        exit(0);
    }

    if((ret=setsid()) < 0) {
        PRINT_ERR_MSG("unable to setsid.");
        exit(0);
    }
     setpgrp();
     return 0;
} */

static int getValues(TITLE_CONTNET_TYPE *tContent, char *filename){
    int ret;
    /* ���� - 10_2887326051_000fe25c06a0_64234_168466306_80c16ef872cd_1433_0_5_1440916826045169_request */
    sscanf(filename, "%hu_%u_%[^_]_%hu_%u_%[^_]_%hu_%u_%hu_%lu_request",
                    &tContent->app_id, &tContent->sip, tContent->smac, &tContent->sport,
                    &tContent->dip, tContent->dmac, &tContent->dport, &tContent->seq,
                    &tContent->user_id, &tContent->time);
    if (ret != 10) {
        fprintf(stderr, "ERROR : <%s> : %d : parse filename failed(%s)\n", __FILE__, __LINE__, filename);
        return -1;
    }
    return 0;
}

static int getValuesFromFullName(TITLE_CONTNET_TYPE *tContent, char *filename){
    int ret;
    /* ���� - /dev/shm/1/10_2887326051_000fe25c06a0_64234_168466306_80c16ef872cd_1433_0_5_1440916826045169_request */
    ret = sscanf(filename, "/dev/shm/%d/%hu_%u_%[^_]_%hu_%u_%[^_]_%hu_%u_%hu_%lu_request",
                    &tContent->processId, &tContent->app_id, &tContent->sip, tContent->smac, &tContent->sport,
                    &tContent->dip, tContent->dmac, &tContent->dport, &tContent->seq,
                    &tContent->user_id, &tContent->time);
    if (ret != 11) {
        fprintf(stderr, "ERROR : <%s> : %d : parse filename failed(%s)\n", __FILE__, __LINE__, filename);
        return -1;
    }
    return 0;
}

static unsigned int fileInit(char *filename, char *fileContent, int maxsize){
    FILE * fp = NULL;
    long fsize =0;
    long readsize = 0;
    struct stat buf;

    memset(fileContent,0,CMDLEN*sizeof(char));
    if(stat(filename, &buf)<0) {
        PRINT_ERR_MSG("get file's stat failed");
        return -1;
    }
    fsize = buf.st_size;
    if(fsize <= 0){
        return 0;
    } else if(fsize > CMDLEN*sizeof(char)){
        fprintf(stderr, "<%s>:%d:Big file.(filename=%s, fsize=%ld)\n", __FILE__, __LINE__,filename, fsize);
        fsize = CMDLEN*sizeof(char) - 1;
    }

    fp = fopen(filename,"r+");
    if(!fp){
        fprintf(stderr, "<%s>:%d:Open file(%s) failed. \n", __FILE__, __LINE__,filename);
        return 0;
    }

    readsize = fread(fileContent, 1, fsize, fp);
    if(readsize != fsize){
        fprintf(stderr, "<%s>:%d:fread file(%s) error.\n", __FILE__, __LINE__,filename);
        fclose(fp);
        return 0;
    }

    fclose(fp);
    return fsize;
}


#if 0
#define REQUEST_RESPONSE_CACHE_PATH "/dev/shm/"
static char helpStr[] = "\n\n*************************************************************\n"
                 "USAGE:\n"
                 "audit_sqlserver_process <id> <daemonFlag>\n"
                 "<id>[0...9]:       Specify which dir to read.\n"
                 "<daemonFlag>[0/1]: Set daemon mode, 1 for YES, 0 for NO\n"
                 "*************************************************************\n\n";
int main(int argc,char **argv){
    DIR *srcDir;
    struct dirent *srcDp;
    int id, flag, exist;
    char *pos, dirName[1024], fileBaseName1[1024], fileBaseName2[1024];
    TITLE_CONTNET_TYPE tContent;

    if (argc != 3) {
        perror(helpStr);
        exit(0);
    } else {
        id = atoi(argv[1]);
        flag = atoi(argv[2]);

        if (id<0 || id >9 || (flag!=1 && flag!=0)) {
            perror(helpStr);
            exit(0);
        }
    }

    /* ��̨���� */
    if (1 == flag) NC_daemon_audit();

    sprintf(dirName, REQUEST_RESPONSE_CACHE_PATH "%d/", id);

    while(1){
        if (NULL == (srcDir = opendir(dirName))) {
            PRINT_ERR_MSG("opendir error");
            return -1;
        }

        while ((srcDp = readdir(srcDir)) != NULL) {
            if(strcmp(srcDp->d_name,".") == 0 || strcmp(srcDp->d_name,"..") == 0){
                continue;
            }

            /* ��������studio���ļ� */
            if(memcmp(srcDp->d_name, SQLSERVER_TMP_ID_PREFIX, strlen(SQLSERVER_TMP_ID_PREFIX))!=0){
                continue;
            }

            memset(&tContent, 0, sizeof(TITLE_CONTNET_TYPE));
            tContent.processId = id;

            memset(requestFileName, 0, sizeof(requestFileName));
            memset(responseFileName, 0, sizeof(responseFileName));

            strcpy(fileBaseName1, srcDp->d_name);
            if ((pos = strstr(fileBaseName1, "_request")) != NULL) {
                *pos = '\0';
                sprintf(fileBaseName2, "%s_response", fileBaseName1);
                *pos = '_';
                sprintf(requestFileName, "%s%s", dirName, fileBaseName1);
                sprintf(responseFileName, "%s%s", dirName, fileBaseName2);
                getValues(&tContent, fileBaseName1);
            } else if ((pos = strstr(fileBaseName1,"_response")) != NULL) {
                *pos = '\0';
                sprintf(fileBaseName2, "%s_request", fileBaseName1);
                *pos = '_';
                sprintf(requestFileName,"%s%s", dirName, fileBaseName2);
                sprintf(responseFileName,"%s%s", dirName, fileBaseName1);
                getValues(&tContent, fileBaseName2);
            } else {
                sprintf(fileBaseName2, "%s%s", dirName, fileBaseName1);
                fprintf(stderr, "<%s>:%d:No request/resonse in file name(%s), remove it.\n", __FILE__, __LINE__,fileBaseName2);
                unlink(fileBaseName2);
            }

            tContent.request=fileContentRequest;
            tContent.response=fileContentResponse;

#if DEBUG_OPEN
            DEBUG_LOG("***********************************************************");
            fprintf(stderr, "<%s>:%d:"
                    "app_id=%hu, sip=%u, sport=%hu, smac=%s, dip=%u, dport=%hu, dmac=%s, seq=%u, user_id=%hu, time=%lu\n",
                    __FILE__, __LINE__,
                    tContent.app_id, tContent.sip, tContent.sport, tContent.smac,
                    tContent.dip, tContent.dport, tContent.dmac, tContent.seq,
                    tContent.user_id, tContent.time);
#endif
            parse_request_file(&tContent, requestFileName);
            parse_response_file(&tContent, responseFileName);

            /* ֻ��һ������ʱ�����ô��ڵ��ļ���ʱ����ɾ�� */
            if((exist=access(requestFileName,0))!=0){
                if (isOld(responseFileName, 120) == 1) {
                    unlink(responseFileName);
                }
                continue;
            }

            if((exist=access(responseFileName,0))!=0){
                if (isOld(requestFileName, 120) == 1) {
                    unlink(requestFileName);
                }
                continue;
            }

            audit_sqlserver(&tContent);

            unlink(requestFileName);
            unlink(responseFileName);
        }
        closedir(srcDir);
        usleep(1000);
    }

    return 0;
}

#else

static char helpStr2[] = "\n\n*************************************************************\n"
                 "USAGE:\n"
                 "audit_sqlserver_process fileFullName <daemonFlag>\n"
                 "fileFullName:       Specify which file to parse.\n"
                 "<daemonFlag>[0/1]: Set daemon mode, 1 for YES, 0 for NO\n"
                 "*************************************************************\n\n";
int main(int argc, char **argv) {
    int deamonOn, i;
    char *pos, fileBaseName1[1024], fileBaseName2[1024];
    TITLE_CONTNET_TYPE tContent;

    if (argc < 1) {
        perror(helpStr2);
        exit(0);
    }
    deamonOn = 0;
    for (i=1; i<argc; i++) {
        if ('1'==argv[i][0] && '\0'==argv[i][1]) {
            deamonOn = 1;
        } else if ('0'==argv[i][0] && '\0'==argv[i][1]) {
            deamonOn = 0;
        } else {
            strcpy(fileBaseName1, argv[i]);
        }
    }

    memset(&tContent, 0, sizeof(TITLE_CONTNET_TYPE));

    if ((pos = strstr(fileBaseName1, "_request")) != NULL) {
        *pos = '\0';
        sprintf(fileBaseName2, "%s_response", fileBaseName1);
        *pos = '_';
        strcpy(requestFileName, fileBaseName1);
        strcpy(responseFileName, fileBaseName2);
        if (getValuesFromFullName(&tContent, fileBaseName1) < 0) {
            return -1;
        }
    } else if ((pos = strstr(fileBaseName1,"_response")) != NULL) {
        *pos = '\0';
        sprintf(fileBaseName2, "%s_request", fileBaseName1);
        *pos = '_';
        strcpy(requestFileName, fileBaseName2);
        strcpy(responseFileName, fileBaseName1);
        if (getValuesFromFullName(&tContent, fileBaseName2) < 0) {
            return -1;
        }
    } else {
        fprintf(stderr, "<%s>:%d:No request/resonse in file name(%s), remove it.\n", __FILE__, __LINE__,fileBaseName1);
        unlink(fileBaseName1);
    }

    tContent.request = fileContentRequest;
    tContent.response = fileContentResponse;

#if DEBUG_OPEN
    DEBUG_LOG("***********************************************************");
    fprintf(stderr, "<%s>:%d:"
            "id = %d, app_id=%hu, sip=%u, sport=%hu, smac=%s, dip=%u, dport=%hu, dmac=%s, seq=%u, user_id=%hu, time=%lu\n",
            __FILE__, __LINE__,
            tContent.processId, tContent.app_id, tContent.sip, tContent.sport, tContent.smac,
            tContent.dip, tContent.dport, tContent.dmac, tContent.seq,
            tContent.user_id, tContent.time);
#endif

    tContent.reqsize = fileInit(requestFileName, fileContentRequest, sizeof(fileContentRequest)-1);
    tContent.respsize = fileInit(responseFileName, fileContentResponse, sizeof(fileContentResponse)-1);

    /* 2015-11-09�����ֶ� */
    long tmpdif = getFileTime(requestFileName)-getFileTime(responseFileName);
    tContent.interval_time = (tmpdif < 0) ? (-tmpdif) : tmpdif;

    audit_sqlserver(&tContent);

    unlink(responseFileName);
    unlink(requestFileName);
    return 0;
}
#endif

