time  /usr/src/inp/main/search_processing_dir 0 &
time  /usr/src/inp/main/search_processing_dir 1 &
time  /usr/src/inp/main/search_processing_dir 2 &
time  /usr/src/inp/main/search_processing_dir 3 &
time  /usr/src/inp/main/search_processing_dir 4 &
time  /usr/src/inp/main/search_processing_dir 5 &
time  /usr/src/inp/main/search_processing_dir 6 &
time  /usr/src/inp/main/search_processing_dir 7 &
time  /usr/src/inp/main/search_processing_dir 8 &
time  /usr/src/inp/main/search_processing_dir 9 &

