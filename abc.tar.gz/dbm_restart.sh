#!/bin/bash

/usr/inp/bin/dbm_stop.sh
sleep 2
/usr/inp/bin/dbm_start.sh
