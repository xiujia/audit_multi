#ifndef _TYPEDEF_H
#define _TYPEDEF_H

typedef char 				PRInt8;
typedef short 			PRInt16;
typedef int				PRInt32;
typedef long 				PRInt64;
typedef unsigned char 		PRUint8;
typedef unsigned short 	PRUint16;
typedef unsigned int 		PRUint32;
typedef unsigned long  	PRUint64;

#endif
