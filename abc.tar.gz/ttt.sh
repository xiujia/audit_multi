a=`cat text`
echo $a
